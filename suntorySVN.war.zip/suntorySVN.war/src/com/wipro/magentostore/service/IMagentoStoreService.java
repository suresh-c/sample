/*
 * This software is the confidential and proprietary information of
 * Wipro. You shall not disclose such Confidential Information and 
 * shall use it only in accordance with the terms of the license 
 * agreement you entered into with Wipro.
 *
 */
package com.wipro.magentostore.service;

import java.util.ArrayList;
import java.util.List;

import com.wipro.dxp.rest.cart.bean.Cart;
import com.wipro.dxp.rest.categories.bean.Categories;
import com.wipro.dxp.rest.categories.response.CategoryProduct;
import com.wipro.dxp.rest.quickorder.bean.QuickOrder;
import com.wipro.dxp.rest.checkout.bean.CheckOut;
import com.wipro.dxp.rest.orderhistory.bean.Order;
import com.wipro.dxp.rest.orderhistory.request.bean.OrderHistory;
import com.wipro.dxp.rest.productview.bean.Product;
import com.wipro.dxp.rest.placeorder.address.request.ShippingAddress;
import com.wipro.dxp.rest.placeorder.request.BillingAddress;
import com.wipro.dxp.rest.quickorder.bean.QuickOrder;
import com.wipro.dxp.search.bean.ProductSearch;
import com.wipro.dxp.rest.quickorder.request.bean.CartItems;








import net.sf.json.JSONObject;

public interface IMagentoStoreService {
	/**
	 * This method fetches all categories for the current store
	 * @param request
	 * @return JSONObject
	 */
	JSONObject fetchCategories();

	/**
	 * This method does a category search and keyword search
	 * @param request
	 * @return JSONObject
	 */
	JSONObject search(String searchType,String value, String condition);

	/**
	 * This method Authenticates the user
	 * @param username
	 * @param password
	 * @return
	 */
	JSONObject login(String username, String password, List<JSONObject> cartDataFromSession);

	/**
	 * fetches all cart data
	 * @param apiToken
	 * @param quoteId
	 * @param cartId
	 * @return
	 */
	JSONObject getCartData(String apiToken);

	/**
	 * This request adds or updates an item to cart
	 * @param cartData
	 * @param apiToken
	 * @return
	 */
	JSONObject addToCart(List<JSONObject> cartData, String apiToken, String cartId);

	/**
	 * Removes an item from cart
	 * @param itemId
	 * @param apiToken
	 * @return
	 */
	JSONObject removeFromCart(String itemId, String apiToken);

	/**
	 * Method returns product details for sku id, pass multiple skuid delimited by "," to get list of products.
	 * @param skuid
	 * @return
	 */
	JSONObject getProductDetailsFromSKU(String skuid );

	/**
	 * Method returns customer info 
	 * @param apiToken
	 * @return
	 */
	JSONObject getUserInfo(String apiToken);

	/**
	 * Method checks the stock availability for the products
	 * @param data
	 * @return
	 */
	JSONObject checkInventory(List<JSONObject> data);

	/**
	 * This method gets all cart items with user info.
	 * @param apiToken
	 * @return
	 */
	JSONObject getCartItemsForCheckout(String apiToken);

	/**
	 * This method places order in the magento system 
	 * @param apiToken
	 * @return
	 */
	JSONObject placeOrder(String apiToken, String ponumber);

	/**
	 * This method gets order details for a customer
	 * @param String cutomerid
	 * @return String
	 */
	Order getOrders(String apiToken);

	/**
	 * This method fetches all data for landing page and also gets all product information for an user and caches it for easy searching
	 */
	JSONObject fetchLandingData();

	JSONObject searchInCache(List<JSONObject> productList, String key, String value);
	JSONObject QuickOrder();
	CategoryProduct categoryProduct(int category);
	Categories loadCategories();


	QuickOrder getQuickOrder(String customer_id1);


	JSONObject getCart(String apiToken);

	JSONObject deleteRequest(String deleteid,String apiToken);

	CheckOut getCheckOutData(String apiToken);

	JSONObject forgotpassword(String email);

	JSONObject resetpassword(String newpassword);

	JSONObject changepassword(String customerId,String currentpassword,String newpassword,String apitoken);
	ProductSearch searchProduct(String keyword,String categoryId);

	JSONObject orderPlacement(String apiToken, String ponumber, ShippingAddress shippingAddress,
			BillingAddress billingAddress, String customer_id);

	JSONObject basketrequest(ArrayList<CartItems> cartitem, String apitoken);
	String UpdateRequest(String apiToken, String cartinfo);
	Product getProductview(String productid);
	JSONObject addrequest(String productId, String qty,String apitoken);

	OrderHistory previousOrder(String orderId);

}

