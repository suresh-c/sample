/*
\ * This software is the confidential and proprietary information of
 * Wipro. You shall not disclose such Confidential Information and 
 * shall use it only in accordance with the terms of the license 
 * agreement you entered into with Wipro.
 *
 */
package com.wipro.magentostore.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import com.wipro.dxp.rest.orderhistory.bean.Order;
import com.wipro.dxp.rest.orderhistory.client.OrderRestClient;
import com.wipro.dxp.rest.orderhistory.request.bean.OrderHistory;
import com.wipro.dxp.rest.productview.bean.Product;
import com.wipro.dxp.rest.productview.client.ProductviewRest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.wipro.dxp.rest.categories.bean.Categories;
import com.wipro.dxp.rest.categories.client.CategoriesRestClient;
import com.wipro.dxp.rest.categories.request.CategoryProductRequest;
import com.wipro.dxp.rest.categories.response.CategoryProduct;
import com.wipro.dxp.rest.checkout.bean.CheckOut;
import com.wipro.dxp.rest.client.CartRequest;
import com.wipro.dxp.rest.client.CheckOutRequest;
import com.wipro.dxp.rest.placeorder.address.request.AddressInformation;
import com.wipro.dxp.rest.placeorder.address.request.AddressInformationRequest;
import com.wipro.dxp.rest.placeorder.address.request.ShippingAddress;
import com.wipro.dxp.rest.placeorder.address.response.AddressInformationResponse;
import com.wipro.dxp.rest.placeorder.client.OrderPaymentRestClient;
import com.wipro.dxp.rest.placeorder.request.BillingAddress;
import com.wipro.dxp.rest.placeorder.request.OrderPaymentRequest;
import com.wipro.dxp.rest.placeorder.request.PaymentMethod;
import com.wipro.dxp.rest.placeorder.response.OrderId;
import com.wipro.dxp.rest.quickorder.bean.QuickOrder;
import com.wipro.dxp.rest.quickorder.client.QuickOrderRequest;
import com.wipro.dxp.rest.quickorder.request.bean.Cart;
import com.wipro.dxp.rest.quickorder.request.bean.CartItems;
import com.wipro.magentostore.util.MagentoApiClient;
import com.wipro.dxp.search.bean.ProductSearch;
import com.wipro.dxp.search.bean.ProductSearchRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


/**
 * 
 * This class manages all the service level actions for MagentoStore
 *
 */
@Service("_magentoStoreService")
public class MagentoStoreService implements IMagentoStoreService {

	@Autowired
	private Properties _sources;

	/**
	 * Autowiring MagentoApiRequest
	 */
	@Autowired
	private MagentoApiClient magentoApiClient;

	/**
	 * Registering logger
	 */
	private static final Logger _LOGGER = Logger.getLogger(MagentoStoreService.class);


	@SuppressWarnings("unchecked")
	@Override
	public JSONObject getCartData(String apiToken){
		JSONObject response = null;
		try{
			response = magentoApiClient.makeRequest("/carts/mine", "GET", null, apiToken);
			if(response.getString("status").equals("success")){
				List<JSONObject> cartItems = response.getJSONObject("data").getJSONArray("items");
				if(cartItems.size() > 0){

					// Look up object to reduce nested for loop in next step.
					Map<String, Integer> itemIndexes = new HashMap<String, Integer> ();
					int index = 0;
					String inString = "";
					for(JSONObject cartItem : cartItems){
						String skuId  = cartItem.getString("sku");
						inString += skuId+",";
						itemIndexes.put(skuId, index++);
					}
					JSONObject productInfo = getProductDetailsFromSKU(inString);
					_LOGGER.info("productInfo" + productInfo.getJSONObject("data").get("items"));
					if (productInfo.getJSONObject("data").get("items")!=null){
						for(JSONObject product : (List<JSONObject>)productInfo.getJSONObject("data").get("items")){
							String sku = product.getString("sku");
							//cartItems.get(itemIndexes.get(sku)).put("image", product.getString("small_image"));
							cartItems.get(itemIndexes.get(sku)).put("crate", "N/A");
						}
					}
				}
			}
		}
		catch(Exception e){
			response = new JSONObject();
			response.put("status", "failed");
			e.printStackTrace();
		}

		return response;
	}
	public JSONObject getCart(String apiToken){
		JSONObject cartInfo = CartRequest.jsonresponse(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("Cart.service.path"),apiToken);
		return cartInfo;
	}

	@Override
	public JSONObject forgotpassword(String email) {
		JSONObject response = null;
		try{
			_LOGGER.info("MagentoStoreService-forgotpassword-STARTS");
			JSONObject userData = new JSONObject();
			userData.put("email", email);
			userData.put("template", "email_reset");
			userData.put("websiteId", "1");
			response = magentoApiClient.makeRequest("/customers/password", "PUT", userData.toString(), null);
			if(response.getString("status").equals("success")){
				response.put("status", "success");
			}
			_LOGGER.info("MagentoStoreService-forgotpassword-ENDS");
		}catch(Exception e){
			e.printStackTrace();
			response = new JSONObject();
			response.put("status", "failed");
		}
		return response;
	}


	@Override
	public JSONObject resetpassword(String newpassword) {
		JSONObject response = null;
		try{
			_LOGGER.info("MagentoStoreService-resetpassword-STARTS");
			JSONObject userData = new JSONObject();



			userData.put("email", "v.05@wipro.com");
			userData.put("resetToken", "79574daaa4220f058a73761e1d591160");
			userData.put("newPassword", newpassword);

			response = magentoApiClient.makeRequest("/customers/resetPassword", "POST", userData.toString(), null);
			if(response.getString("status").equals("success")){
				response.put("status", "success");
			}
			_LOGGER.info("MagentoStoreService-resetpassword-ENDS");
		}catch(Exception e){
			e.printStackTrace();
			response = new JSONObject();
			response.put("status", "failed");
		}
		return response;
	}



	@Override
	public JSONObject changepassword(String customerId,String currentpassword,String newpassword,String apitoken) {
		JSONObject response = null;
		try{
			_LOGGER.info("MagentoStoreService-changepassword-STARTS");
			JSONObject userData = new JSONObject();

			userData.put("customer_id", customerId);
			userData.put("currentPassword", currentpassword);
			userData.put("newPassword", newpassword);
			_LOGGER.info(userData);
			response = magentoApiClient.makeRequest("/customers/me/password", "PUT", userData.toString(), apitoken);
			if(response.getString("status").equals("success")){
				response.put("status", "success");
			}
			_LOGGER.info("MagentoStoreService-changepassword-ENDS");
		}catch(Exception e){
			e.printStackTrace();
			response = new JSONObject();
			response.put("status", "failed");
		}
		return response;
	}


	@SuppressWarnings("unchecked")
	@Override
	public JSONObject getProductDetailsFromSKU(String skuid ){
		_LOGGER.info("MagentoStoreService-getProductDetailsFromSKU-STARTS");
		JSONObject result = new JSONObject();
		if(!skuid.contains(",")){
			result = magentoApiClient.makeRequest("/products/"+skuid, "GET", null, null);
		}else{
			result = magentoApiClient.makeRequest(getSearchURL("sku",skuid,"in"), "GET", null, null);
			if(result.getString("status").equals("success")){
				for(JSONObject product : (List<JSONObject>)result.getJSONObject("data").get("items")){
					for(JSONObject attributes : (List<JSONObject>)product.get("custom_attributes")){
						product.put(attributes.getString("attribute_code"), attributes.getString("value"));
						product.remove("custom_attributes");
					}
				}
			}
		}
		_LOGGER.info("MagentoStoreService-getProductDetailsFromSKU-ENDS");
		return result;
	}
	public JSONObject QuickOrder()
	{
		_LOGGER.info("MagentoStoreService-QuickOrder-STARTS");
		//		JSONObject result = magentoApiClient.makeRequest("/suntory/customer/1/most_ordered/20", "GET", null, null);
		//		QuickOrder quick_order = new QuickOrder();  
		//		Gson gson = new Gson();
		//		Type type = new TypeToken<QuickOrder>() {}.getType();
		//		
		////	//	quick_order = gson.fromJson(result, type);
		//		System.out.println(quick_order.getOrders());
		//		System.out.println(quick_order.getOrders().get(0).getProduct().getShort_description());
		return null ;

	}
	@Override
	public JSONObject login(String username, String password, List<JSONObject> cartDataFromSession) {
		_LOGGER.info("MagentoStoreService-login-STARTS");
		JSONObject response = null;
		try{
			JSONObject userData = new JSONObject();
			userData.put("username", username);
			userData.put("password", password);
			response = magentoApiClient.makeRequest("/integration/customer/token", "POST", userData.toString(), null);
			_LOGGER.info(response.getString("status"));
			String apiToken = response.getString("data");
			System.out.println("LOGIN"+apiToken);
			if(response.getString("status").equals("success")){

				// GET USERS ACCOUNT INFO
				response.put("userinfo", getUserInfo(apiToken).getString("data"));

				// USERS PREVIOUS CART DATA
				JSONObject cartData =getCartData(apiToken);
				String cartId = "";
				if(cartData.getString("status").equals("success")){
					if(null!=cartData && null!=cartData.getJSONObject("data").getString("id") && !cartData.getJSONObject("data").getString("id").isEmpty()){
						cartId = cartData.getJSONObject("data").getString("id");
					}
					// TRANSFER CART DATA FROM SESSION TO MAGENTO STORE
					if(cartDataFromSession != null){
						addToCart(cartDataFromSession, apiToken, cartId);
					}
					response.put("status", "success");
					response.put("cartId", cartId);
				}
			}
			_LOGGER.info("MagentoStoreService-login-ENDS");
		}
		catch(Exception e){
			e.printStackTrace();
			response = new JSONObject();
			response.put("status", "failed");
		}
		return response;
	}


	@Override
	public JSONObject addToCart(List<JSONObject> cartData, String apiToken, String cartId){
		_LOGGER.info("MagentoStoreService-addToCart-STARTS");
		JSONObject response = new JSONObject();
		JSONObject apiResponses = new JSONObject();
		for(JSONObject cartItem : cartData ){
			JSONObject js = new JSONObject();
			js.put("quoteId", cartId);
			js.put("sku", cartItem.getString("sku"));
			js.put("qty", cartItem.getString("qty"));
			JSONObject result = magentoApiClient.makeRequest("/carts/mine/items", "POST", new JSONObject().accumulate("cartItem", js).toString(), apiToken);
			apiResponses.put(cartItem.getString("sku"), result);
		}
		response.put("data", apiResponses);
		response.put("status","success");
		_LOGGER.info("MagentoStoreService-addToCart-ENDS");
		return response;
	}

	@Override
	public JSONObject removeFromCart(String itemId, String apiToken){
		_LOGGER.info("MagentoStoreService-removeFromCart-STARTS");
		JSONObject result = magentoApiClient.makeRequest("/carts/mine/items/"+itemId, "DELETE", null, apiToken);
		_LOGGER.info("MagentoStoreService-removeFromCart-ENDS");
		return result;
	}

	@Override
	public JSONObject getUserInfo(String apiToken){
		_LOGGER.info("MagentoStoreService-getUserInfo-STARTS");	
		JSONObject result = magentoApiClient.makeRequest("/customers/me", "GET", null, apiToken);
		_LOGGER.info("MagentoStoreService-getUserInfo-ENDS");
		return result;
	}


	@Override
	public JSONObject fetchCategories() {
		_LOGGER.info("MagentoStoreService-fetchCategories-STARTS");
		JSONObject js = magentoApiClient.makeRequest("/categories", "GET", null, "");
		//		Categories ct = loadCategories();
		//		js.put("jkcategories", ct);
		_LOGGER.info("MagentoStoreService-fetchCategories-ENDS");
		return js;
	}

	@Override
	public JSONObject search(String searchType,String paramvalue, String condition) {
		_LOGGER.info("MagentoStoreService-search-STARTS");
		JSONObject result = magentoApiClient.makeRequest(getSearchURL(searchType, paramvalue, condition), "GET", null, null);
		result.put("searchtext", paramvalue);
		_LOGGER.info("MagentoStoreService-search-ENDS");
		return result;
	}

	@Override
	public JSONObject checkInventory(List<JSONObject> data){
		_LOGGER.info("MagentoStoreService-checkInventory-STARTS");
		JSONObject response = new JSONObject();
		try{
			List<JSONObject> stockInfo = new ArrayList<JSONObject>();
			for(JSONObject item : data){
				String sku = item.getString("sku");
				int reqestCount = item.getInt("quantity"); 

				JSONObject stockResponse = magentoApiClient.makeRequest("/stockStatuses/"+sku, "GET", null, null);
				System.out.println(stockResponse);
				JSONObject stockItem = stockResponse.getJSONObject("data");
				int availableCount = stockItem.getInt("qty");

				stockItem.clear();
				stockItem.put("sku", sku);
				stockItem.put("requestCount", reqestCount);
				stockItem.put("availableCount", availableCount);
				stockItem.put("stockAvailable", availableCount >= reqestCount ? true : false);
				stockItem.put("deliverydate", getRandomDate(5,15).toGMTString());
				stockInfo.add(stockItem);
			}	
			response.put("status", "success");
			response.put("stockInfo", stockInfo);
		}
		catch(Exception e){
			e.printStackTrace();
			response.put("status", "failed");
		}
		_LOGGER.info("MagentoStoreService-checkInventory-ENDS");
		return response;

	}

	@Override
	public JSONObject getCartItemsForCheckout(String apiToken) {
		_LOGGER.info("MagentoStoreService-getCartItemsForCheckout-STARTS");
		JSONObject result = magentoApiClient.makeRequest("/carts/mine", "GET", null, apiToken);
		_LOGGER.info("MagentoStoreService-getCartItemsForCheckout-ENDS");
		return result;
	}

	@Override
	public JSONObject placeOrder(String apiToken, String ponumber) {
		_LOGGER.info("MagentoStoreService-placeOrder-STARTS");
		JSONObject result = null;
		try{
			JSONObject cartData =  getCartItemsForCheckout(apiToken);
			_LOGGER.info(cartData);

			if(cartData.getJSONObject("data").getJSONArray("items").size() == 0){
				throw new Exception("Cart is Empty");
			}

			// PLACE ORDER
			JSONObject paymentInfo = formatPaymentInfo(cartData.getJSONObject("data").getJSONObject("customer").getJSONArray("addresses").getJSONObject(0)
					,ponumber);

			JSONObject confirmPayment = magentoApiClient.makeRequest("/carts/mine/payment-information", "POST", paymentInfo.toString(), apiToken);
			if(confirmPayment.getString("status").equals("failed")){
				throw new Exception("Unexpected Error While Processing");
			}

			// CREATE A NEW CART FOR CUSTOMER
			JSONObject newCart = magentoApiClient.makeRequest("/carts/mine", "POST", "", apiToken);
			if(newCart.getString("status").equals("failed")){
				throw new Exception("Unexpected Error While Processing");
			}

			// FORMAT DATA FOR UI
			confirmPayment.put("newCartId", newCart.getString("data"));
			confirmPayment.put("orderId", confirmPayment.getString("data"));
			confirmPayment.put("cartInfo", cartData.getString("data"));
			confirmPayment.put("paymentInfo", paymentInfo);
			confirmPayment.remove("data");

			result = confirmPayment;
		}
		catch(Exception e){
			e.printStackTrace();
			result = new JSONObject();
			result.put("status", "failed");
			if(e instanceof Exception ){
				result.put("message", e.getMessage());
			}
		}		
		_LOGGER.info("MagentoStoreService-placeOrder-ENDS");
		return result;
	}


	private JSONObject formatPaymentInfo(JSONObject addressData, String poNumber){
		JSONObject region = addressData.getJSONObject("region");

		addressData.put("region_code", region.getString("region_code"));
		addressData.put("region_id", region.getString("region_id"));
		addressData.put("region", region.getString("region"));
		addressData.put("customer_address_id", addressData.getString("id"));
		addressData.remove("id");
		addressData.remove("default_shipping");
		addressData.remove("default_billing");

		JSONObject paymentMethod = new JSONObject();
		paymentMethod.put("po_number", poNumber);
		paymentMethod.put("method", "purchaseorder");

		JSONObject paymentInfo = new JSONObject();

		paymentInfo.put("paymentMethod", paymentMethod);
		paymentInfo.put("billingAddress", addressData);

		_LOGGER.info("Payment Data \n : "+paymentInfo);
		return paymentInfo;
	}



	/**
	 * Helper to create search url
	 * @param searchType
	 * @param paramvalue
	 * @param condition
	 * @return
	 */
	private String getSearchURL(String searchType,String paramvalue, String condition){
		String url="";
		if(searchType.indexOf(",")==-1){
			url= "/products/?searchCriteria[filter_groups][0][filters][0][field]="+searchType
					+"&searchCriteria[filter_groups][0][filters][0][value]="+(condition.equals("like") ? "%25"+paramvalue+"%25" : paramvalue)
					+"&searchCriteria[filter_groups][0][filters][0][condition_type]="+condition;
		}else{
			String search[]=searchType.split(",");
			url="/products/?";
			for(int i=0;i<search.length;i++){
				url+= "searchCriteria[filter_groups][0][filters]["+i+"][field]="+search[i]
						+"&searchCriteria[filter_groups][0][filters]["+i+"][value]="+(condition.equals("like") ? "%25"+paramvalue+"%25" : paramvalue)
						+"&searchCriteria[filter_groups][0][filters]["+i+"][condition_type]="+condition+"&";
			}
			url+= "searchCriteria[filter_groups][0][filters][2][field]=store&searchCriteria[filter_groups][0][filters][2][value]=2&searchCriteria[filter_groups][0][filters][2][condition_type]=eq";
		}
		return url;
	}


	/**
	 *  This method returns random date within range
	 * @param skipDaysFromToday
	 * @param daysWithin
	 * @return
	 */
	private Date getRandomDate(long skipDaysFromToday, long daysWithin){
		long time = new Date().getTime();
		return new Date(ThreadLocalRandom.current().nextLong(time+ (skipDaysFromToday *86400000),time + (daysWithin * 86400000)));
	}

	/**
	 * This method gets order details for a customer
	 * @param String cutomerid
	 * @return String
	 */
	public Order getOrders(String apiToken) {
		_LOGGER.info("MagentoStoreService-getOrders-STARTS");
		Order order=new Order();
		order = OrderRestClient.orderresponse(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("order.service.path"),apiToken);
		
		_LOGGER.info("MagentoStoreService-getOrders-ENDS");
		return order;
	}

	@SuppressWarnings("unchecked")
	@Override
	public JSONObject fetchLandingData() {
		_LOGGER.info("MagentoStoreService-fetchLandingData-STARTS");
		JSONObject response = new JSONObject();
		JSONObject allCategories = fetchCategories();
		JSONObject products = search("store", _sources.getProperty("store.id"), "eq");

		JSONObject categoriesMap = new JSONObject();
		for(JSONObject js : (List<JSONObject>)allCategories.getJSONObject("data").getJSONArray("children_data")){
			categoriesMap.put(js.getString("id"), js.getString("name"));
		}

		List<JSONObject> productsList = products.getJSONObject("data").getJSONArray("items");
		for(JSONObject product : productsList){
			arrayToJSON(product,product.getJSONArray("custom_attributes"));
			String categoryId = (String) product.getJSONArray("category_ids").get(0);
			product.put("category_id",categoryId );
			product.put("category_name", categoriesMap.get(categoryId));
			product.remove("category_ids");
			product.remove("custom_attributes");
		}
		response.put("categories", categoriesMap);
		response.put("productList", productsList);
		_LOGGER.info("MagentoStoreService-fetchLandingData-ENDS");
		return response;
	}

	private JSONObject arrayToJSON(JSONObject accumulator, List<JSONObject> jsonArray){

		for(JSONObject item :  jsonArray){
			accumulator.put(item.getString("attribute_code"), item.getString("value"));
		}
		return accumulator;
	}

	@Override
	public JSONObject searchInCache(List<JSONObject> productList,String key, String value) {
		_LOGGER.info("MagentoStoreService-searchInCache-STARTS");
		JSONArray resultList = new JSONArray();	
		for(JSONObject product : productList){

			// FREE TEXT SEARCH
			if(key.equals("all")){
				boolean match = product.getString("sku").contains(value) ||
						product.getString("category_name").contains(value) ||
						product.getString("name").contains(value) ||
						(product.containsKey("description") && product.getString("description").contains(value));

				if(match)
					resultList.add(product);
			}else{

				// LIST SEARCH
				if(value.contains(",")){
					String[] values = value.split(",");
					for(String val : values){
						if(product.containsKey(key) && product.getString(key).equals(val))
							resultList.add(product);
					}
				}else{

					// SINGLE PRODUCT SEARCH
					if(product.containsKey(key) && product.getString(key).equals(value))
						resultList.add(product);
				}

			}
		}
		JSONObject result = new JSONObject();
		result.put("status", "success");
		result.put("data", resultList);
		_LOGGER.info("MagentoStoreService-searchInCache-ENDS");
		return result;
	}
	@Override
	public Categories loadCategories() {
		_LOGGER.info("MagentoStoreService-loadCategories-STARTS");	
		CategoriesRestClient categoriesRestClient = new CategoriesRestClient();
		_LOGGER.info("CategoriesRestClient-loadCategories-STARTS");
		Categories categories = categoriesRestClient.getCategories(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("categories.service.path"), _sources.getProperty("magento.service.token"));
		_LOGGER.info("CategoriesRestClient-loadCategories-STARTS"+categories);
		//		JSONObject js = magentoApiClient.makeRequest("/categories", "GET", null, "");
		_LOGGER.info("MagentoStoreService-loadCategories-ENDS");
		return categories;
	}
	/* (non-Javadoc)
	 * @see com.wipro.magentostore.service.IMagentoStoreService#categoryProduct(int)
	 */
	@Override
	public CategoryProduct categoryProduct(int category)
	{
		_LOGGER.info("MagentoStoreService-CategoryProduct-STARTS");
		CategoriesRestClient restClient = new CategoriesRestClient();
		CategoryProductRequest productRequest= new CategoryProductRequest();
		productRequest.setCategoryId(category);
		productRequest.setPageSize(5);
		productRequest.setPage(1);
		CategoryProduct productsResult = restClient.getCategoryProducts(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("category.products.service.path"), _sources.getProperty("magento.service.token"), productRequest);
		_LOGGER.info("MagentoStoreService-CategoryProduct-"+productsResult);
		magentoApiClient.setMediaFiles(productsResult);
		return productsResult ;

	}

	@Override
	public QuickOrder getQuickOrder(String customer_id1) {
		_LOGGER.info("MagentoStoreService-Quick Order-STARTS");
		JSONObject result = new JSONObject();

		QuickOrderRequest request=new QuickOrderRequest();
		_LOGGER.info(_sources.getProperty("quickorder.service.path")+customer_id1+_sources.getProperty("quickorder.service.recent"));
		QuickOrder order = request.jsonresponse(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("quickorder.service.path")+customer_id1+_sources.getProperty("quickorder.service.recent"),_sources.getProperty("magento.service.token"));
		//        if(order.getString("status").equalsIgnoreCase("success")){
		//              String url = "/orders/?searchCriteria[filter_groups][0][filters][0][field]=customer_id&searchCriteria[filter_groups][0][filters][0][value]="+cutomerid+"&searchCriteria[filter_groups][0][filters][0][condition_type]=eq";
		//              result = magentoApiClient.makeRequest(url, "GET", null, getAdminToken.getString("data"));
		//        }
		result.put("quickorder",order);
		_LOGGER.info("MagentoStoreService-Quick Order-ENDS");
		return order;

	}

	public JSONObject deleteRequest(String deleteid,String apiToken)
	{

		CartRequest request=new CartRequest();
		JSONObject j=new JSONObject();
		j=request.makeRequest(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("delete.service.path")+deleteid,"DELETE",apiToken,"");
		_LOGGER.info(j.get("status"));
		//_LOGGER.info(j.get("status"));
		//JSONObject jsonResponse = request.updateCartAfterDelete(j);
		return j;
	}

	@SuppressWarnings("unchecked")
	@Override
	public CheckOut getCheckOutData(String apiToken){

		_LOGGER.info(_sources.getProperty("magento.rest.base.url"));
		CheckOut c = CheckOutRequest.jsonResponse(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("CheckOut.service.path"),apiToken);
		return c;
	}

	public JSONObject basketrequest(ArrayList<CartItems> cartitem,String apiToken) {
		// TODO Auto-generated method stub			
		Cart cart=new Cart();
		cart.setCartItems(cartitem);
		Gson json=new Gson();
		String cartinfo=json.toJson(cart);
		_LOGGER.info(cartinfo);
		QuickOrderRequest request=new QuickOrderRequest();
		JSONObject j=request.quickorderrequest(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("quickorder.update.basket.service.path"),cartinfo,apiToken,"POST");
		if(j.getString("status").equals("success")){
			_LOGGER.info("hai");
		}
		return j;
	}


	@Override
	public JSONObject orderPlacement(String customerToken, String ponumber, ShippingAddress shippingAddress, BillingAddress billingAddress, String customer_id) {
		_LOGGER.info("MagentoStoreService-placeOrder-STARTS");
		JSONObject result = new JSONObject();
		OrderPaymentRestClient orderPaymentRestClient = new OrderPaymentRestClient();
		AddressInformation addressInformation = new AddressInformation();
		addressInformation.setShippingAddress(shippingAddress);
		AddressInformationRequest addressInformationRequest = new AddressInformationRequest();
		addressInformationRequest.setAddressInformation(addressInformation);
		AddressInformationResponse  shipAddressResponse = orderPaymentRestClient.saveShippingAddress(_sources.getProperty("magento.rest.base.url"), _sources.getProperty("order.shipping.address.save.path"), customerToken, addressInformationRequest);

		/**
		 * Setting payment info
		 */
		PaymentMethod paymentMethod = new PaymentMethod();
		//paymentMethod.setMethod(shipAddressResponse.getPayment_methods().get(0).getCode());
		paymentMethod.setMethod("purchaseorder");
		paymentMethod.setPo_number(ponumber);
		OrderPaymentRequest orderPaymentRequest = new OrderPaymentRequest();
		orderPaymentRequest.setPaymentMethod(paymentMethod);
		orderPaymentRequest.setBilling_address(billingAddress);
		OrderId orderId = orderPaymentRestClient.orderPlacement(_sources.getProperty("magento.rest.base.url"), _sources.getProperty("order.place.payment.path"), customerToken, orderPaymentRequest);
		_LOGGER.info("MagentoStoreService-placeOrder-ENDS"+shipAddressResponse);
		result.put("orderId", orderId.getOrder_id());
		/**
		 * Request to create new empty cart for the user
		 */
		magentoApiClient.makeRequest(_sources.getProperty("order.place.refresh.cart.path").concat(customer_id).concat(_sources.getProperty("order.place.refresh.cart")), "POST", null,null);
		return result;
	}
	public String UpdateRequest(String apiToken, String cartinfo)
	{

		QuickOrderRequest request=new QuickOrderRequest();
		JSONObject j=request.quickorderrequest(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("quickorder.update.basket.service.path"),cartinfo,apiToken,"POST");
		_LOGGER.info(j.getString("status"));
		return j.getString("status");

	}
	public Product getProductview(String productid)
	{
		_LOGGER.info("MagentoStoreService-Productview-STARTS");
		Product product= new Product();
		product = ProductviewRest.productsearch(_sources.getProperty("magento.base.url"), _sources.getProperty("productview.service.path")+productid,_sources.getProperty("magento.service.token"));
		_LOGGER.info("MagentoStoreService-Productview-ENDS");
		magentoApiClient.setImages(product);
		return product;
	}

	@Override
	public JSONObject addrequest(String productId, String qty,String apitoken) {
		// TODO Auto-generated method stub
		Cart cart=new Cart();
		ArrayList<CartItems> cartitemlist=new ArrayList<CartItems>();
		CartItems cartitem=new CartItems();
		cartitem.setProductId(Integer.parseInt(productId));
		cartitem.setQty(Integer.parseInt(qty));
		cartitemlist.add(cartitem);
		cart.setCartItems(cartitemlist);
		Gson json=new Gson();
		String cartinfo=json.toJson(cart);
		ProductviewRest request=new ProductviewRest();
		JSONObject jsonresponse=request.productrequest(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("quickorder.update.basket.service.path"),cartinfo,apitoken,"POST");
		return jsonresponse;
	}
	@Override
	public ProductSearch searchProduct(String keyword,String categoryId) {
		// TODO Auto-generated method stub
		ProductSearchRequest searchresult=new ProductSearchRequest();
		ProductSearch search=new ProductSearch();
		_LOGGER.info("CatID="+categoryId);
		if(categoryId==null || categoryId.isEmpty()) {
			 search=searchresult.makeRequest(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("searchproduct.service.path")+keyword+_sources.getProperty("searchproduct.service.keyword")+keyword+_sources.getProperty("serachproduct.service.keyword_hint") ,_sources.getProperty("magento.service.token"));
		}
		else {
			 search=searchresult.makeRequest(_sources.getProperty("magento.rest.base.url"),_sources.getProperty("searchproduct.service.catpath")+keyword+_sources.getProperty("searchproduct.service.catpathkey")+keyword+_sources.getProperty("searchproduct.service.catpathkeyword")+categoryId+_sources.getProperty("searchproduct.service.catpathcid") ,_sources.getProperty("magento.service.token"));	
		}
		magentoApiClient.setMediaFilesSearch(search);
		return search;
	}
	public OrderHistory previousOrder(String orderId)
	{
		OrderRestClient request=new OrderRestClient();
		OrderHistory orderdetail=request.orderDetailresponse(_sources.getProperty("magento.rest.base.url"), _sources.getProperty("orderdetail.service.path")+orderId, _sources.getProperty("magento.service.token"));
		return orderdetail;
		
	}
}


