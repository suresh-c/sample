/*
 * This software is the confidential and proprietary information of
 * Wipro. You shall not disclose such Confidential Information and 
 * shall use it only in accordance with the terms of the license 
 * agreement you entered into with Wipro.
 *
 */
package com.wipro.magentostore.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.security.oauth2.sso.EnableOAuth2Sso;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.wipro.dxp.rest.cart.bean.Cart;
import com.wipro.dxp.rest.cart.bean.Items;
import com.wipro.dxp.rest.categories.bean.Categories;
import com.wipro.dxp.rest.categories.response.CategoryProduct;
import com.wipro.dxp.rest.orderhistory.bean.Order;
import com.wipro.dxp.rest.orderhistory.request.bean.Address;
import com.wipro.dxp.rest.orderhistory.request.bean.OrderHistory;
import com.wipro.dxp.rest.productview.bean.Product;
import com.wipro.dxp.rest.quickorder.bean.QuickOrder;
import com.wipro.dxp.rest.quickorder.request.bean.CartItems;
import com.wipro.dxp.rest.updatecart.response.CartItem;
import com.wipro.dxp.rest.updatecart.response.UpdateCartItems;
import com.wipro.magentostore.service.IMagentoStoreService;
import com.wipro.dxp.rest.checkout.bean.CheckOut;
import com.wipro.dxp.rest.placeorder.address.request.ShippingAddress;
import com.wipro.dxp.rest.placeorder.request.BillingAddress;
import com.wipro.dxp.search.bean.ProductSearch;
/**
 * 
 * This class controls all the requests for the MagentoStore
 *	
 */
@EnableOAuth2Sso
@Controller
public class MagentoStoreController {
	
	/**
	 *  Autowiring MagentoStoreService
	 */
	@Autowired 
	private IMagentoStoreService _magentoStoreService;
	
	/**
	 * Autowiring sources 	
	 */
	@Autowired
	private Properties _sources;
	
	/**
	 * Registering logger
	 */
	private static final Logger _LOGGER = Logger.getLogger(MagentoStoreController.class);
	Categories	categories = new Categories();
	CategoryProduct categoryProduct = new CategoryProduct();
	/**
	 * This method authenticates user
	 * @param request
	 * @param response
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/login.mgt")
	public @ResponseBody JSONObject login(HttpServletRequest request,HttpServletResponse response){
	_LOGGER.info("MagentoStoreController-Login-STARTS");
		String userType = request.getParameter("userType");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
    JSONObject  result = new JSONObject();
        System.out.println(username +"  "+password + " " +userType);
	try{    
if(userType.equals("Suntory")){/*
        HttpSession session = request.getSession();
		List<JSONObject> cartDataFromSession = session.getAttribute("cartData") == null ? null :JSONArray.fromObject(session.getAttribute("cartData")) ;
	//result = _magentoStoreService.login(username, password, cartDataFromSession);
		result = _magentoStoreService.login(username, password, cartDataFromSession);
    System.out.println(result);	
		//JSONObject	result = _magentoStoreService.login(username, password, cartDataFromSession);
		//System.out.println(result);
		if(result.getString("status").equals("success")){
		 JSONObject userinfo = result.getJSONObject("userinfo");
	              session.removeAttribute("cartData");
	              session.setAttribute("customerId", userinfo.getString("id"));
	              session.setAttribute("apiToken", result.getString("data"));
	              session.setAttribute("userEmail", username);
	              session.setAttribute("userFullName", userinfo.getString("firstname")+" "+userinfo.getString("lastname")) ;
	              session.setAttribute("categoryId", "");
	              session.setAttribute("cartId", result.getString("cartId"));
	              result.remove("data");
	              result.remove("cartId");
		}
    */
	
//Okta Integration - START
	System.out.println("Okta Integartion");
	HttpSession session = request.getSession();
	List<JSONObject> cartDataFromSession = session.getAttribute("cartData") == null ? null :JSONArray.fromObject(session.getAttribute("cartData")) ;
//result = _magentoStoreService.login(username, password, cartDataFromSession);
	result = _magentoStoreService.login(username, password, cartDataFromSession);
System.out.println(result);	
	//JSONObject	result = _magentoStoreService.login(username, password, cartDataFromSession);
	//System.out.println(result);
	if(result.getString("status").equals("success")){
	 JSONObject userinfo = result.getJSONObject("userinfo");
              session.removeAttribute("cartData");
              session.setAttribute("customerId", userinfo.getString("id"));
              session.setAttribute("apiToken", result.getString("data"));
              session.setAttribute("userEmail", username);
              session.setAttribute("userFullName", userinfo.getString("firstname")+" "+userinfo.getString("lastname")) ;
              session.setAttribute("categoryId", "");
              session.setAttribute("cartId", result.getString("cartId"));
              result.remove("data");
              result.remove("cartId");
	}
	
	//Okta Integration - END




}
    else if(userType.equals("Partners")){
    	HttpSession session = request.getSession();
        List<JSONObject> cartDataFromSession = session.getAttribute("cartData") == null ? null :JSONArray.fromObject(session.getAttribute("cartData")) ;
        result = _magentoStoreService.login(username, password, cartDataFromSession);
        System.out.println(result);
        if(result.getString("status").equals("success")){
             JSONObject userinfo = result.getJSONObject("userinfo");
	              session.removeAttribute("cartData");
	              session.setAttribute("customerId", userinfo.getString("id"));
	              session.setAttribute("apiToken", result.getString("data"));
	              session.setAttribute("userEmail", username);
	              session.setAttribute("userFullName", userinfo.getString("firstname")+" "+userinfo.getString("lastname")) ;
	              session.setAttribute("categoryId", "");
	              session.setAttribute("cartId", result.getString("cartId"));
	              result.remove("data");
	              result.remove("cartId");
        }
    }
	}catch (Exception e) {
			_LOGGER.info("Exception in login:"+e);
		}
		_LOGGER.info("MagentoStoreController-getProduct-ENDS");
		return result;
	}
	
	/**
	 * This request logs out the user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/logout.mgt")
	public String logout(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-logout-STARTS");
		request.getSession().invalidate();
		_LOGGER.info("MagentoStoreController-logout-ENDS");
		return "redirect:/";
	}
	
	
	@RequestMapping(value="/forgotpassword.mgt")
	public String forgotpassword(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-forgotpassword-Loads");
		return "password/forgotpassword";
	}
 
	@RequestMapping(value="/requestPassword.mgt")
	 public @ResponseBody JSONObject requestPassword(HttpServletRequest request,HttpServletResponse response){
			_LOGGER.info("MagentoStoreController-requestPassword-STARTS");
			String email = request.getParameter("email");
			
			System.out.println("email:  "+email);
			
			JSONObject	result = _magentoStoreService.forgotpassword(email);
			System.out.println(result);
			if(result.getString("status").equals("success")){
				System.out.println("Response Success");
			}
			_LOGGER.info("MagentoStoreController-requestPassword-ENDS");
			return result;
		}
	
	@RequestMapping(value="/resetpassword.mgt")
	public String resetpassword(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-resetpassword-Loads");
		return "password/resetpassword";
	}
	
	@RequestMapping(value="/updateresetpassword.mgt")
	 public @ResponseBody JSONObject updateresetpassword(HttpServletRequest request,HttpServletResponse response){
			_LOGGER.info("MagentoStoreController-updateresetpassword-STARTS");
			String newpassword = request.getParameter("newpassword");
			
			System.out.println("newpassword:  "+newpassword);
			
			JSONObject	result = _magentoStoreService.resetpassword(newpassword);
			System.out.println(result);
			if(result.getString("status").equals("success")){
				System.out.println("Response Success");
			}
			_LOGGER.info("MagentoStoreController-updateresetpassword-ENDS");
			return result;
		}
	
	@RequestMapping(value="/updatechangepassword.mgt")
	public @ResponseBody JSONObject updatechangepassword(HttpServletRequest request,HttpServletResponse response){
			_LOGGER.info("MagentoStoreController-updatechangepassword-STARTS");
			HttpSession session = request.getSession();
			String customerId=(String) session.getAttribute("customerId");
			String currentpassword = request.getParameter("currentpassword");
			String newpassword1 = request.getParameter("newpassword");
			String apitoken = (String) session.getAttribute("apiToken");
			System.out.println("customerId"+customerId+"currentpassword:"+currentpassword+"newpassword: "+newpassword1);
			
			JSONObject	result = _magentoStoreService.changepassword(customerId,currentpassword,newpassword1,apitoken);
			System.out.println(result);
			if(result.getString("status").equals("success")){
				System.out.println("Response Success");
			}
			_LOGGER.info("MagentoStoreController-updatechangepassword-ENDS");
			return result;
		}
	
	/**
	 * This method fetches all categories for the current store
	 * @param request
	 * @param response
	 * @return
	 *//*
	@RequestMapping(value="/fetchCategories.mgt")
	public @ResponseBody JSONObject fetchCategories(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-fetchCategories-STARTS");
		JSONObject js = _magentoStoreService.fetchCategories();
		_LOGGER.info("MagentoStoreController-fetchCategories-ENDS");
		return js;
	}*/
	/**
	 * This method does a category search and keyword search
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/search.mgt")
	public @ResponseBody JSONObject search(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-search-STARTS");
		String searchType = request.getParameter("searchtype");
		String value = request.getParameter("value");
		String condition = request.getParameter("condition");
		JSONObject result = _magentoStoreService.search(searchType, value, condition);
		_LOGGER.info("MagentoStoreController-search-ENDS");
		return result;
	}
	
	/**
	 * This method returns product info of particular product
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/getproduct.mgt")
	public @ResponseBody JSONObject getProduct(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-getProduct-STARTS");
		String sku = request.getParameter("sku");
		JSONObject	result = _magentoStoreService.getProductDetailsFromSKU(sku);
		_LOGGER.info("MagentoStoreController-getProduct-ENDS");
		return result;
		
	}
	
	
	/**
	 * This request adds or updates an item to cart
	 * 
	 * @RequestParam data : Example  {
	      [{
	        "sku": "YSMH",
	        "qty": "1"
	        "item_id" : "12",
	        "image" : "image path",
	        "name" : "product name"
	      }]
	 * 
	 * @param request
	 * @param response
	 * @return 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/addtocart.mgt")
	public @ResponseBody JSONObject addtocart(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-addtocart-STARTS");
		List<JSONObject> cartList = JSONArray.fromObject(request.getParameter("data"));
		HttpSession session = request.getSession();
		String apiToken = (String)session.getAttribute("apiToken");
		JSONObject result = null;
		if(apiToken == null){
			List<JSONObject> cartItems = null;
			if(session.getAttribute("cartData") == null){
				cartItems = new ArrayList<JSONObject>();
			}else{
				cartItems = JSONArray.fromObject(session.getAttribute("cartData").toString());
			}
			cartItems.addAll(cartList);
			session.setAttribute("cartData", cartItems.toString());
			result = new JSONObject();
			result.put("status", "success");
		}else{
			String cartId = session.getAttribute("cartId").toString();
			result = _magentoStoreService.addToCart(cartList, apiToken, cartId);
		}
		_LOGGER.info("MagentoStoreController-addtocart-ENDS");
		return result;
	}
	
	/**
	 * This method fetches cartItems
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/getcartitems.mgt")
	public @ResponseBody JSONObject getCartItems(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-getProduct-STARTS");
		HttpSession session = request.getSession();
		JSONObject result = null;
		String apiToken = (String)session.getAttribute("apiToken");
		
		if(apiToken == null){
			String cartData = (String)session.getAttribute("cartData");
			result = new JSONObject();
			result.put("status", "success");
			result.put("data", cartData == null ? "[]" : cartData);
		}else{
			result = _magentoStoreService.getCartData(apiToken);
			if(result.getString("status").equals("success")){
				result.put("data", result.getJSONObject("data").getJSONArray("items"));
			}
		}
		_LOGGER.info("MagentoStoreController-getProduct-ENDS");
		return result;
	}
	
	/**
	 * This method fetches cartItems
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/removefromcart.mgt")
	public @ResponseBody JSONObject removeFromCart(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-getProduct-STARTS");
		HttpSession session = request.getSession();
		JSONObject result = null;
		String apiToken = (String)session.getAttribute("apiToken");
		
		if(apiToken == null){
			// USER NOT LOGGED IN
			String sku = request.getParameter("sku");
			@SuppressWarnings("unchecked")
			List<JSONObject> cartData = JSONArray.fromObject(session.getAttribute("cartData"));
			for(JSONObject item: cartData){
				if(item.getString("sku").equals(sku)){
					cartData.remove(item);
					session.setAttribute("cartData", cartData.toString());
					break;
				}
			}
			result = new JSONObject();
			result.put("status", "success");
		}else{
			// USER LOGGED IN
			String itemid = request.getParameter("itemId");
			result = _magentoStoreService.removeFromCart(itemid, apiToken);
		}
		
		_LOGGER.info("MagentoStoreController-getProduct-ENDS");
		return result;
	}
	/**
	 * This method does a category search
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/searchpage.mgt")
	public String searchPage(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-searchPage-STARTS");
		/*String searchType = request.getParameter("searchtype");
		String value = request.getParameter("value");
		String condition = request.getParameter("condition");*/
		//JSONObject result = _magentoStoreService.search(searchType, value, condition);
		
		
		
		JSONObject result = searchInCache(request, response);
		request.setAttribute("searchresult", StringEscapeUtils.escapeJavaScript(result.toString()));
		_LOGGER.info("MagentoStoreController-searchPage-ENDS");
		return "searchresult/searchresult";
	}
	
	/**
	 * This request checks the availability of the stock
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/checkinventory.mgt")
	@SuppressWarnings("unchecked")
	public @ResponseBody JSONObject checkInventory(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-getProduct-STARTS");
		List<JSONObject> data = JSONArray.fromObject(request.getParameter("data"));
		JSONObject result = _magentoStoreService.checkInventory(data);
		_LOGGER.info("MagentoStoreController-getProduct-ENDS");
		return result;
	}
	
	/**
	 * This method handles handles checkout confirmation
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/confirmcheckout.mgt" , method=RequestMethod.POST)
	public String confirmCheckout(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-confirmCheckout-STARTS");
		String apiToken = (String) request.getSession().getAttribute("apiToken");
		
		if(apiToken == null){
			return "redirect:/";
		}
		JSONObject confirmPageData = _magentoStoreService.getCartData(apiToken);
		request.setAttribute("cartData", StringEscapeUtils.escapeJavaScript(confirmPageData.getString("data")));
		_LOGGER.info("MagentoStoreController-confirmCheckout-ENDS");
		return "order/confirmation";
	}
	
	/**
	 * This method handles handles checkout confirmation
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/placeorder.mgt" , method=RequestMethod.POST)
	public String placeOrder(HttpServletRequest request,HttpServletResponse response){
		BillingAddress billingAddress = new BillingAddress();
		ShippingAddress shippingAddress = new ShippingAddress();
		String email = (String) request.getSession().getAttribute("userEmail");
		
		String billFname = request.getParameter("billfname");
		String[] billNameArray = billFname.split(" ");
		_LOGGER.info("MagentoStoreController-placeOrder-STARTS"+billFname);
		String billStreet = request.getParameter("billstreet");
		String[] billStreetArray = {billStreet};
		String billAddress = request.getParameter("billaddress");
		String[] billAddrArray = billAddress.split(",");
		String billCountry = request.getParameter("billcountry");
		String billTelephone = request.getParameter("billtelephone");
		billingAddress.setEmail(isNullOrEmpty(email));
		billingAddress.setFirstname(isNullOrEmpty(billNameArray[0]));
		billingAddress.setLastname(isNullOrEmpty(billNameArray[1]));
		billingAddress.setStreet(billStreetArray);
		billingAddress.setCity(isNullOrEmpty(billAddrArray[0]));
		billingAddress.setRegion(isNullOrEmpty(billAddrArray[1]));
		billingAddress.setPostcode(isNullOrEmpty(billAddrArray[2]));
		billingAddress.setCountry_id(isNullOrEmpty(billCountry));
		billingAddress.setTelephone(isNullOrEmpty(billTelephone));
		billingAddress.setRegion_id(Integer.valueOf(isNullOrEmpty(request.getParameter("billRegionId"))));
		billingAddress.setRegion_code(isNullOrEmpty(request.getParameter("billRegionCode")));
		
		String shipFname = request.getParameter("shipfname");
		String[] shipNameArray = shipFname.split(" ");
		String shipStreet = request.getParameter("shipstreet");
		String[] shipStreetArray = {shipStreet};
		String shipAddress = request.getParameter("shipaddress");
		String[] shipAddrArray = shipAddress.split(",");
		String shipCountry = request.getParameter("shipcountry");
		String shipTelephone = request.getParameter("shiptelephone");
		shippingAddress.setEmail(isNullOrEmpty(email));
		shippingAddress.setFirstname(isNullOrEmpty(shipNameArray[0]));
		shippingAddress.setLastname(isNullOrEmpty(shipNameArray[1]));
		shippingAddress.setStreet(shipStreetArray);
		shippingAddress.setCity(isNullOrEmpty(shipAddrArray[0]));
		shippingAddress.setRegion(isNullOrEmpty(shipAddrArray[1]));
		shippingAddress.setPostcode(isNullOrEmpty(shipAddrArray[2]));
		shippingAddress.setCountry_id(isNullOrEmpty(shipCountry));
		shippingAddress.setTelephone(isNullOrEmpty(shipTelephone));
		billingAddress.setRegion_id(Integer.valueOf(isNullOrEmpty(request.getParameter("shipRegionId"))));
		billingAddress.setRegion_code(isNullOrEmpty(request.getParameter("shipRegionCode")));
		
		String poNumber = request.getParameter("ponumber");
		String apiToken = (String) request.getSession().getAttribute("apiToken");
		
		if(apiToken == null){
			return "redirect:/";
		}
		String customer_id = (String) request.getSession().getAttribute("customerId");
		JSONObject result = _magentoStoreService.orderPlacement(apiToken, poNumber, shippingAddress, billingAddress,customer_id);
		if(null!=result&& !result.isEmpty()){
		request.setAttribute("orderId",result.getString("orderId"));
		}else{
			return "checkout/checkout";
		}
		_LOGGER.info("MagentoStoreController-placeOrder-ENDS");
		return "order/orderplacement";
	}
	
	/**
	 * This method gets order details for a customer
	 * @param request
	 * @param response
	 * @return String
	 */
	

	
	/**
	 * This method serves pages 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/showPage.mgt")
	public String showPage(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-showPage-STARTS");
		String redirect = "redirect:/";
		HttpSession session = request.getSession();
		String requestedPage = request.getParameter("param");
		String categoryid =(String) request.getSession().getAttribute("categoryId");
		if(request.getSession().getAttribute("apiToken") == null || requestedPage == null){
			return redirect;
		}
		String customer_id = (String) request.getSession().getAttribute("customerId");
		String apiToken = request.getSession().getAttribute("apiToken").toString();
		ServletContext context = request.getSession().getServletContext();
		
		switch(requestedPage){
			case "searchResult" :
				String keyword=request.getParameter("key");
				_LOGGER.info("LOGGER LOADS FOR SEARCH"+keyword);
				ProductSearch search=new ProductSearch();
				/*categoryid="4";*/
				_LOGGER.info("CatID="+categoryid);
				
				search=_magentoStoreService.searchProduct(keyword,categoryid);
				_LOGGER.info(search.getItems());
				request.setAttribute("categoryProducts", search.getItems());
				redirect="product/categoryproduct";
				break;
				
		/*	case "cart" :
				JSONObject cartData = _magentoStoreService.getCartData(apiToken);
				request.setAttribute("cartData", StringEscapeUtils.escapeJavaScript(cartData.getString("data")));
				redirect = "cart/cart";
				break;
				*/
			case "account" :
				JSONObject userInfo = _magentoStoreService.getUserInfo(apiToken);
				request.setAttribute("userInfo", StringEscapeUtils.escapeJavaScript(userInfo.getString("data")));
				redirect = "account";
				break;
				
			case "myorders" :		
				_LOGGER.info("Magento strore Controller myorder");
				Order order = _magentoStoreService.getOrders(apiToken);
				request.setAttribute("orderInfo",(order.getOrders()!=null)?order.getOrders():"");				
				redirect = "order/myorders";
				break;
			case "QuickOrder" :		
				_LOGGER.info(customer_id);				 
				QuickOrder quickorder = _magentoStoreService.getQuickOrder(customer_id);
				session.setAttribute("quickorderobject", quickorder);
				request.setAttribute("quickorder", quickorder.getOrders());
				
				redirect = "QuickOrder/QuickOrder";
				break;
			case "CategoryProduct" :
				String category = request.getParameter("categoryId");
				categoryProduct= _magentoStoreService.categoryProduct(Integer.valueOf(category));
				request.setAttribute("categoryProducts",categoryProduct.getProducts());
				redirect = "product/categoryproduct";
				break;
			case "inventorycheck" :
				
			session.getAttribute("skuList");
				JSONObject productData = (JSONObject) context.getAttribute("masterData");
				/*JSONObject data = _magentoStoreService.searchInCache(productData.getJSONArray("productList"), "sku", StringUtils.join(skuList,","));*/
				request.setAttribute("allProductsList", StringEscapeUtils.escapeJavaScript(productData.toString()));
				redirect = "inventory/inventory";
				break;
				
			case "checkOut":
				CheckOut checkOutData= _magentoStoreService.getCheckOutData(apiToken);
			String fullName=checkOutData.getCustomer().getFirstname()+" "+checkOutData.getCustomer().getLastname();
			request.setAttribute("fname",fullName);
			request.setAttribute("street",checkOutData.getCustomer().getAddresses().get(0).getStreet()[0]);
			request.setAttribute("address",checkOutData.getCustomer().getAddresses().get(0).getCity()+","+checkOutData.getCustomer().getAddresses().get(0).getRegion().getRegion()+","+checkOutData.getCustomer().getAddresses().get(0).getPostcode()+".");
			request.setAttribute("country",checkOutData.getCustomer().getAddresses().get(0).getCountry_id());
			request.setAttribute("telephone",checkOutData.getCustomer().getAddresses().get(0).getTelephone());
			request.setAttribute("regionId",checkOutData.getCustomer().getAddresses().get(0).getRegion().getRegion_id());
			request.setAttribute("regionCode",checkOutData.getCustomer().getAddresses().get(0).getRegion().getRegion_code());
			request.setAttribute("size",checkOutData.getItems().size() );
			ArrayList<com.wipro.dxp.rest.checkout.bean.Items> array=checkOutData.getItems();

			request.setAttribute("ItemsArray",array);
			redirect ="checkout/checkout";
			break;
		
			case "cart" :
				JSONObject cartInfo = _magentoStoreService.getCart(apiToken);
				
				request.setAttribute("grand",cartInfo.get("cartInfo"));
				request.setAttribute("CartData", cartInfo.get("cartItems"));
				if(cartInfo.get("cartItemsSize")!=null)
				{
				request.setAttribute("cartSize",cartInfo.get("cartItemsSize"));
				session.setAttribute("cartSize",cartInfo.get("cartItemsSize"));
				_LOGGER.info(cartInfo.get(cartInfo.get("cartItemsSize")));
				for(int i=0;i<(int)cartInfo.get("cartItemsSize");i++)
				{
					if(cartInfo.get("image"+i)!="")
					{
					request.setAttribute("image"+i,_sources.getProperty("magento.server.image.path")+cartInfo.get("image"+i));
					_LOGGER.info("image"+i);
					_LOGGER.info(_sources.getProperty("magento.server.image.path"));
					_LOGGER.info(cartInfo.get("image"+i));
					}
					else
					{
						request.setAttribute("image"+i,"");
					}
				}
				}
				else
				{
					request.setAttribute("cartSize","");
				}
				_LOGGER.info((int)request.getAttribute("cartSize"));
				redirect = "cart/cart";
				break;
		
		
	case "deletecart":
		_LOGGER.info("Inside Delete Controller");
		String deleteid=(String) request.getParameter("deleteid");
		_LOGGER.info(deleteid);
		String request1= (String) request.getSession().getAttribute("cartSize").toString();
		_LOGGER.info(request1);
         int productsize=0;
		productsize=Integer.parseInt(request1);
		_LOGGER.info(productsize);
		productsize-=1;
		session.setAttribute("cartSize",productsize);
		_LOGGER.info(productsize);
		JSONObject jsonresponse=_magentoStoreService.deleteRequest(deleteid,apiToken);
		break;				
		case "changepassword":
			
			JSONObject passInfo = _magentoStoreService.getUserInfo(apiToken);
			request.setAttribute("passInfo", StringEscapeUtils.escapeJavaScript(passInfo.getString("data")));
			redirect = "password/changepassword";
			break;
			
       case "productview" :
//			String customer_id1 = (String) request.getSession().getAttribute("customerId");
			_LOGGER.info("MagentoStoreController-showPage-START");
			String productid= request.getParameter("productid");
			Product productview = _magentoStoreService.getProductview(productid);
			session.setAttribute("productid",productid);
			
			//request.setAttribute("view",productview );
			//System.out.println("productlistview");
			
			_LOGGER.info(productid);
			request.setAttribute("sku", productview.getSku());
			request.setAttribute("name", productview.getName());
			request.setAttribute("price", productview.getPrice());	
			request.setAttribute("qty", productview.getQuantity_and_stock_status().getQty());
			request.setAttribute("shortdescription", productview.getShort_description());
			request.setAttribute("image", productview.getSmall_image());
			_LOGGER.info(productview.getShort_description());
			redirect = "productview/productview";
			break;
		case "myprofile" :
			//JSONObject userInfo = _magentoStoreService.getUserInfo(apiToken);
			//request.setAttribute("userInfo", StringEscapeUtils.escapeJavaScript(userInfo.getString("data")));
			_LOGGER.info("MagentoStoreController-myprofile-START");
			JSONObject userInfo1 = _magentoStoreService.getUserInfo(apiToken);
			request.setAttribute("userInfo", StringEscapeUtils.escapeJavaScript(userInfo1.getString("data")));
			redirect = "myprofile/profile";
			break;
		case "orderdetail":
				_LOGGER.info("MagentoStoreController - order detail-start");
				String orderId=request.getParameter("orderid");
				_LOGGER.info(orderId);
				OrderHistory orderInfo=_magentoStoreService.previousOrder(orderId);
				_LOGGER.info(orderInfo);
				Address shippingAddress=orderInfo.getExtension_attributes().getShipping_assignments().get(0).getShipping().getAddress();
				request.setAttribute("orderhistory", orderInfo.getItems());
				request.setAttribute("subtotal", orderInfo.getSubtotal());
				request.setAttribute("grandtotal", orderInfo.getGrand_total());
				request.setAttribute("billing-fullname", isNullOrEmpty(orderInfo.getBilling_address().getFirstname()+" "+orderInfo.getBilling_address().getLastname() ));
				request.setAttribute("billing-city", isNullOrEmpty(orderInfo.getBilling_address().getCity()));
				request.setAttribute("billing-region", isNullOrEmpty(orderInfo.getBilling_address().getRegion()));
				request.setAttribute("billing-postcode", isNullOrEmpty(orderInfo.getBilling_address().getCountry_id()+"-"+orderInfo.getBilling_address().getPostcode()));
				request.setAttribute("shipping-fullname",isNullOrEmpty(shippingAddress.getFirstname()+" "+shippingAddress.getLastname() ));
				request.setAttribute("shipping-city", isNullOrEmpty(shippingAddress.getCity()));
				request.setAttribute("shipping-region", isNullOrEmpty(shippingAddress.getRegion()));
				request.setAttribute("shipping-postcode", isNullOrEmpty(shippingAddress.getCountry_id()+"-"+shippingAddress.getPostcode()));
				redirect="order/orderdetail";
				break;
		case "addtobasket":
			String productId=(String)session.getAttribute("productid");
			
			_LOGGER.info("MagentoStoreController-addtobasket-START");
			JSONObject add=new JSONObject();
			String qty=(String) request.getParameter("qty");
			add=_magentoStoreService.addrequest(productId,qty,apiToken);
			_LOGGER.info(add.get("status"));
			if(add.get("status")=="success")
			{
					JSONObject cartInfo1 = _magentoStoreService.getCart(apiToken);
					_LOGGER.info("Product View cart_---"+cartInfo1);
					request.setAttribute("grand",cartInfo1.get("cartInfo"));
					request.setAttribute("CartData", cartInfo1.get("cartItems"));
					redirect = "cart/cart";
				
			}
			else
			{
				redirect = "productview/productview";
			}
			break;
		}
		_LOGGER.info(redirect);
		_LOGGER.info("MagentoStoreController-showPage-ENDS");
		return redirect;
	}
	
	
	

/*****************************************************************************************************************************************************************
	
	
	
	
	
	
	/**
	 * This method returns all data necessary for landing page
	 * @param request
	 * @param response
	 * @return String
	 */
	@RequestMapping(value="/getlandingpagedata.mgt")
	public @ResponseBody JSONObject getLandingPageData(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-getLandingPageData-STARTS");
		ServletContext context = request.getSession().getServletContext();
		JSONObject result = null;
		JSONObject contextData = (JSONObject)context.getAttribute("masterData");
		if(contextData != null){
			result = contextData;
		}else{
			result = _magentoStoreService.fetchLandingData();
			context.setAttribute("masterData", result);
		}
		_LOGGER.info("MagentoStoreController-getLandingPageData-ENDS");
		return result;
	}
	
	/**
	 * This method returns all data necessary for landing page
	 * @param request
	 * @param response
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/searchproducts.mgt")
	public @ResponseBody JSONObject searchInCache(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-searchInCache-STARTS");
		ServletContext context = request.getSession().getServletContext();
		JSONObject productList = (JSONObject) context.getAttribute("masterData");
		String key = request.getParameter("searchtype");
		String value = request.getParameter("value");
		
		JSONObject result = _magentoStoreService.searchInCache((List<JSONObject>)productList.get("productList"), key, value);
		_LOGGER.info("MagentoStoreController-searchInCache-ENDS");
		return result;
	}
	
	/**
	 * This method returns all data necessary for landing page
	 * @param request
	 * @param response
	 * @return String
	 */
	@RequestMapping(value="/clearcache.mgt")
	public @ResponseBody JSONObject clearCache(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-searchInCache-STARTS");
		ServletContext context = request.getSession().getServletContext();
	
		JSONObject data = _magentoStoreService.fetchLandingData();
		context.setAttribute("masterData", data);
		
		JSONObject result = new JSONObject();
		result.put("status", "success");
		_LOGGER.info("MagentoStoreController-searchInCache-ENDS");
		return result;
	}
	
	/**
	 * This method fetches all categories for the current store
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/fetchcategories.mgt")
	public @ResponseBody JSONObject fetchCategories(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-fetchCategories-STARTS");
		ServletContext context = request.getSession().getServletContext();
		JSONObject sessionData = (JSONObject)context.getAttribute("masterData");
		JSONObject result = new JSONObject();
		result.put("status", "success");
		if (sessionData.getString("categories")!= null)
		result.put("categories", sessionData.getString("categories"));
		_LOGGER.info("MagentoStoreController-fetchCategories-ENDS");
		return result;
	}
	
	/**
	 * This method saves the sku in list
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/listoperation.mgt")
	public @ResponseBody JSONObject addToList(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-addToList-STARTS");
		JSONObject result = new JSONObject();
		HttpSession session = request.getSession();
		String sku = request.getParameter("sku");
		String operation = request.getParameter("operation");
		
		Set<String> skuList = (Set<String>)session.getAttribute("skuList");
		if(skuList == null){
			skuList = new HashSet<String>();
		}
		
		if(operation.equals("add")){
			skuList.add(sku);
		}else{
			skuList.remove(sku);
		}
		
		session.setAttribute("skuList",skuList);
		result.put("status", "success");
		_LOGGER.info("MagentoStoreController-addToList-ENDS");
		return result;
	}
	/**
	 * This method authenticates user
	 * @param request
	 * @param response
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/loadcategories.mgt")
	public @ResponseBody Categories loadCategories(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-loadCategories-STARTS");		
		categories= _magentoStoreService.loadCategories();
		request.setAttribute("maincategories", categories.getChildren_data());
		_LOGGER.info("MagentoStoreController-loadCategories-ENDS");
		return categories;
	}
	
	
	@RequestMapping(value="/updatecart.mgt")
	public String updateCart(HttpServletRequest request,HttpServletResponse response){
		String redirect = "redirect:/";

		_LOGGER.info("MagentoStoreController-CartUpdation-STARTS");

		String pcount=request.getParameter("productcount");
		_LOGGER.info("dsckjdnciusjdkalclkjdsasfvsf"+pcount);

		//int count=Integer.parseInt(pcount);
		//_LOGGER.info(count);
		if(pcount!=null)
		{
			int cartCount=Integer.parseInt((null!=pcount&& !pcount.isEmpty())?pcount:"");
			ArrayList<CartItem> cartItems=new ArrayList<CartItem>();

			UpdateCartItems updatedCart=new UpdateCartItems();
			_LOGGER.info("product count"+cartCount);
			for(int i=0;i<cartCount;i++)
			{	
				String qty=request.getParameter("quantity"+i);
				_LOGGER.info("quantity"+i+" "+qty);
				if(null!=qty)
				{
					CartItem cartItem=new CartItem();
					int a=Integer.parseInt(qty);
					cartItem.setQty(a);
					_LOGGER.info(a);

					String item=request.getParameter("itemId"+i);
					_LOGGER.info("itemid"+i+" "+item);

					int b=Integer.parseInt(item);
					cartItem.setItemId(b);
					_LOGGER.info(b);			
					String product=request.getParameter("productId"+i);
					_LOGGER.info("productid"+i+" "+product);

					int c=Integer.parseInt(product);
					cartItem.setProductId(c);
					_LOGGER.info(c);
					cartItems.add(cartItem);
				}		
			}
			updatedCart.setUpdateCart(cartItems);
			Gson json=new Gson();
			String cartinfo=json.toJson(updatedCart);
			_LOGGER.info(cartinfo);
			String apiToken = request.getSession().getAttribute("apiToken").toString();
			String basketrequest=_magentoStoreService.UpdateRequest(apiToken,cartinfo);
			_LOGGER.info(basketrequest);
			if(basketrequest=="success")
			{
				_LOGGER.info(basketrequest);
				viewCart(request,apiToken);


			}
			_LOGGER.info("MagentoStoreController-CartUpdation-ENDS");
			/*	try {
			response.sendRedirect("cart/cart.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/  

			
		}
		else
		{
			request.setAttribute("cartSize","");	
			_LOGGER.info("Inside else");
			_LOGGER.info("Inside");
		}
		return "cart/cart";
	}
       
	
	public void viewCart(HttpServletRequest request,String apiToken)
	{
		_LOGGER.info("inside view cart");
		JSONObject cartInfo = _magentoStoreService.getCart(apiToken);
		request.setAttribute("grand",cartInfo.get("cartInfo"));
		_LOGGER.info("kjdsvbhs");
		request.setAttribute("CartData", cartInfo.get("cartItems"));
		request.setAttribute("cartSize",cartInfo.get("cartItemsSize"));
		
		if(cartInfo.get("cartItemsSize")!=null)
		{
		request.setAttribute("cartSize",cartInfo.get("cartItemsSize"));
		_LOGGER.info(cartInfo.get(cartInfo.get("cartItemsSize")));
		for(int i=0;i<(int)cartInfo.get("cartItemsSize");i++)
		{
			if(cartInfo.get("image"+i)!="")
			{
			request.setAttribute("image"+i,_sources.getProperty("magento.server.image.path")+cartInfo.get("image"+i));
			_LOGGER.info("image"+i);
			_LOGGER.info(_sources.getProperty("magento.server.image.path"));
			_LOGGER.info(cartInfo.get("image"+i));
			}
			else
			{
				request.setAttribute("image"+i,"");
			}
		}
		}
		else
		{
			request.setAttribute("cartSize","");
		}
		_LOGGER.info((int)request.getAttribute("cartSize"));
		
		
	}
	
	/**
	 * @return the categories
	 */
	public Categories getCategories() {
		return categories;
	}

	/**
	 * @param categories the categories to set
	 */
	public void setCategories(Categories categories) {
		this.categories = categories;
	}

	/**
	 * @return the categoryProduct
	 */
	public CategoryProduct getCategoryProduct() {
		return categoryProduct;
	}

	/**
	 * @param categoryProduct the categoryProduct to set
	 */
	public void setCategoryProduct(CategoryProduct categoryProduct) {
		this.categoryProduct = categoryProduct;
	}
	
	@RequestMapping(value="/addbasket.mgt")
	public String addbasket(HttpServletRequest request,HttpServletResponse response){
		_LOGGER.info("MagentoStoreController-Add basket-STARTS");
		String apiToken=(String)request.getSession().getAttribute("apiToken");
		String selectedproduct=request.getParameter("selectedproductdata");
		JSONObject basket=new JSONObject();
		selectedproduct=selectedproduct.substring(0, selectedproduct.length()-1);
		ArrayList<CartItems> cartitemlist=addtoBasket(selectedproduct);
		_LOGGER.info(selectedproduct);
		basket=_magentoStoreService.basketrequest(cartitemlist,apiToken);
		_LOGGER.info(basket.get("status"));
		if(basket.get("status")=="success")
		{
			_LOGGER.info("cart");
			JSONObject cartInfo1 = _magentoStoreService.getCart(apiToken);
			_LOGGER.info("QuickOrder cart_---"+cartInfo1);
			request.setAttribute("grand",cartInfo1.get("cartInfo"));
			request.setAttribute("CartData", cartInfo1.get("cartItems"));
			request.setAttribute("cartSize",cartInfo1.get("cartItemsSize"));
			request.getSession().setAttribute("cartSize",cartInfo1.get("cartItemsSize"));
			
			return "cart/cart";
		}
		else
		{
			_LOGGER.info("quickOrder");
			return "QuickOrder/QuickOrder";
		}
		
	}

	public ArrayList<CartItems> addtoBasket(String selectedproduct){
		_LOGGER.info("MagentoStoreController-basket-STARTS");
		
		ArrayList<CartItems> cartitemlist=new ArrayList<CartItems>();
		Cart cart=new Cart();
		if(selectedproduct.length()!=0) {
			String selecteddata[]=selectedproduct.split(",");
			for(int i=0;i<selecteddata.length;i++) {
					String productandqty[]=selecteddata[i].split("_");
							CartItems cartitem=new CartItems();
								_LOGGER.info(productandqty[0]);
								cartitem.setProductId(Integer.parseInt(productandqty[0]));
								int q=(int) Math.round(Float.valueOf(productandqty[1]));
								cartitem.setQty(q);					
						cartitemlist.add(cartitem);
				
			}
		}
	return cartitemlist;
	}
	


	public String isNullOrEmpty(String value){
		String finalValue= "";
		finalValue= (null!=value && !value.isEmpty())?value:"";
		return finalValue;
	}

}
