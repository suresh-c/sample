/*
 * This software is the confidential and proprietary information of
 * Wipro. You shall not disclose such Confidential Information and 
 * shall use it only in accordance with the terms of the license 
 * agreement you entered into with Wipro.
 *
 */
package com.wipro.magentostore.util;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Properties;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wipro.dxp.rest.categories.response.CategoryProduct;
import com.wipro.dxp.rest.categories.response.MediaGallery;
import com.wipro.dxp.rest.categories.response.Products;
import com.wipro.dxp.rest.productview.bean.Product;
import com.wipro.dxp.search.bean.Items;
import com.wipro.dxp.search.bean.ProductSearch;

/**
 * 
 * This class acts as rest api client for magento rest api's.
 *
 */
@Component("magentoApiClient")
public class MagentoApiClient {

	/**
	 * Autowiring sources
	 */
	@Autowired
	private Properties _sources;

	/**
	 * Registering logger
	 */
	private static final Logger _LOGGER = Logger.getLogger(MagentoApiClient.class);

	/**
	 * @param requestString
	 * @param method
	 * @param data
	 * @param token
	 * @return
	 * Method will make http requests for magento rest api's
	 * 
	 */
	public JSONObject makeRequest(String requestString,String method, String data,String token){
		_LOGGER.info("MagentoApiClient - makeRequest - STARTS");
		JSONObject result = new JSONObject();
		try{
			String urlString = _sources.getProperty("magento.base.url")+requestString;
			URL url = new URL(urlString);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Content-Type", "application/json");

			if(token != null){
				connection.setRequestProperty("Authorization", "Bearer "+token);
			}else{
				connection.setRequestProperty("Authorization", "Bearer "+_sources.getProperty("magento.service.token"));
			}
			connection.setRequestMethod(method);
			if(method.equalsIgnoreCase("POST")|| method.equalsIgnoreCase("PUT")){
				connection.setDoOutput(true);
				OutputStream outStream = connection.getOutputStream();
				if(data != null){
					outStream.write(data.getBytes());
				}
				outStream.flush();
				outStream.close();
			}

			int responseCode = connection.getResponseCode(); 
			_LOGGER.info("urlString:"+urlString);
			_LOGGER.info("method:"+method);
			_LOGGER.info("responseCode:"+responseCode);

			if(responseCode == 200){
				result.put("status", "success");
				result.put("data", IOUtils.toString(connection.getInputStream()).replaceAll("null", "\"N/A\""));
			}else{
				result.put("status", "failed");
				String error = IOUtils.toString(connection.getErrorStream()).replaceAll("null", "\"N/A\"");
				result.put("data", error);
				_LOGGER.info(error);
			}
			connection.disconnect();
		}
		catch(Exception e){
			e.printStackTrace();
			result.put("status", "failed");
		}
		_LOGGER.info("MagentoApiClient - makeRequest - ENDS");
		return result;
	}	
	/**
	 * 
	 * @param requestString
	 * @param requestMethod
	 * @param data
	 * @param request
	 * @return
	 * 
	 * This method fetches data from the Magento
	 *//*
	public JSONObject requestData(String requestString,String requestMethod, String data, HttpServletRequest request){
		JSONObject response = null;
		try{
			String token = (String)request.getSession().getAttribute("apitoken");

			// NEW SESSION
			if(token == null){
				JSONObject tokenResponse = makeRequest("/V1/integration/admin/token", "POST", getAdminCredentials(), null);
				token = tokenResponse.getString("data");
				request.getSession().setAttribute("apitoken", token);
			}
			response = makeRequest(requestString,requestMethod,data,token);

			// TOKEN EXPIRED
			if(response.containsKey("message") && response.getString("message").equals("Token Expired")){
				JSONObject tokenResponse = makeRequest("/V1/integration/admin/token", "POST", getAdminCredentials(), null);
				token = tokenResponse.getString("data");
				request.getSession().setAttribute("apitoken", token);
				response = makeRequest(requestString,requestMethod,data,token);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			response = new JSONObject();
			response.put("status", "failed");
		}
		return response;
	}*/
	public void setMediaFiles(CategoryProduct productsResult) {
		String imageServePath = _sources.getProperty("magento.server.image.path");

		if(null!=productsResult && !isNullOrEmpty(productsResult.getProducts())){
			for(Products product : productsResult.getProducts()){
				String smallImage = product.getSmall_image();
				if(null!=smallImage && !smallImage.isEmpty()){
					product.setSmall_image("");
					product.setSmall_image(imageServePath.concat(smallImage));
					_LOGGER.info("setMediaFiles---product--"+product.getSmall_image());
				}else{
					product.setSmall_image("");
				}
				if(!isNullOrEmpty(product.getMedia_gallery())){
					for(MediaGallery gallery:product.getMedia_gallery()){
						String filePath = gallery.getFile();
						_LOGGER.info("setMediaFiles---filePath--"+filePath);
						if(null!=filePath && !filePath.isEmpty()){
							gallery.setFile("");
							gallery.setFile(imageServePath.concat(filePath));
							_LOGGER.info("setMediaFiles---gallery--"+gallery.getFile());
						}else{
							gallery.setFile("");							
						}
					}
				}
				_LOGGER.info("setMediaFiles---smallImage--"+product.getSmall_image());
			} 
		}

	}
	
	public void setMediaFilesSearch(ProductSearch search) {
		String imageServePath = _sources.getProperty("magento.server.image.path");

		if(null!=search && !isNullOrEmpty(search.getItems())){
			for(Items product : search.getItems()){
				String smallImage = product.getSmall_image();
				if(null!=smallImage && !smallImage.isEmpty()){
					product.setSmall_image("");
					product.setSmall_image(imageServePath.concat(smallImage));
					_LOGGER.info("setMediaFiles---product--"+product.getSmall_image());
				}else{
					product.setSmall_image("");
				}	
								
				_LOGGER.info("setMediaFiles---smallImage--"+product.getSmall_image());
			} 
		}

	}
	
	
	public boolean isNullOrEmpty(List value){
		boolean result = false;
		result = (null==value || value.isEmpty()) ? true : false;
		return result;
	}
	public void setImages(Product product) {
		String imageServePath = _sources.getProperty("magento.server.image.path");

		String imagefile = product.getSmall_image();
		if(null!=imagefile && !imagefile.isEmpty()){
			product.setSmall_image("");
			product.setSmall_image(imageServePath.concat(imagefile));
			_LOGGER.info(product.getSmall_image());
		}
	}
}


