/**
 * This software is the confidential and proprietary information of
 * Wipro. You shall not disclose such Confidential Information and 
 * shall use it only in accordance with the terms of the license 
 * agreement you entered into with Wipro.
 *
 */

package com.wipro.magentostore.interceptor;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * This class intercepts each and every request to the application. Checks for a
 * valid session and redirects as per the case
 */
public class RequestInterceptor extends HandlerInterceptorAdapter {
	/**
	 * private static logger
	 */
	private static final Logger _LOGGER = Logger.getLogger(RequestInterceptor.class);
	

	public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler)throws ServletException, IOException {
		_LOGGER.debug("RequestInterceptor-preHandle()-STARTS");
		response.setHeader("X-FRAME-OPTIONS", "DENY");
		String receivedURL = request.getServletPath() + "?"	+ request.getQueryString();
		_LOGGER.info("RECEIVED URL::"+receivedURL);
		boolean status = false;
		
		HttpSession session = request.getSession();
		if(session.getAttribute("apiToken") != null ||
			(receivedURL.contains("login") ||
			 receivedURL.contains("landingpagedata")||
			 receivedURL.contains("requestPassword")||
			 receivedURL.contains("updateresetpassword")||
			 receivedURL.contains("resetpassword")||
			 receivedURL.contains("forgotpassword")||
			 receivedURL.contains("changepassword")||
			 receivedURL.contains("updatechangepassword"))){
			status = true;
		}else{
			status = false;
			response.sendRedirect(request.getContextPath()+"/?error=unauthorized");
		}
		//status =  true;
		
		_LOGGER.debug("RequestInterceptor-preHandle()-ENDS" + status);
		return status;
	}
}