/**
 * 
 */
package com.wipro.dxp.backend.csv.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.dxp.backend.csv.bean.CSVProduct;
import com.wipro.dxp.backend.csv.bean.CSVProductFinal;
import com.wipro.dxp.backend.csv.bean.CSVcmriBean;

/**
 * @author JA294967
 *
 */
public class BackendCSVDAO {
	Connection con = null;
	private static SessionFactory factory; 
	public BackendCSVDAO(){
		try {
			factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/magento2","root","");  
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		//		System.out.println("DriverManager::"+DriverManager.getConnection("jdbc:mysql://localhost:8081/phpmyadmin/mysql","root","root"));

	}

	public void insertToCRMI(ArrayList<CSVcmriBean> sapcmrilist){
		try{
			System.out.println("insertToCRMI::");
			deleteAllRecords("cmri");
			//here sonoo is database name, root is username and password
			Session session=factory.openSession();

			//creating transaction object
			Transaction t=session.beginTransaction();
			session.clear();
			for(CSVcmriBean sapCMRI : sapcmrilist){
				session.saveOrUpdate(sapCMRI);
			}
			t.commit();//transaction is commited
			session.close(); 
		}catch(Exception e){ System.out.println(e);}  

	}

	public void insertToProductMaterial(ArrayList<CSVProduct> prodMatlist){
		try{
			System.out.println("insertToCRMI::");
			deleteAllRecords("product_material");
			//here sonoo is database name, root is username and password
			Session session=factory.openSession();

			//creating transaction object
			Transaction t=session.beginTransaction();
			for(CSVProduct prodMat : prodMatlist){
				session.saveOrUpdate(prodMat);
			}
			t.commit();//transaction is commited
			session.close(); 
			
		}catch(Exception e){ System.out.println(e);}  

	}

	public void insertToFinalProductMaterial(ArrayList<CSVProductFinal> finalProdList){
		try{
			System.out.println("insertToFinalProductMaterial::"+finalProdList.size());
			deleteAllRecords("final_product_material");
			//here sonoo is database name, root is username and password
			Session session=factory.openSession();
			
			//creating transaction object
			Transaction t=session.beginTransaction();
			
			for(CSVProductFinal finalProd : finalProdList){
				session.saveOrUpdate(finalProd);
			}
			t.commit();//transaction is commited
			session.close(); 
		}catch(Exception e){ System.out.println(e);}  

	}
	public ArrayList<CSVProductFinal> retrieveMerged(){
		System.out.println("retrieveMerged::");
		ArrayList<CSVProductFinal> finalProdList = new ArrayList<CSVProductFinal>();
		try{			
			PreparedStatement statement = con.prepareStatement("select c.SKU,c.PRICE,p.ATTRIBUTE_SET_CODE,p.PRODUCT_TYPE,p.PRODUCT_WEBSITES,p.NAME,p.WEIGHT,p.PRODUCT_ONLINE,p.TAX_CLASS_NAME,p.VISIBILITY,p.MATERIAL_ID,p.MATERIAL_NAME,p.QTY,p.OUT_OF_STOCK_QTY,p.IS_IN_STOCK,p.ADDITIONAL_FIELD1,p.ADDITIONAL_FIELD2,p.ADDITIONAL_FIELD3,p.ADDITIONAL_FIELD4,p.ADDITIONAL_FIELD5 from cmri c,product_material p where c.SKU=p.SKU");
			ResultSet resultSet = statement.executeQuery();
			if(null!=resultSet){
				while(resultSet.next()){
					CSVProductFinal finalProd = new CSVProductFinal();
					finalProd.setSku(resultSet.getString("SKU"));
					finalProd.setPrice(resultSet.getDouble("PRICE"));
					finalProd.setAttribute_set_code(resultSet.getString("ATTRIBUTE_SET_CODE"));
					finalProd.setProduct_type(resultSet.getString("PRODUCT_TYPE"));
					finalProd.setProduct_websites(resultSet.getString("PRODUCT_WEBSITES"));
					finalProd.setName(resultSet.getString("NAME"));
					finalProd.setWeight(resultSet.getInt("WEIGHT"));
					finalProd.setProduct_online(resultSet.getString("PRODUCT_ONLINE"));
					finalProd.setTax_class_name(resultSet.getString("TAX_CLASS_NAME"));
					finalProd.setVisibility(resultSet.getString("VISIBILITY"));
					finalProd.setMaterial_id(resultSet.getString("MATERIAL_ID"));
					finalProd.setMaterial_name(resultSet.getString("MATERIAL_NAME"));
					finalProd.setQty(resultSet.getInt("QTY"));
					finalProd.setOut_of_stock_qty(resultSet.getInt("OUT_OF_STOCK_QTY"));
					finalProd.setIs_in_stock(resultSet.getInt("IS_IN_STOCK"));
					finalProd.setAdditionalField1(resultSet.getString("ADDITIONAL_FIELD1"));
					finalProd.setAdditionalField2(resultSet.getString("ADDITIONAL_FIELD2"));
					finalProd.setAdditionalField3(resultSet.getString("ADDITIONAL_FIELD3"));
					finalProd.setAdditionalField4(resultSet.getString("ADDITIONAL_FIELD4"));
					finalProd.setAdditionalField5(resultSet.getString("ADDITIONAL_FIELD5"));
					finalProdList.add(finalProd);
				}
			}
			con.close();  
		}catch(Exception e){ System.out.println(e);} 
		System.out.println(finalProdList.get(0).getSku()+" ******size");
		return finalProdList;
	}

	public ArrayList<CSVProductFinal> getFinalList(){
		ArrayList<CSVProductFinal> finalProdList = new ArrayList<CSVProductFinal>();
		Session session=factory.openSession();		
		//creating transaction object
		Transaction t=session.beginTransaction();
		Criteria cr = session.createCriteria(CSVProductFinal.class);
		finalProdList = (ArrayList<CSVProductFinal>) cr.list();
		t.commit();//transaction is commited
		session.close(); 
		return finalProdList;
	}
	public void deleteAllRecords(String tableName){
		System.out.println("deleteAllRecords::");

		try{			
			PreparedStatement statement = con.prepareStatement("select * from "+tableName);
			ResultSet rs = statement.executeQuery();
			if(null!= rs && rs.next()){
				PreparedStatement statement1 = con.prepareStatement("delete from "+tableName);
				//statement.setString(1, tableName);
				int result = statement1.executeUpdate();
				if(result!=0){
					System.out.println("Deletion is successful");
				}else{
					System.out.println("Deletion is unsuccessful");
				}
			}
			con.close();  
		}catch(Exception e){ System.out.println(e);}  

	}
	public boolean isNullOrEmpty(List value){
		boolean result = false;
		result = (null==value || value.isEmpty()) ? true : false;
		return result;
	}
}
