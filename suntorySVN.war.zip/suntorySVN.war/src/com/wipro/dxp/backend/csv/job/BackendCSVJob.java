package com.wipro.dxp.backend.csv.job;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.wipro.dxp.backend.csv.bean.CSVProduct;
import com.wipro.dxp.backend.csv.bean.CSVProductFinal;
import com.wipro.dxp.backend.csv.bean.CSVcmriBean;
import com.wipro.dxp.backend.csv.dao.BackendCSVDAO;


public class BackendCSVJob
{
	public static void main(String[] args)
	{


		String sapCmriFileName = "D:/SuntoryPOC/Docs/Sample_CSVs/Test-SAP-sample-format(from).csv";
		String prodFileName = "D:/SuntoryPOC/Docs/Sample_CSVs/Magento-required-format(to).csv";
		String mergedFileName = "D:/SuntoryPOC/Docs/Sample_CSVs/Merged.csv";
		File mergedFile = new File(mergedFileName);
		if(!mergedFile.exists()){
			try {
				mergedFile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		CsvMapper mapper = new CsvMapper();
		CsvSchema schema = CsvSchema.emptySchema().withHeader().withColumnSeparator(',');
		MappingIterator<CSVcmriBean> sapCmriIt = null;
		MappingIterator<CSVProduct> prodIt = null;
		try {
			sapCmriIt = mapper.reader(CSVcmriBean.class).with(schema).readValues(new File(sapCmriFileName));
			prodIt = mapper.reader(CSVProduct.class).with(schema).readValues(new File(prodFileName));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<CSVcmriBean>  sapList = new ArrayList<CSVcmriBean>();
		while (sapCmriIt.hasNext()){
			CSVcmriBean row = sapCmriIt.next();
			sapList.add(row);
		}
		
		ArrayList<CSVProduct>  magentoList = new ArrayList<CSVProduct>();
		while (prodIt.hasNext()){
			CSVProduct row = prodIt.next();
			magentoList.add(row);
		}
		BackendCSVDAO csvdao = new BackendCSVDAO();	
		BackendCSVDAO csvdao1 = new BackendCSVDAO();	
		BackendCSVDAO csvdao2 = new BackendCSVDAO();
		BackendCSVDAO csvdao3 = new BackendCSVDAO();
		BackendCSVDAO csvdao4 = new BackendCSVDAO();
		csvdao.insertToCRMI(sapList);
		csvdao1.insertToProductMaterial(magentoList);
		ArrayList<CSVProductFinal> finalProdList = csvdao2.retrieveMerged();
		csvdao3.insertToFinalProductMaterial(finalProdList);
		ArrayList<CSVProductFinal> finalList  = csvdao4.getFinalList();
		writeToCSV(finalList,mergedFile);
//		try {
//			updateMagentoCSVWithSapCSV(sapList,magentoList);
//		} catch (IntrospectionException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		//writeToCSV(magentoList,mergedFile);
	}


	private static void writeToCSV(ArrayList<CSVProductFinal> finalList, File mergedFile) {
		// TODO Auto-generated method stub
		CsvMapper mapper = new CsvMapper();
		CsvSchema schema = mapper.schemaFor(CSVProductFinal.class);
		ObjectWriter objWriter= mapper.writer(schema.withUseHeader(true));
		try {
			FileOutputStream outputStream = new FileOutputStream(mergedFile);
			objWriter.writeValue(outputStream, finalList);
			outputStream.close();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}


//	public static void updateMagentoCSVWithSapCSV(ArrayList<CSVcmriBean> sapList, ArrayList<CSVProduct> magentoList) throws IntrospectionException {
//		// TODO Auto-generated method stub
//		CSVProductComparator productComparator = new CSVProductComparator();
//		for(CSVcmriBean sap : sapList){
//			for(CSVProduct magento : magentoList){
//				if(sap.getSku().equals(magento.getSku())){
//					productComparator.compareObjectsByProperty(sap,magento);
//				}
//			}
//		}
//	}
}