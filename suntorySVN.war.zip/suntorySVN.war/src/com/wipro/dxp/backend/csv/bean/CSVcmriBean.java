/**
 * 
 */
package com.wipro.dxp.backend.csv.bean;

import java.io.Serializable;

/**
 * @author JA294967
 *
 */
public class CSVcmriBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String sku = "";				
	String material_id = "";
	String material_name = "";
	double price;
	String additionalField1 = "";
	String additionalField2 = "";
	String additionalField3 = "";
	String additionalField4 = "";
	String additionalField5 = "";
	/**
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}
	/**
	 * @param sku the sku to set
	 */
	public void setSku(String sku) {
		this.sku = sku;
	}
	/**
	 * @return the material_id
	 */
	public String getMaterial_id() {
		return material_id;
	}
	/**
	 * @param material_id the material_id to set
	 */
	public void setMaterial_id(String material_id) {
		this.material_id = material_id;
	}
	/**
	 * @return the material_name
	 */
	public String getMaterial_name() {
		return material_name;
	}
	/**
	 * @param material_name the material_name to set
	 */
	public void setMaterial_name(String material_name) {
		this.material_name = material_name;
	}
	
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the additionalField1
	 */
	public String getAdditionalField1() {
		return additionalField1;
	}
	/**
	 * @param additionalField1 the additionalField1 to set
	 */
	public void setAdditionalField1(String additionalField1) {
		this.additionalField1 = additionalField1;
	}
	/**
	 * @return the additionalField2
	 */
	public String getAdditionalField2() {
		return additionalField2;
	}
	/**
	 * @param additionalField2 the additionalField2 to set
	 */
	public void setAdditionalField2(String additionalField2) {
		this.additionalField2 = additionalField2;
	}
	/**
	 * @return the additionalField3
	 */
	public String getAdditionalField3() {
		return additionalField3;
	}
	/**
	 * @param additionalField3 the additionalField3 to set
	 */
	public void setAdditionalField3(String additionalField3) {
		this.additionalField3 = additionalField3;
	}
	/**
	 * @return the additionalField4
	 */
	public String getAdditionalField4() {
		return additionalField4;
	}
	/**
	 * @param additionalField4 the additionalField4 to set
	 */
	public void setAdditionalField4(String additionalField4) {
		this.additionalField4 = additionalField4;
	}
	/**
	 * @return the additionalField5
	 */
	public String getAdditionalField5() {
		return additionalField5;
	}
	/**
	 * @param additionalField5 the additionalField5 to set
	 */
	public void setAdditionalField5(String additionalField5) {
		this.additionalField5 = additionalField5;
	}

}
