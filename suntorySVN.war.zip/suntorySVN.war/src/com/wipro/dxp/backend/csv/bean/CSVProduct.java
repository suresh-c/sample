/**
 * 
 */
package com.wipro.dxp.backend.csv.bean;

import java.io.Serializable;

/**
 * @author JA294967
 *
 */
public class CSVProduct implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int qty;
	int weight;
	double price;
	int out_of_stock_qty;
	int is_in_stock;
	String sku = "";				
	String material_id = "";
	String material_name = "";	
	String attribute_set_code = "";	
	String product_type = "";
	String product_websites	="";
	String name = "";	
	String product_online="";
	String tax_class_name="";
	String visibility="";	
	String additionalField1 = "";
	String additionalField2 = "";
	String additionalField3 = "";
	String additionalField4 = "";
	String additionalField5 = "";
	/**
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}
	/**
	 * @param sku the sku to set
	 */
	public void setSku(String sku) {
		this.sku = sku;
	}
	/**
	 * @return the material_id
	 */
	public String getMaterial_id() {
		return material_id;
	}
	/**
	 * @param material_id the material_id to set
	 */
	public void setMaterial_id(String material_id) {
		this.material_id = material_id;
	}
	/**
	 * @return the material_name
	 */
	public String getMaterial_name() {
		return material_name;
	}
	/**
	 * @param material_name the material_name to set
	 */
	public void setMaterial_name(String material_name) {
		this.material_name = material_name;
	}
	
	/**
	 * @return the qty
	 */
	public int getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(int qty) {
		this.qty = qty;
	}
	/**
	 * @return the attribute_set_code
	 */
	public String getAttribute_set_code() {
		return attribute_set_code;
	}
	/**
	 * @param attribute_set_code the attribute_set_code to set
	 */
	public void setAttribute_set_code(String attribute_set_code) {
		this.attribute_set_code = attribute_set_code;
	}
	/**
	 * @return the product_type
	 */
	public String getProduct_type() {
		return product_type;
	}
	/**
	 * @param product_type the product_type to set
	 */
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	/**
	 * @return the product_websites
	 */
	public String getProduct_websites() {
		return product_websites;
	}
	/**
	 * @param product_websites the product_websites to set
	 */
	public void setProduct_websites(String product_websites) {
		this.product_websites = product_websites;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the weight
	 */
	public int getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}
	/**
	 * @return the product_online
	 */
	public String getProduct_online() {
		return product_online;
	}
	/**
	 * @param product_online the product_online to set
	 */
	public void setProduct_online(String product_online) {
		this.product_online = product_online;
	}
	/**
	 * @return the tax_class_name
	 */
	public String getTax_class_name() {
		return tax_class_name;
	}
	/**
	 * @param tax_class_name the tax_class_name to set
	 */
	public void setTax_class_name(String tax_class_name) {
		this.tax_class_name = tax_class_name;
	}
	/**
	 * @return the visibility
	 */
	public String getVisibility() {
		return visibility;
	}
	/**
	 * @param visibility the visibility to set
	 */
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the out_of_stock_qty
	 */
	public int getOut_of_stock_qty() {
		return out_of_stock_qty;
	}
	/**
	 * @param out_of_stock_qty the out_of_stock_qty to set
	 */
	public void setOut_of_stock_qty(int out_of_stock_qty) {
		this.out_of_stock_qty = out_of_stock_qty;
	}
	/**
	 * @return the is_in_stock
	 */
	public int getIs_in_stock() {
		return is_in_stock;
	}
	/**
	 * @param is_in_stock the is_in_stock to set
	 */
	public void setIs_in_stock(int is_in_stock) {
		this.is_in_stock = is_in_stock;
	}
	/**
	 * @return the additionalField1
	 */
	public String getAdditionalField1() {
		return additionalField1;
	}
	/**
	 * @param additionalField1 the additionalField1 to set
	 */
	public void setAdditionalField1(String additionalField1) {
		this.additionalField1 = additionalField1;
	}
	/**
	 * @return the additionalField2
	 */
	public String getAdditionalField2() {
		return additionalField2;
	}
	/**
	 * @param additionalField2 the additionalField2 to set
	 */
	public void setAdditionalField2(String additionalField2) {
		this.additionalField2 = additionalField2;
	}
	/**
	 * @return the additionalField3
	 */
	public String getAdditionalField3() {
		return additionalField3;
	}
	/**
	 * @param additionalField3 the additionalField3 to set
	 */
	public void setAdditionalField3(String additionalField3) {
		this.additionalField3 = additionalField3;
	}
	/**
	 * @return the additionalField4
	 */
	public String getAdditionalField4() {
		return additionalField4;
	}
	/**
	 * @param additionalField4 the additionalField4 to set
	 */
	public void setAdditionalField4(String additionalField4) {
		this.additionalField4 = additionalField4;
	}
	/**
	 * @return the additionalField5
	 */
	public String getAdditionalField5() {
		return additionalField5;
	}
	/**
	 * @param additionalField5 the additionalField5 to set
	 */
	public void setAdditionalField5(String additionalField5) {
		this.additionalField5 = additionalField5;
	}

}
