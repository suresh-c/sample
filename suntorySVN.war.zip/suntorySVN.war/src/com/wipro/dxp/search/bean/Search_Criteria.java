package com.wipro.dxp.search.bean;

import java.util.ArrayList;

public class Search_Criteria {
ArrayList<Filter_Groups> filter_groups= new ArrayList<Filter_Groups>();

public ArrayList<Filter_Groups> getFilter_groups() {
	return filter_groups;
}

public void setFilter_groups(ArrayList<Filter_Groups> filter_groups) {
	this.filter_groups = filter_groups;
}
}
