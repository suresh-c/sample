package com.wipro.dxp.search.bean;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Properties;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.wipro.dxp.rest.quickorder.bean.QuickOrder;
import com.wipro.dxp.rest.quickorder.request.bean.Cart;

public class ProductSearchRequest {
	private static final Logger _LOGGER = Logger.getLogger(Cart.class);
	private Properties _sources;
	WebTarget webTarget;
	private static final String webServiceURI = "http://10.201.61.51:81/magento2/rest/V1/products?searchCriteria%5bfilter_groups%5d%5b0%5d%5bfilters%5d%5b0%5d%5bfield%5d=sku&searchCriteria%5bfilter_groups%5d%5b0%5d%5bfilters%5d%5b0%5d%5bvalue%5d=%25royal%25&searchCriteria%5bfilter_groups%5d%5b0%5d%5bfilters%5d%5b0%5d%5bcondition_type%5d=like&searchCriteria%5bfilter_groups%5d%5b0%5d%5bfilters%5d%5b1%5d%5bfield%5d=name&searchCriteria%5bfilter_groups%5d%5b0%5d%5bfilters%5d%5b1%5d%5bvalue%5d=%25royal25&searchCriteria%5bfilter_groups%5d%5b0%5d%5bfilters%5d%5b1%5d%5bcondition_type%5d=like&searchCriteria%5bfilter_groups%5d%5b1%5d%5bfilters%5d%5b0%5d%5bfield%5d=category_id&searchCriteria%5bfilter_groups%5d%5b1%5d%5bfilters%5d%5b0%5d%5bvalue%5d=3&searchCriteria%5bfilter_groups%5d%5b1%5d%5bfilters%5d%5b0%5d%5bcondition_type%5d=eq";


	public static void main(String[] args) {
		
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
		WebTarget webTarget = client.target(serviceURI);
		String response = webTarget.request()
				.header("authorization", "Bearer y6gwhc1y5ncawg4t00enixguck5om1d3")
				.header("accept-language", "application/json")
				.get(String.class);
		System.out.println(response);
		ProductSearch productsearch = new ProductSearch();
		
		Gson gson = new Gson();
		
		
		System.out.println(response);
		productsearch = gson.fromJson(response,ProductSearch.class);
		//String response1="{\"items\":[{\"entity_id\"}]}";
//		System.out.println(productsearch.getTotal_count());
		
	}
	public ProductSearch makeRequest(String baseUrl,String servicepath,String token)
	{
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		StringBuffer webServiceURL = new StringBuffer(baseUrl);
		webServiceURL.append(servicepath);
		_LOGGER.info(webServiceURL);
		URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build();
		_LOGGER.info(serviceURI);
		WebTarget webTarget = client.target(serviceURI);
		String response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.get(String.class);
	
		ProductSearch productsearch = new ProductSearch();
		Gson gson = new Gson();
		productsearch = gson.fromJson(response,ProductSearch.class);
		return productsearch;
	
	
		
	}

}
