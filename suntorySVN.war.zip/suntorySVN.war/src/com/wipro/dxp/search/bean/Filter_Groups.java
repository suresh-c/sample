package com.wipro.dxp.search.bean;

import java.util.ArrayList;

public class Filter_Groups {
	ArrayList<Filters> filters=new ArrayList<Filters>();

	public ArrayList<Filters> getFilters() {
		return filters;
	}

	public void setFilters(ArrayList<Filters> filters) {
		this.filters = filters;
	} 
}
