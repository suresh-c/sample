package com.wipro.dxp.search.bean;

public class Filters {

    String field="";
    String value="";
    String condition_type="";
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getCondition_type() {
		return condition_type;
	}
	public void setCondition_type(String condition_type) {
		this.condition_type = condition_type;
	}
}
