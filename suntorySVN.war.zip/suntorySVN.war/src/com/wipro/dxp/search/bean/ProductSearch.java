package com.wipro.dxp.search.bean;

import java.util.ArrayList;

public class ProductSearch {
ArrayList<Items> items=new ArrayList<Items>();
Search_Criteria search_criteria=new Search_Criteria();
int total_count=0;
public ArrayList<Items> getItems() {
	return items;
}
public void setItems(ArrayList<Items> items) {
	this.items = items;
}
public Search_Criteria getSearch_criteria() {
	return search_criteria;
}
public void setSearch_criteria(Search_Criteria search_criteria) {
	this.search_criteria = search_criteria;
}
public int getTotal_count() {
	return total_count;
}
public void setTotal_count(int total_count) {
	this.total_count = total_count;
}
}
