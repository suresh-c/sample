/**
 * 
 */
package com.wipro.dxp.rest.categories.bean;

import java.util.ArrayList;

/**
 * @author JA294967
 *
 */
public class Categories {
    String id = "";
    String parent_id="";
    String name="";
    String is_active = "";
    String position;
    String level ;
    String product_count;
    ArrayList<ChildrenData> children_data = new ArrayList<ChildrenData>();
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the parent_id
	 */
	public String getParent_id() {
		return parent_id;
	}
	/**
	 * @param parent_id the parent_id to set
	 */
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the is_active
	 */
	public String getIs_active() {
		return is_active;
	}
	/**
	 * @param is_active the is_active to set
	 */
	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}
	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}
	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the product_count
	 */
	public String getProduct_count() {
		return product_count;
	}
	/**
	 * @param product_count the product_count to set
	 */
	public void setProduct_count(String product_count) {
		this.product_count = product_count;
	}
	/**
	 * @return the children_data
	 */
	public ArrayList<ChildrenData> getChildren_data() {
		return children_data;
	}
	/**
	 * @param children_data the children_data to set
	 */
	public void setChildren_data(ArrayList<ChildrenData> children_data) {
		this.children_data = children_data;
	}
    
}
