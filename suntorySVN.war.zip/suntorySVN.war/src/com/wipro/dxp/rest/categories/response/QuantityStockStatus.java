/**
 * 
 */
package com.wipro.dxp.rest.categories.response;

/**
 * @author JA294967
 *
 */
public class QuantityStockStatus {
	boolean is_in_stock;
    int qty;
	/**
	 * @return the is_in_stock
	 */
	public boolean isIs_in_stock() {
		return is_in_stock;
	}
	/**
	 * @param is_in_stock the is_in_stock to set
	 */
	public void setIs_in_stock(boolean is_in_stock) {
		this.is_in_stock = is_in_stock;
	}
	/**
	 * @return the qty
	 */
	public int getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(int qty) {
		this.qty = qty;
	}
    
}
