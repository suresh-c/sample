/**
 * 
 */
package com.wipro.dxp.rest.categories.response;

/**
 * @author JA294967
 *
 */
public class MediaGallery {
	String value_id;
	String file;
	String media_type;
	String entity_id;
	String label;
	String position;
	String disabled;
	String label_default;
	String position_default;
	String disabled_default;
	String video_provider;
	String video_url;
	String video_title;
	String video_description;
	String video_metadata;
	String video_provider_default;
	String video_url_default;
	String video_title_default;
	String video_description_default;
	String video_metadata_default;
	/**
	 * @return the value_id
	 */
	public String getValue_id() {
		return value_id;
	}
	/**
	 * @param value_id the value_id to set
	 */
	public void setValue_id(String value_id) {
		this.value_id = value_id;
	}
	/**
	 * @return the file
	 */
	public String getFile() {
		return file;
	}
	/**
	 * @param file the file to set
	 */
	public void setFile(String file) {
		this.file = file;
	}
	/**
	 * @return the media_type
	 */
	public String getMedia_type() {
		return media_type;
	}
	/**
	 * @param media_type the media_type to set
	 */
	public void setMedia_type(String media_type) {
		this.media_type = media_type;
	}
	/**
	 * @return the entity_id
	 */
	public String getEntity_id() {
		return entity_id;
	}
	/**
	 * @param entity_id the entity_id to set
	 */
	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}
	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}
	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	/**
	 * @return the disabled
	 */
	public String getDisabled() {
		return disabled;
	}
	/**
	 * @param disabled the disabled to set
	 */
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}
	/**
	 * @return the label_default
	 */
	public String getLabel_default() {
		return label_default;
	}
	/**
	 * @param label_default the label_default to set
	 */
	public void setLabel_default(String label_default) {
		this.label_default = label_default;
	}
	/**
	 * @return the position_default
	 */
	public String getPosition_default() {
		return position_default;
	}
	/**
	 * @param position_default the position_default to set
	 */
	public void setPosition_default(String position_default) {
		this.position_default = position_default;
	}
	/**
	 * @return the disabled_default
	 */
	public String getDisabled_default() {
		return disabled_default;
	}
	/**
	 * @param disabled_default the disabled_default to set
	 */
	public void setDisabled_default(String disabled_default) {
		this.disabled_default = disabled_default;
	}
	/**
	 * @return the video_provider
	 */
	public String getVideo_provider() {
		return video_provider;
	}
	/**
	 * @param video_provider the video_provider to set
	 */
	public void setVideo_provider(String video_provider) {
		this.video_provider = video_provider;
	}
	/**
	 * @return the video_url
	 */
	public String getVideo_url() {
		return video_url;
	}
	/**
	 * @param video_url the video_url to set
	 */
	public void setVideo_url(String video_url) {
		this.video_url = video_url;
	}
	/**
	 * @return the video_title
	 */
	public String getVideo_title() {
		return video_title;
	}
	/**
	 * @param video_title the video_title to set
	 */
	public void setVideo_title(String video_title) {
		this.video_title = video_title;
	}
	/**
	 * @return the video_description
	 */
	public String getVideo_description() {
		return video_description;
	}
	/**
	 * @param video_description the video_description to set
	 */
	public void setVideo_description(String video_description) {
		this.video_description = video_description;
	}
	/**
	 * @return the video_metadata
	 */
	public String getVideo_metadata() {
		return video_metadata;
	}
	/**
	 * @param video_metadata the video_metadata to set
	 */
	public void setVideo_metadata(String video_metadata) {
		this.video_metadata = video_metadata;
	}
	/**
	 * @return the video_provider_default
	 */
	public String getVideo_provider_default() {
		return video_provider_default;
	}
	/**
	 * @param video_provider_default the video_provider_default to set
	 */
	public void setVideo_provider_default(String video_provider_default) {
		this.video_provider_default = video_provider_default;
	}
	/**
	 * @return the video_url_default
	 */
	public String getVideo_url_default() {
		return video_url_default;
	}
	/**
	 * @param video_url_default the video_url_default to set
	 */
	public void setVideo_url_default(String video_url_default) {
		this.video_url_default = video_url_default;
	}
	/**
	 * @return the video_title_default
	 */
	public String getVideo_title_default() {
		return video_title_default;
	}
	/**
	 * @param video_title_default the video_title_default to set
	 */
	public void setVideo_title_default(String video_title_default) {
		this.video_title_default = video_title_default;
	}
	/**
	 * @return the video_description_default
	 */
	public String getVideo_description_default() {
		return video_description_default;
	}
	/**
	 * @param video_description_default the video_description_default to set
	 */
	public void setVideo_description_default(String video_description_default) {
		this.video_description_default = video_description_default;
	}
	/**
	 * @return the video_metadata_default
	 */
	public String getVideo_metadata_default() {
		return video_metadata_default;
	}
	/**
	 * @param video_metadata_default the video_metadata_default to set
	 */
	public void setVideo_metadata_default(String video_metadata_default) {
		this.video_metadata_default = video_metadata_default;
	}
	 
}
