/**
 * 
 */
package com.wipro.dxp.rest.categories.response;

import java.util.ArrayList;

/**
 * @author JA294967
 *
 */
public class Products {
	 String entity_id;
     String attribute_set_id;
     String type_id;
     String sku;
     String has_options;
     String required_options;
     String created_at;
     String updated_at;
     String status;
     String visibility;
     QuantityStockStatus quantity_and_stock_status = new QuantityStockStatus();
     String tax_class_id;
     String price;
     String special_price;
     String weight;
     String name;
     String meta_title;
     String meta_description;
     String image;
     String small_image;
     String thumbnail;
     String options_container;
     String url_key;
     String msrp_display_actual_price_type;
     String gift_message_available;
     String material_id;
     String material_name;
     ArrayList<Options> options = new ArrayList<Options>();
     ArrayList<MediaGallery> media_gallery = new ArrayList<MediaGallery>();
     ExtensionAttributes extension_attributes = new ExtensionAttributes();
     ArrayList<TierPrice> tier_price = new ArrayList<TierPrice>();
     int tier_price_changed;
     String[] category_ids;
     String is_salable;
	/**
	 * @return the entity_id
	 */
	public String getEntity_id() {
		return entity_id;
	}
	/**
	 * @param entity_id the entity_id to set
	 */
	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}
	/**
	 * @return the attribute_set_id
	 */
	public String getAttribute_set_id() {
		return attribute_set_id;
	}
	/**
	 * @param attribute_set_id the attribute_set_id to set
	 */
	public void setAttribute_set_id(String attribute_set_id) {
		this.attribute_set_id = attribute_set_id;
	}
	/**
	 * @return the type_id
	 */
	public String getType_id() {
		return type_id;
	}
	/**
	 * @param type_id the type_id to set
	 */
	public void setType_id(String type_id) {
		this.type_id = type_id;
	}
	/**
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}
	/**
	 * @param sku the sku to set
	 */
	public void setSku(String sku) {
		this.sku = sku;
	}
	/**
	 * @return the has_options
	 */
	public String getHas_options() {
		return has_options;
	}
	/**
	 * @param has_options the has_options to set
	 */
	public void setHas_options(String has_options) {
		this.has_options = has_options;
	}
	/**
	 * @return the required_options
	 */
	public String getRequired_options() {
		return required_options;
	}
	/**
	 * @param required_options the required_options to set
	 */
	public void setRequired_options(String required_options) {
		this.required_options = required_options;
	}
	/**
	 * @return the created_at
	 */
	public String getCreated_at() {
		return created_at;
	}
	/**
	 * @param created_at the created_at to set
	 */
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	/**
	 * @return the updated_at
	 */
	public String getUpdated_at() {
		return updated_at;
	}
	/**
	 * @param updated_at the updated_at to set
	 */
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the visibility
	 */
	public String getVisibility() {
		return visibility;
	}
	/**
	 * @param visibility the visibility to set
	 */
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	/**
	 * @return the quantity_and_stock_status
	 */
	public QuantityStockStatus getQuantity_and_stock_status() {
		return quantity_and_stock_status;
	}
	/**
	 * @param quantity_and_stock_status the quantity_and_stock_status to set
	 */
	public void setQuantity_and_stock_status(QuantityStockStatus quantity_and_stock_status) {
		this.quantity_and_stock_status = quantity_and_stock_status;
	}
	/**
	 * @return the tax_class_id
	 */
	public String getTax_class_id() {
		return tax_class_id;
	}
	/**
	 * @param tax_class_id the tax_class_id to set
	 */
	public void setTax_class_id(String tax_class_id) {
		this.tax_class_id = tax_class_id;
	}
	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}
	/**
	 * @return the special_price
	 */
	public String getSpecial_price() {
		return special_price;
	}
	/**
	 * @param special_price the special_price to set
	 */
	public void setSpecial_price(String special_price) {
		this.special_price = special_price;
	}
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the meta_title
	 */
	public String getMeta_title() {
		return meta_title;
	}
	/**
	 * @param meta_title the meta_title to set
	 */
	public void setMeta_title(String meta_title) {
		this.meta_title = meta_title;
	}
	/**
	 * @return the meta_description
	 */
	public String getMeta_description() {
		return meta_description;
	}
	/**
	 * @param meta_description the meta_description to set
	 */
	public void setMeta_description(String meta_description) {
		this.meta_description = meta_description;
	}
	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}
	/**
	 * @param image the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}
	/**
	 * @return the small_image
	 */
	public String getSmall_image() {
		return small_image;
	}
	/**
	 * @param small_image the small_image to set
	 */
	public void setSmall_image(String small_image) {
		this.small_image = small_image;
	}
	/**
	 * @return the thumbnail
	 */
	public String getThumbnail() {
		return thumbnail;
	}
	/**
	 * @param thumbnail the thumbnail to set
	 */
	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}
	/**
	 * @return the options_container
	 */
	public String getOptions_container() {
		return options_container;
	}
	/**
	 * @param options_container the options_container to set
	 */
	public void setOptions_container(String options_container) {
		this.options_container = options_container;
	}
	/**
	 * @return the url_key
	 */
	public String getUrl_key() {
		return url_key;
	}
	/**
	 * @param url_key the url_key to set
	 */
	public void setUrl_key(String url_key) {
		this.url_key = url_key;
	}
	/**
	 * @return the msrp_display_actual_price_type
	 */
	public String getMsrp_display_actual_price_type() {
		return msrp_display_actual_price_type;
	}
	/**
	 * @param msrp_display_actual_price_type the msrp_display_actual_price_type to set
	 */
	public void setMsrp_display_actual_price_type(String msrp_display_actual_price_type) {
		this.msrp_display_actual_price_type = msrp_display_actual_price_type;
	}
	/**
	 * @return the gift_message_available
	 */
	public String getGift_message_available() {
		return gift_message_available;
	}
	/**
	 * @param gift_message_available the gift_message_available to set
	 */
	public void setGift_message_available(String gift_message_available) {
		this.gift_message_available = gift_message_available;
	}
	/**
	 * @return the material_id
	 */
	public String getMaterial_id() {
		return material_id;
	}
	/**
	 * @param material_id the material_id to set
	 */
	public void setMaterial_id(String material_id) {
		this.material_id = material_id;
	}
	/**
	 * @return the material_name
	 */
	public String getMaterial_name() {
		return material_name;
	}
	/**
	 * @param material_name the material_name to set
	 */
	public void setMaterial_name(String material_name) {
		this.material_name = material_name;
	}
	/**
	 * @return the options
	 */
	public ArrayList<Options> getOptions() {
		return options;
	}
	/**
	 * @param options the options to set
	 */
	public void setOptions(ArrayList<Options> options) {
		this.options = options;
	}

	/**
	 * @return the media_gallery
	 */
	public ArrayList<MediaGallery> getMedia_gallery() {
		return media_gallery;
	}
	/**
	 * @param media_gallery the media_gallery to set
	 */
	public void setMedia_gallery(ArrayList<MediaGallery> media_gallery) {
		this.media_gallery = media_gallery;
	}
	/**
	 * @return the extension_attributes
	 */
	public ExtensionAttributes getExtension_attributes() {
		return extension_attributes;
	}
	/**
	 * @param extension_attributes the extension_attributes to set
	 */
	public void setExtension_attributes(ExtensionAttributes extension_attributes) {
		this.extension_attributes = extension_attributes;
	}
	/**
	 * @return the tier_price
	 */
	public ArrayList<TierPrice> getTier_price() {
		return tier_price;
	}
	/**
	 * @param tier_price the tier_price to set
	 */
	public void setTier_price(ArrayList<TierPrice> tier_price) {
		this.tier_price = tier_price;
	}
	/**
	 * @return the tier_price_changed
	 */
	public int getTier_price_changed() {
		return tier_price_changed;
	}
	/**
	 * @param tier_price_changed the tier_price_changed to set
	 */
	public void setTier_price_changed(int tier_price_changed) {
		this.tier_price_changed = tier_price_changed;
	}
	/**
	 * @return the category_ids
	 */
	public String[] getCategory_ids() {
		return category_ids;
	}
	/**
	 * @param category_ids the category_ids to set
	 */
	public void setCategory_ids(String[] category_ids) {
		this.category_ids = category_ids;
	}
	/**
	 * @return the is_salable
	 */
	public String getIs_salable() {
		return is_salable;
	}
	/**
	 * @param is_salable the is_salable to set
	 */
	public void setIs_salable(String is_salable) {
		this.is_salable = is_salable;
	}
     
}
