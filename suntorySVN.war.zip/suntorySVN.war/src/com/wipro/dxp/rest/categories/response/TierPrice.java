/**
 * 
 */
package com.wipro.dxp.rest.categories.response;

/**
 * @author JA294967
 *
 */
public class TierPrice {

}
