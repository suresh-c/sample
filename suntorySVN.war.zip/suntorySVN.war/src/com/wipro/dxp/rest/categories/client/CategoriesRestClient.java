package com.wipro.dxp.rest.categories.client;

import java.lang.reflect.Type;
import java.net.URI;

import javax.ws.rs.POST;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wipro.dxp.rest.categories.bean.Categories;
import com.wipro.dxp.rest.categories.request.CategoryProductRequest;
import com.wipro.dxp.rest.categories.response.CategoryProduct;

import net.sf.json.JSONObject;
/**
 * @author JA294967
 *
 */
public class CategoriesRestClient {
	/**
	 * Registering logger
	 */
	private static final Logger _LOGGER = Logger.getLogger(CategoriesRestClient.class);
	WebTarget webTarget;
	/**
	 * @return Categories
	 */
	public Categories getCategories(String base,String servicePath, String token){
		_LOGGER.info("getCategories: START");
		Categories categories = new Categories();  
		StringBuffer webServiceURI = new StringBuffer(base);
		webServiceURI.append(servicePath);
		createWebTarget(webServiceURI);
		/*
		 * Make request
		 */
		Response response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.get(Response.class);
		_LOGGER.info("Response::"+response);
		if(response.getStatus()==200){
			response.bufferEntity();
			Gson gson = new Gson();
			Type type = new TypeToken<Categories>() {}.getType();
			categories = gson.fromJson(response.readEntity(String.class), type);
			_LOGGER.info("getCategories-name"+categories.getName());
			_LOGGER.info("getCategories-chiled"+categories.getChildren_data().get(0).getName());
			_LOGGER.info("getCategories-child"+categories.getChildren_data().get(1).getName());
		}
		return categories;
	}

	public CategoryProduct getCategoryProducts(String base,String servicePath, String token,CategoryProductRequest productRequest){
		_LOGGER.info("getCategoryProducts: START");
		CategoryProduct products = new CategoryProduct();  
		StringBuffer webServiceURI = new StringBuffer(base);
		webServiceURI.append(servicePath);
		createWebTarget(webServiceURI);
		/*
		 * Make request
		 */
		Response response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.post(Entity.entity(productRequest, MediaType.APPLICATION_JSON_TYPE));
		//String response = "{\"products\": [{\"entity_id\": \"5\",\"attribute_set_id\": \"9\",\"type_id\": \"simple\",\"sku\": \"Test Product 3\",\"has_options\": \"0\",\"required_options\": \"0\",\"created_at\": \"2018-01-02 10:47:38\",\"updated_at\": \"2018-01-03 10:13:49\",\"status\": \"1\",\"visibility\": \"4\",\"quantity_and_stock_status\": {\"is_in_stock\": true,\"qty\": 92},\"tax_class_id\": \"2\",\"price\": \"350.0000\",\"special_price\": null,\"weight\": \"2.0000\",\"name\": \"Test Product 3\",\"options_container\": \"container2\",\"url_key\": \"test-product-3\",\"msrp_display_actual_price_type\": \"0\",\"gift_message_available\": \"0\",\"material_id\": \"testmatid1\",\"material_name\": \"test mat name 1\",\"options\": [],\"media_gallery\": {\"images\": [],\"values\": []},\"extension_attributes\": {},\"tier_price\": [],\"tier_price_changed\": 0,\"category_ids\": [\"4\"],\"is_salable\": \"1\"},{\"entity_id\": \"6\",\"attribute_set_id\": \"9\",\"type_id\": \"simple\",\"sku\": \"Test Product 4\",\"has_options\": \"0\",\"required_options\": \"0\",\"created_at\": \"2018-01-02 10:47:38\",\"updated_at\": \"2018-01-03 10:05:36\",\"status\": \"1\",\"visibility\": \"4\",\"quantity_and_stock_status\": {\"is_in_stock\": true,\"qty\": 117},\"tax_class_id\": \"2\",\"price\": \"400.0000\",\"special_price\": null,\"weight\": \"3.0000\",\"name\": \"Test Product 4\",\"options_container\": \"container2\",\"url_key\": \"test-product-4\",\"msrp_display_actual_price_type\": \"0\",\"gift_message_available\": \"0\",\"material_id\": \"testmatid2\",\"material_name\": \"test mat name 2\",\"options\": [],\"media_gallery\": {\"images\": [],\"values\": []},\"extension_attributes\": {},\"tier_price\": [],\"tier_price_changed\": 0,\"category_ids\": [\"4\"],\"is_salable\": \"1\"}],\"total_count\": 2}";
		_LOGGER.info("Response::"+response);
		response.bufferEntity();		
		System.out.println("getCategoryProducts---"+response.readEntity(String.class));
		if(response.getStatus()==200){
			Gson gson = new Gson();
			Type type = new TypeToken<CategoryProduct>() {}.getType();
			products = gson.fromJson(response.readEntity(String.class), type);
			_LOGGER.info("getCategoryProducts-getTotal_count="+products.getTotal_count());
			_LOGGER.info("getCategoryProducts name1-"+products.getProducts().get(0).getName());
			_LOGGER.info("getCategoryProducts name2-"+products.getProducts().get(1).getName());
		}
		return products;
	}

	/**
	 * createWebTarget
	 */
	public void createWebTarget(StringBuffer webServiceURI) {	
		System.out.println(webServiceURI);
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI.toString()).build();
		webTarget = client.target(serviceURI);

	}
	public static void main(String[] args) {
//				CategoriesRestClient categoriesRestClient = new CategoriesRestClient();
//				categoriesRestClient.getCategories("http://10.201.61.51:81/magento2/rest/V1/","categories","y6gwhc1y5ncawg4t00enixguck5om1d3");
		CategoriesRestClient restClient = new CategoriesRestClient();
		CategoryProductRequest productRequest= new CategoryProductRequest();
		productRequest.setCategoryId(3);
		productRequest.setPageSize(5);
		productRequest.setPage(1);
		CategoryProduct productsResult = restClient.getCategoryProducts("http://10.201.61.51:81/magento2/rest/V1","/suntory/category/products","y6gwhc1y5ncawg4t00enixguck5om1d3", productRequest);


	}
}
