/**
 * 
 */
package com.wipro.dxp.rest.categories.response;

import java.util.ArrayList;

/**
 * @author JA294967
 *
 */
public class CategoryProduct {
	ArrayList<Products> products = new ArrayList<Products>();
	int total_count;
	/**
	 * @return the products
	 */
	public ArrayList<Products> getProducts() {
		return products;
	}
	/**
	 * @param products the products to set
	 */
	public void setProducts(ArrayList<Products> products) {
		this.products = products;
	}
	/**
	 * @return the total_count
	 */
	public int getTotal_count() {
		return total_count;
	}
	/**
	 * @param total_count the total_count to set
	 */
	public void setTotal_count(int total_count) {
		this.total_count = total_count;
	}
	
}
