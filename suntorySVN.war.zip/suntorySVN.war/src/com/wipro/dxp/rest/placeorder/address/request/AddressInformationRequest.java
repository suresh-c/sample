/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.request;

/**
 * @author JA294967
 *
 */
public class AddressInformationRequest {
	AddressInformation addressInformation = new AddressInformation();

	/**
	 * @return the addressInformation
	 */
	public AddressInformation getAddressInformation() {
		return addressInformation;
	}

	/**
	 * @param addressInformation the addressInformation to set
	 */
	public void setAddressInformation(AddressInformation addressInformation) {
		this.addressInformation = addressInformation;
	}
		
		
}
