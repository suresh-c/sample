/**
 * 
 */
package com.wipro.dxp.rest.placeorder.response;

/**
 * @author JA294967
 *
 */
public class OrderId {
	String order_id;

	/**
	 * @return the order_id
	 */
	public String getOrder_id() {
		return order_id;
	}

	/**
	 * @param order_id the order_id to set
	 */
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	
}
