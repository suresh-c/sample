/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

import java.util.ArrayList;

/**
 * @author JA294967
 *
 */
public class ExtensionAttributes {
	ArrayList<TaxGrandtotalDetails> tax_grandtotal_details = new ArrayList<TaxGrandtotalDetails>();
}
