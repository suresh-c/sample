package com.wipro.dxp.rest.placeorder.client;

import java.lang.reflect.Type;
import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wipro.dxp.rest.placeorder.address.request.AddressInformationRequest;
import com.wipro.dxp.rest.placeorder.address.response.AddressInformationResponse;
import com.wipro.dxp.rest.placeorder.request.BillingAddress;
import com.wipro.dxp.rest.placeorder.request.OrderPaymentRequest;
import com.wipro.dxp.rest.placeorder.request.PaymentMethod;
import com.wipro.dxp.rest.placeorder.response.OrderId;
/**
 * @author JA294967
 *
 */
public class OrderPaymentRestClient {
	/**
	 * Registering logger
	 */
	private static final Logger _LOGGER = Logger.getLogger(OrderPaymentRestClient.class);
	WebTarget webTarget;

	public OrderId orderPlacement(String base,String servicePath, String customerToken,OrderPaymentRequest paymentRequest){
		_LOGGER.info("orderPlacement: START");
		OrderId orderId = new OrderId();
		try{
			StringBuffer webServiceURI = new StringBuffer(base);
			webServiceURI.append(servicePath);
			createWebTarget(webServiceURI);
			/*
			 * Make request
			 */
			Response response = webTarget.request()
					.header("authorization", "Bearer "+customerToken)
					.header("accept-language", "application/json")
					.post(Entity.entity(paymentRequest, MediaType.APPLICATION_JSON_TYPE));
			//String response = "{\"order_id\":\"2000000002\"}";
			_LOGGER.info("Response::"+response);
			response.bufferEntity();		
			System.out.println("orderPlacement---"+response.readEntity(String.class));
			if(response.getStatus()==200){
						Gson gson = new Gson();
						Type type = new TypeToken<OrderId>() {}.getType();
						orderId = gson.fromJson(response.readEntity(String.class), type);
				
				_LOGGER.info("orderPlacement orderId"+orderId.getOrder_id());
			}
		}catch (Exception e) {
			_LOGGER.info("Exception in OrderPaymentRestClient-orderPlacement-"+e);
		}
		return orderId;
	}
	public AddressInformationResponse saveShippingAddress(String base,String servicePath, String customerToken,AddressInformationRequest addressInformationRequest){
		_LOGGER.info("saveShippingAddress: START");
		AddressInformationResponse addressInformationResponse = new AddressInformationResponse();
		try{
			StringBuffer webServiceURI = new StringBuffer(base);
			webServiceURI.append(servicePath);
			createWebTarget(webServiceURI);
			/*
			 * Make request
			 */
			Response response = webTarget.request()
					.header("authorization", "Bearer "+customerToken)
					.header("accept-language", "application/json")
					.post(Entity.entity(addressInformationRequest, MediaType.APPLICATION_JSON_TYPE));
			//String response = "{\"payment_methods\": [{\"code\": \"purchaseorder\",\"title\": \"Purchase Order\"}],\"totals\": {\"grand_total\": 10,\"base_grand_total\": 10,\"subtotal\": 10,\"base_subtotal\": 10,\"discount_amount\": 0,\"base_discount_amount\": 0,\"subtotal_with_discount\": 10,\"base_subtotal_with_discount\": 10,\"shipping_amount\": 0,\"base_shipping_amount\": 0,\"shipping_discount_amount\": 0,\"base_shipping_discount_amount\": 0,\"tax_amount\": 0,\"base_tax_amount\": 0,\"weee_tax_applied_amount\": null,\"shipping_tax_amount\": 0,\"base_shipping_tax_amount\": 0,\"subtotal_incl_tax\": 10,\"shipping_incl_tax\": 0,\"base_shipping_incl_tax\": 0,\"base_currency_code\": \"USD\",\"quote_currency_code\": \"USD\",\"items_qty\": 1,\"items\": [{\"item_id\": 15,\"price\": 10,\"base_price\": 10,\"qty\": 1,\"row_total\": 10,\"base_row_total\": 10,\"row_total_with_discount\": 0,\"tax_amount\": 0,\"base_tax_amount\": 0,\"tax_percent\": 0,\"discount_amount\": 0,\"base_discount_amount\": 0,\"discount_percent\": 0,\"price_incl_tax\": 10,\"base_price_incl_tax\": 10,\"row_total_incl_tax\": 10,\"base_row_total_incl_tax\": 10,\"options\": \"[]\",\"weee_tax_applied_amount\": null,\"weee_tax_applied\": null,\"name\": \"Orange\"}],\"total_segments\": [{\"code\": \"subtotal\",\"title\": \"Subtotal\",\"value\": 10},{\"code\": \"shipping\",\"title\": \"Shipping & Handling\",\"value\": 0},{\"code\": \"tax\",\"title\": \"Tax\",\"value\": 0,\"extension_attributes\": {\"tax_grandtotal_details\": []}},{\"code\": \"grand_total\",\"title\": \"Grand Total\",\"value\": 10,\"area\": \"footer\"}]}}";
			_LOGGER.info("Response::"+response);
			response.bufferEntity();		
			System.out.println("saveShippingAddress---"+response.readEntity(String.class));
			if(response.getStatus()==200){
				Gson gson = new Gson();
				Type type = new TypeToken<AddressInformationResponse>() {}.getType();
				addressInformationResponse = gson.fromJson(response.readEntity(String.class), type);
				//addressInformationResponse = gson.fromJson(response, type);

				_LOGGER.info("saveShippingAddress orderId"+addressInformationResponse.getTotals().getItems().get(0).getOptions());
			}
		}catch (Exception e) {
			_LOGGER.info("Exception in OrderPaymentRestClient-saveShippingAddress-"+e);
		}
		return addressInformationResponse;
	}
	/**
	 * createWebTarget
	 */
	public void createWebTarget(StringBuffer webServiceURI) {	
		System.out.println(webServiceURI);
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI.toString()).build();
		webTarget = client.target(serviceURI);

	}
	public static void main(String[] args) {
		OrderPaymentRestClient restClient = new OrderPaymentRestClient();
		OrderPaymentRequest paymentRequest = new OrderPaymentRequest();
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setMethod("purchaseorder");
		paymentMethod.setPo_number("123456");
		paymentRequest.setPaymentMethod(paymentMethod);
		BillingAddress billing_address = new BillingAddress();
		billing_address.setEmail("sivaraj.venkatachalam@wipro.com");
		billing_address.setRegion("Indiana");
		billing_address.setRegion_id(24);
		billing_address.setRegion_code("IN");
		billing_address.setCountry_id("US");
		String[] street = {"E City"};
		billing_address.setStreet(street);
		billing_address.setPostcode("10577");
		billing_address.setCity("Bangalore");
		billing_address.setTelephone("1234567890");
		billing_address.setFirstname("siva");
		billing_address.setLastname("venkat");

		paymentRequest.setBilling_address(billing_address);
		AddressInformationRequest informationRequest = new AddressInformationRequest();
		restClient.orderPlacement("http://10.201.61.51:81/magento2/rest/V1/", "/carts/mine/payment-information", "28bipltao46lr0yw4bh02ymthytyecfv", paymentRequest);
		restClient.saveShippingAddress("http://10.201.61.51:81/magento2/rest/V1/", "/carts/mine/payment-information", "28bipltao46lr0yw4bh02ymthytyecfv", informationRequest);

	}
}
