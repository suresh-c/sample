/**
 * 
 */
package com.wipro.dxp.rest.placeorder.request;

/**
 * @author JA294967
 *
 */
public class OrderPaymentRequest {
	PaymentMethod paymentMethod = new PaymentMethod();
	BillingAddress billing_address = new BillingAddress();
	/**
	 * @return the paymentMethod
	 */
	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}
	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	/**
	 * @return the billing_address
	 */
	public BillingAddress getBilling_address() {
		return billing_address;
	}
	/**
	 * @param billing_address the billing_address to set
	 */
	public void setBilling_address(BillingAddress billing_address) {
		this.billing_address = billing_address;
	}
	
}
