/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

/**
 * @author JA294967
 *
 */
public class TaxGrandtotalDetails {

}
