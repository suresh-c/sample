/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.request;

/**
 * @author JA294967
 *
 */
public class AddressInformation {
	ShippingAddress shippingAddress = new ShippingAddress();
	String shippingCarrierCode = "flatrate";
	String shippingMethodCode = "flatrate";
	/**
	 * @return the shippingAddress
	 */
	public ShippingAddress getShippingAddress() {
		return shippingAddress;
	}
	/**
	 * @param shippingAddress the shippingAddress to set
	 */
	public void setShippingAddress(ShippingAddress shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	/**
	 * @return the shippingCarrierCode
	 */
	public String getShippingCarrierCode() {
		return shippingCarrierCode;
	}
	/**
	 * @param shippingCarrierCode the shippingCarrierCode to set
	 */
	public void setShippingCarrierCode(String shippingCarrierCode) {
		this.shippingCarrierCode = shippingCarrierCode;
	}
	/**
	 * @return the shippingMethodCode
	 */
	public String getShippingMethodCode() {
		return shippingMethodCode;
	}
	/**
	 * @param shippingMethodCode the shippingMethodCode to set
	 */
	public void setShippingMethodCode(String shippingMethodCode) {
		this.shippingMethodCode = shippingMethodCode;
	}

}
