/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

/**
 * @author JA294967
 *
 */
public class PaymentMethod {
	String code;
	String title;
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
}
