/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

/**
 * @author JA294967
 *
 */
public class Items {
	 int item_id;
	 int price;
	 int base_price;
	 int qty;
	 int row_total;
	 int base_row_total;
	 int row_total_with_discount;
	 int tax_amount;
	 int base_tax_amount;
	 int tax_percent;
	 int discount_amount;
	 int base_discount_amount;
	 int discount_percent;
	 int price_incl_tax;
	 int base_price_incl_tax;
	 int row_total_incl_tax;
	 int base_row_total_incl_tax;
	 String options;
	 int weee_tax_applied_amount;
	 int weee_tax_applied;
	 String name;
	/**
	 * @return the item_id
	 */
	public int getItem_id() {
		return item_id;
	}
	/**
	 * @param item_id the item_id to set
	 */
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(int price) {
		this.price = price;
	}
	/**
	 * @return the base_price
	 */
	public int getBase_price() {
		return base_price;
	}
	/**
	 * @param base_price the base_price to set
	 */
	public void setBase_price(int base_price) {
		this.base_price = base_price;
	}
	/**
	 * @return the qty
	 */
	public int getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(int qty) {
		this.qty = qty;
	}
	/**
	 * @return the row_total
	 */
	public int getRow_total() {
		return row_total;
	}
	/**
	 * @param row_total the row_total to set
	 */
	public void setRow_total(int row_total) {
		this.row_total = row_total;
	}
	/**
	 * @return the base_row_total
	 */
	public int getBase_row_total() {
		return base_row_total;
	}
	/**
	 * @param base_row_total the base_row_total to set
	 */
	public void setBase_row_total(int base_row_total) {
		this.base_row_total = base_row_total;
	}
	/**
	 * @return the row_total_with_discount
	 */
	public int getRow_total_with_discount() {
		return row_total_with_discount;
	}
	/**
	 * @param row_total_with_discount the row_total_with_discount to set
	 */
	public void setRow_total_with_discount(int row_total_with_discount) {
		this.row_total_with_discount = row_total_with_discount;
	}
	/**
	 * @return the tax_amount
	 */
	public int getTax_amount() {
		return tax_amount;
	}
	/**
	 * @param tax_amount the tax_amount to set
	 */
	public void setTax_amount(int tax_amount) {
		this.tax_amount = tax_amount;
	}
	/**
	 * @return the base_tax_amount
	 */
	public int getBase_tax_amount() {
		return base_tax_amount;
	}
	/**
	 * @param base_tax_amount the base_tax_amount to set
	 */
	public void setBase_tax_amount(int base_tax_amount) {
		this.base_tax_amount = base_tax_amount;
	}
	/**
	 * @return the tax_percent
	 */
	public int getTax_percent() {
		return tax_percent;
	}
	/**
	 * @param tax_percent the tax_percent to set
	 */
	public void setTax_percent(int tax_percent) {
		this.tax_percent = tax_percent;
	}
	/**
	 * @return the discount_amount
	 */
	public int getDiscount_amount() {
		return discount_amount;
	}
	/**
	 * @param discount_amount the discount_amount to set
	 */
	public void setDiscount_amount(int discount_amount) {
		this.discount_amount = discount_amount;
	}
	/**
	 * @return the base_discount_amount
	 */
	public int getBase_discount_amount() {
		return base_discount_amount;
	}
	/**
	 * @param base_discount_amount the base_discount_amount to set
	 */
	public void setBase_discount_amount(int base_discount_amount) {
		this.base_discount_amount = base_discount_amount;
	}
	/**
	 * @return the discount_percent
	 */
	public int getDiscount_percent() {
		return discount_percent;
	}
	/**
	 * @param discount_percent the discount_percent to set
	 */
	public void setDiscount_percent(int discount_percent) {
		this.discount_percent = discount_percent;
	}
	/**
	 * @return the price_incl_tax
	 */
	public int getPrice_incl_tax() {
		return price_incl_tax;
	}
	/**
	 * @param price_incl_tax the price_incl_tax to set
	 */
	public void setPrice_incl_tax(int price_incl_tax) {
		this.price_incl_tax = price_incl_tax;
	}
	/**
	 * @return the base_price_incl_tax
	 */
	public int getBase_price_incl_tax() {
		return base_price_incl_tax;
	}
	/**
	 * @param base_price_incl_tax the base_price_incl_tax to set
	 */
	public void setBase_price_incl_tax(int base_price_incl_tax) {
		this.base_price_incl_tax = base_price_incl_tax;
	}
	/**
	 * @return the row_total_incl_tax
	 */
	public int getRow_total_incl_tax() {
		return row_total_incl_tax;
	}
	/**
	 * @param row_total_incl_tax the row_total_incl_tax to set
	 */
	public void setRow_total_incl_tax(int row_total_incl_tax) {
		this.row_total_incl_tax = row_total_incl_tax;
	}
	/**
	 * @return the base_row_total_incl_tax
	 */
	public int getBase_row_total_incl_tax() {
		return base_row_total_incl_tax;
	}
	/**
	 * @param base_row_total_incl_tax the base_row_total_incl_tax to set
	 */
	public void setBase_row_total_incl_tax(int base_row_total_incl_tax) {
		this.base_row_total_incl_tax = base_row_total_incl_tax;
	}
	/**
	 * @return the options
	 */
	public String getOptions() {
		return options;
	}
	/**
	 * @param options the options to set
	 */
	public void setOptions(String options) {
		this.options = options;
	}
	/**
	 * @return the weee_tax_applied_amount
	 */
	public int getWeee_tax_applied_amount() {
		return weee_tax_applied_amount;
	}
	/**
	 * @param weee_tax_applied_amount the weee_tax_applied_amount to set
	 */
	public void setWeee_tax_applied_amount(int weee_tax_applied_amount) {
		this.weee_tax_applied_amount = weee_tax_applied_amount;
	}
	/**
	 * @return the weee_tax_applied
	 */
	public int getWeee_tax_applied() {
		return weee_tax_applied;
	}
	/**
	 * @param weee_tax_applied the weee_tax_applied to set
	 */
	public void setWeee_tax_applied(int weee_tax_applied) {
		this.weee_tax_applied = weee_tax_applied;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	 
}
