/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

import java.util.ArrayList;

/**
 * @author JA294967
 *
 */
public class OrderTotals {
	 int grand_total;
	 int base_grand_total;
	 int subtotal;
	 int base_subtotal;
	 int discount_amount;
	 int base_discount_amount;
	 int subtotal_with_discount;
	 int base_subtotal_with_discount;
	 int shipping_amount;
	 int base_shipping_amount;
	 int shipping_discount_amount;
	 int base_shipping_discount_amount;
	 int tax_amount;
	 int base_tax_amount;
	 int weee_tax_applied_amount;
	 int shipping_tax_amount;
	 int base_shipping_tax_amount;
	 int subtotal_incl_tax;
	 int shipping_incl_tax;
	 int base_shipping_incl_tax;
	 String base_currency_code;
	 String quote_currency_code;
	 int items_qty;
	 ArrayList<Items> items = new ArrayList<Items>();
	 ArrayList<TotalSegments> total_segments = new ArrayList<TotalSegments>();
	/**
	 * @return the grand_total
	 */
	public int getGrand_total() {
		return grand_total;
	}
	/**
	 * @param grand_total the grand_total to set
	 */
	public void setGrand_total(int grand_total) {
		this.grand_total = grand_total;
	}
	/**
	 * @return the base_grand_total
	 */
	public int getBase_grand_total() {
		return base_grand_total;
	}
	/**
	 * @param base_grand_total the base_grand_total to set
	 */
	public void setBase_grand_total(int base_grand_total) {
		this.base_grand_total = base_grand_total;
	}
	/**
	 * @return the subtotal
	 */
	public int getSubtotal() {
		return subtotal;
	}
	/**
	 * @param subtotal the subtotal to set
	 */
	public void setSubtotal(int subtotal) {
		this.subtotal = subtotal;
	}
	/**
	 * @return the base_subtotal
	 */
	public int getBase_subtotal() {
		return base_subtotal;
	}
	/**
	 * @param base_subtotal the base_subtotal to set
	 */
	public void setBase_subtotal(int base_subtotal) {
		this.base_subtotal = base_subtotal;
	}
	/**
	 * @return the discount_amount
	 */
	public int getDiscount_amount() {
		return discount_amount;
	}
	/**
	 * @param discount_amount the discount_amount to set
	 */
	public void setDiscount_amount(int discount_amount) {
		this.discount_amount = discount_amount;
	}
	/**
	 * @return the base_discount_amount
	 */
	public int getBase_discount_amount() {
		return base_discount_amount;
	}
	/**
	 * @param base_discount_amount the base_discount_amount to set
	 */
	public void setBase_discount_amount(int base_discount_amount) {
		this.base_discount_amount = base_discount_amount;
	}
	/**
	 * @return the subtotal_with_discount
	 */
	public int getSubtotal_with_discount() {
		return subtotal_with_discount;
	}
	/**
	 * @param subtotal_with_discount the subtotal_with_discount to set
	 */
	public void setSubtotal_with_discount(int subtotal_with_discount) {
		this.subtotal_with_discount = subtotal_with_discount;
	}
	/**
	 * @return the base_subtotal_with_discount
	 */
	public int getBase_subtotal_with_discount() {
		return base_subtotal_with_discount;
	}
	/**
	 * @param base_subtotal_with_discount the base_subtotal_with_discount to set
	 */
	public void setBase_subtotal_with_discount(int base_subtotal_with_discount) {
		this.base_subtotal_with_discount = base_subtotal_with_discount;
	}
	/**
	 * @return the shipping_amount
	 */
	public int getShipping_amount() {
		return shipping_amount;
	}
	/**
	 * @param shipping_amount the shipping_amount to set
	 */
	public void setShipping_amount(int shipping_amount) {
		this.shipping_amount = shipping_amount;
	}
	/**
	 * @return the base_shipping_amount
	 */
	public int getBase_shipping_amount() {
		return base_shipping_amount;
	}
	/**
	 * @param base_shipping_amount the base_shipping_amount to set
	 */
	public void setBase_shipping_amount(int base_shipping_amount) {
		this.base_shipping_amount = base_shipping_amount;
	}
	/**
	 * @return the shipping_discount_amount
	 */
	public int getShipping_discount_amount() {
		return shipping_discount_amount;
	}
	/**
	 * @param shipping_discount_amount the shipping_discount_amount to set
	 */
	public void setShipping_discount_amount(int shipping_discount_amount) {
		this.shipping_discount_amount = shipping_discount_amount;
	}
	/**
	 * @return the base_shipping_discount_amount
	 */
	public int getBase_shipping_discount_amount() {
		return base_shipping_discount_amount;
	}
	/**
	 * @param base_shipping_discount_amount the base_shipping_discount_amount to set
	 */
	public void setBase_shipping_discount_amount(int base_shipping_discount_amount) {
		this.base_shipping_discount_amount = base_shipping_discount_amount;
	}
	/**
	 * @return the tax_amount
	 */
	public int getTax_amount() {
		return tax_amount;
	}
	/**
	 * @param tax_amount the tax_amount to set
	 */
	public void setTax_amount(int tax_amount) {
		this.tax_amount = tax_amount;
	}
	/**
	 * @return the base_tax_amount
	 */
	public int getBase_tax_amount() {
		return base_tax_amount;
	}
	/**
	 * @param base_tax_amount the base_tax_amount to set
	 */
	public void setBase_tax_amount(int base_tax_amount) {
		this.base_tax_amount = base_tax_amount;
	}
	/**
	 * @return the weee_tax_applied_amount
	 */
	public int getWeee_tax_applied_amount() {
		return weee_tax_applied_amount;
	}
	/**
	 * @param weee_tax_applied_amount the weee_tax_applied_amount to set
	 */
	public void setWeee_tax_applied_amount(int weee_tax_applied_amount) {
		this.weee_tax_applied_amount = weee_tax_applied_amount;
	}
	/**
	 * @return the shipping_tax_amount
	 */
	public int getShipping_tax_amount() {
		return shipping_tax_amount;
	}
	/**
	 * @param shipping_tax_amount the shipping_tax_amount to set
	 */
	public void setShipping_tax_amount(int shipping_tax_amount) {
		this.shipping_tax_amount = shipping_tax_amount;
	}
	/**
	 * @return the base_shipping_tax_amount
	 */
	public int getBase_shipping_tax_amount() {
		return base_shipping_tax_amount;
	}
	/**
	 * @param base_shipping_tax_amount the base_shipping_tax_amount to set
	 */
	public void setBase_shipping_tax_amount(int base_shipping_tax_amount) {
		this.base_shipping_tax_amount = base_shipping_tax_amount;
	}
	/**
	 * @return the subtotal_incl_tax
	 */
	public int getSubtotal_incl_tax() {
		return subtotal_incl_tax;
	}
	/**
	 * @param subtotal_incl_tax the subtotal_incl_tax to set
	 */
	public void setSubtotal_incl_tax(int subtotal_incl_tax) {
		this.subtotal_incl_tax = subtotal_incl_tax;
	}
	/**
	 * @return the shipping_incl_tax
	 */
	public int getShipping_incl_tax() {
		return shipping_incl_tax;
	}
	/**
	 * @param shipping_incl_tax the shipping_incl_tax to set
	 */
	public void setShipping_incl_tax(int shipping_incl_tax) {
		this.shipping_incl_tax = shipping_incl_tax;
	}
	/**
	 * @return the base_shipping_incl_tax
	 */
	public int getBase_shipping_incl_tax() {
		return base_shipping_incl_tax;
	}
	/**
	 * @param base_shipping_incl_tax the base_shipping_incl_tax to set
	 */
	public void setBase_shipping_incl_tax(int base_shipping_incl_tax) {
		this.base_shipping_incl_tax = base_shipping_incl_tax;
	}
	/**
	 * @return the base_currency_code
	 */
	public String getBase_currency_code() {
		return base_currency_code;
	}
	/**
	 * @param base_currency_code the base_currency_code to set
	 */
	public void setBase_currency_code(String base_currency_code) {
		this.base_currency_code = base_currency_code;
	}
	/**
	 * @return the quote_currency_code
	 */
	public String getQuote_currency_code() {
		return quote_currency_code;
	}
	/**
	 * @param quote_currency_code the quote_currency_code to set
	 */
	public void setQuote_currency_code(String quote_currency_code) {
		this.quote_currency_code = quote_currency_code;
	}
	/**
	 * @return the items_qty
	 */
	public int getItems_qty() {
		return items_qty;
	}
	/**
	 * @param items_qty the items_qty to set
	 */
	public void setItems_qty(int items_qty) {
		this.items_qty = items_qty;
	}
	/**
	 * @return the items
	 */
	public ArrayList<Items> getItems() {
		return items;
	}
	/**
	 * @param items the items to set
	 */
	public void setItems(ArrayList<Items> items) {
		this.items = items;
	}
	/**
	 * @return the total_segments
	 */
	public ArrayList<TotalSegments> getTotal_segments() {
		return total_segments;
	}
	/**
	 * @param total_segments the total_segments to set
	 */
	public void setTotal_segments(ArrayList<TotalSegments> total_segments) {
		this.total_segments = total_segments;
	}
	 
}
