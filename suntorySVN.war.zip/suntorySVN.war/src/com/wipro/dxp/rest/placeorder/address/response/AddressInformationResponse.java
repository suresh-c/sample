/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

import java.util.ArrayList;

/**
 * @author JA294967
 *
 */
public class AddressInformationResponse {
	ArrayList<PaymentMethod> payment_methods = new ArrayList<PaymentMethod>();
	OrderTotals totals = new OrderTotals();
	/**
	 * @return the payment_methods
	 */
	public ArrayList<PaymentMethod> getPayment_methods() {
		return payment_methods;
	}
	/**
	 * @param payment_methods the payment_methods to set
	 */
	public void setPayment_methods(ArrayList<PaymentMethod> payment_methods) {
		this.payment_methods = payment_methods;
	}
	/**
	 * @return the totals
	 */
	public OrderTotals getTotals() {
		return totals;
	}
	/**
	 * @param totals the totals to set
	 */
	public void setTotals(OrderTotals totals) {
		this.totals = totals;
	}
	
}
