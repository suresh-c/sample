/**
 * 
 */
package com.wipro.dxp.rest.placeorder.request;

/**
 * @author JA294967
 *
 */
public class PaymentMethod {
	String method = "purchaseorder";
	String po_number;
	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	/**
	 * @return the po_number
	 */
	public String getPo_number() {
		return po_number;
	}
	/**
	 * @param po_number the po_number to set
	 */
	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}
	
}
