/**
 * 
 */
package com.wipro.dxp.rest.placeorder.address.response;

/**
 * @author JA294967
 *
 */
public class TotalSegments {
	String code;
	String title;
	int value;
	String area;
	ExtensionAttributes extension_attributes = new ExtensionAttributes();
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}
	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}
	/**
	 * @return the extension_attributes
	 */
	public ExtensionAttributes getExtension_attributes() {
		return extension_attributes;
	}
	/**
	 * @param extension_attributes the extension_attributes to set
	 */
	public void setExtension_attributes(ExtensionAttributes extension_attributes) {
		this.extension_attributes = extension_attributes;
	}
	
}
