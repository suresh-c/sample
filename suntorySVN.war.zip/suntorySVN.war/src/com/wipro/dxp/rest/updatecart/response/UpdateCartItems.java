package com.wipro.dxp.rest.updatecart.response;

import java.util.ArrayList;

public class UpdateCartItems {

	ArrayList<CartItem> cartItems=new ArrayList<CartItem>();

	public ArrayList<CartItem> getUpdateCart() {
		return cartItems;
	}

	public void setUpdateCart(ArrayList<CartItem> updateCart) {
		this.cartItems = updateCart;
	}
}
