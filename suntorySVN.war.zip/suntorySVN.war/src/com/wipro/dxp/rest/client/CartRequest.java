package com.wipro.dxp.rest.client;

import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wipro.dxp.rest.cart.bean.Cart;
import com.wipro.magentostore.controller.MagentoStoreController;



public class CartRequest {
	private static final Logger _LOGGER = Logger.getLogger(MagentoStoreController.class);
	private static final String webServiceURI = "http://10.201.61.51:81/magento2/rest/V1/suntory/basket/totals";
	//private static final String webServiceURI ="\"grand_total\":950";
	public static void main(String[] args) {
		
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
		WebTarget webTarget = client.target(serviceURI);


		String response = webTarget.request()
			.header("authorization", "Bearer oeeer6eutreqr0voymmbew4xfe9n44sl")
				.header("accept-language", "application/json")
			.get(String.class);
	System.out.println(response);
		
	
	
		Cart cart = new Cart();  
		
		Gson gson = new Gson();
		
		cart = gson.fromJson(response,Cart.class); 
		System.out.println(cart.getItems().get(1).getMedia_gallery().get(1).getPosition());
	
	}
	 
		public static JSONObject jsonresponse(String baseUrl, String servicepath, String token)
			{
				ClientConfig clientConfig = new ClientConfig();
				Client client = ClientBuilder.newClient(clientConfig);
				StringBuffer webServiceURL = new StringBuffer(baseUrl);
				webServiceURL.append(servicepath);
				URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build(); 
				_LOGGER.info(baseUrl+""+servicepath+""+token);
				
		WebTarget webTarget = client.target(serviceURI);
				String response = webTarget.request()
						.header("authorization", "Bearer "+token)
						.header("accept-language", "application/json")
						.get(String.class);
			
				Cart cart = new Cart();
				Gson gson = new Gson();
				cart = gson.fromJson(response,Cart.class);
				JSONObject cartJson= new JSONObject();
				cartJson.put("cartInfo", cart);
				cartJson.put("cartItems", cart.getItems());
				cartJson.put("cartItemsSize", cart.getItems().size());
				_LOGGER.info(cart.getItems().size());
				for(int i=0;i<cart.getItems().size();i++)
				{
					
					if( cart.getItems().get(i).getMedia_gallery().get(0).getFile()!="")
					{
						_LOGGER.info(cart.getItems().get(i).getMedia_gallery().get(0).getFile());
					cartJson.put("image"+i, cart.getItems().get(i).getMedia_gallery().get(0).getFile());
				}
					else
					{
						cartJson.put("image"+i,"");	
					}
				}
				
				return cartJson; 
		
}
		public JSONObject makeRequest(String baseUrl,String servicepath,String method,String token,String data){
			_LOGGER.info("MagentoApiClient - makeRequest - STARTS");
			JSONObject result = new JSONObject();
			try{
				String urlString = baseUrl+servicepath;
				URL url = new URL(urlString);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestProperty("Content-Type", "application/json");
				
				if(token != null){
					connection.setRequestProperty("Authorization", "Bearer "+token);
				}
				connection.setRequestMethod(method);
				if(method.equalsIgnoreCase("DELETE")){
					connection.setDoOutput(true);
					OutputStream outStream = connection.getOutputStream();
					outStream.write(data.getBytes());
					outStream.flush();
					outStream.close();
				}
				
				int responseCode = connection.getResponseCode(); 
				_LOGGER.info(urlString);
				_LOGGER.info(method);
				_LOGGER.info(responseCode);
				
				if(responseCode == 200){
					result.put("status", "success");
					result.put("data", IOUtils.toString(connection.getInputStream()).replaceAll("null", "\"N/A\""));
				}else{
					result.put("status", "failed");
					String error = IOUtils.toString(connection.getErrorStream()).replaceAll("null", "\"N/A\"");
					result.put("data", error);
					_LOGGER.info(error);
				}
				connection.disconnect();
			}
			catch(Exception e){
				e.printStackTrace();
				result.put("status", "failed");
			}
			_LOGGER.info("MagentoApiClient - makeRequest - ENDS");
			return result;
		}	

		
}
