package com.wipro.dxp.rest.client;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.wipro.dxp.rest.cart.bean.Cart;
import com.wipro.dxp.rest.checkout.bean.CheckOut;

public class CheckOutRequest {

	private static final String webServiceURI = "http://10.201.61.51:81/magento2/rest/V1/carts/mine";
	//private static final String webServiceURI ="\"grand_total\":950";
	public static void main(String[] args) {
		CheckOut c = jsonResponse("http://10.201.61.51:81/magento2/rest/V1", "/carts/mine", "oeeer6eutreqr0voymmbew4xfe9n44sl");
		System.out.println(c.getBilling_address().getEmail());
//		ClientConfig clientConfig = new ClientConfig();
//		Client client = ClientBuilder.newClient(clientConfig);
//		URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
//		WebTarget webTarget = client.target(serviceURI);
//
//
//		String response = webTarget.request()
//			.header("authorization", "Bearer oeeer6eutreqr0voymmbew4xfe9n44sl")
//				.header("accept-language", "application/json")
//			.get(String.class);
//	System.out.println(response);
//		
//	
//	
//		CheckOut c = new CheckOut();  
//		
//		Gson gson = new Gson();
//		
//		c = gson.fromJson(response,CheckOut.class); 
//		System.out.println(c.getBilling_address().getEmail());
	
	}
	 
		public static CheckOut jsonResponse(String baseUrl, String servicepath, String token)
			{
				ClientConfig clientConfig = new ClientConfig();
				Client client = ClientBuilder.newClient(clientConfig);
				StringBuffer webServiceURL = new StringBuffer(baseUrl);
				webServiceURL.append(servicepath);
				URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build(); 

		WebTarget webTarget = client.target(serviceURI);
				String response = webTarget.request()
						.header("authorization", "Bearer "+token)
						.header("accept-language", "application/json")
						.get(String.class);
			System.out.println(response);
				CheckOut c = new CheckOut();
				Gson gson = new Gson();
				c = gson.fromJson(response,CheckOut.class);
				return c;
		
}
	
}
