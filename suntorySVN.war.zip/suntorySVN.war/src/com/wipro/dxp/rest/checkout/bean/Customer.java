package com.wipro.dxp.rest.checkout.bean;

import java.util.ArrayList;

public class Customer {

	int id=0;
	int group_id=0;
	String default_billing="";
	String default_shipping="";
	String created_at="";
	String updated_at="";
	String created_in="";
	String email="";
	String firstname="";
	String lastname="";
	int store_id=0;
	int website_id=0;
	ArrayList<Addresses> addresses=new ArrayList<Addresses>();
	int disable_auto_group_change=0;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getGroup_id() {
		return group_id;
	}
	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}
	public String getDefault_billing() {
		return default_billing;
	}
	public void setDefault_billing(String default_billing) {
		this.default_billing = default_billing;
	}
	public String getDefault_shipping() {
		return default_shipping;
	}
	public void setDefault_shipping(String default_shipping) {
		this.default_shipping = default_shipping;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public String getCreated_in() {
		return created_in;
	}
	public void setCreated_in(String created_in) {
		this.created_in = created_in;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	public int getWebsite_id() {
		return website_id;
	}
	public void setWebsite_id(int website_id) {
		this.website_id = website_id;
	}
	public ArrayList<Addresses> getAddresses() {
		return addresses;
	}
	public void setAddresses(ArrayList<Addresses> addresses) {
		this.addresses = addresses;
	}
	public int getDisable_auto_group_change() {
		return disable_auto_group_change;
	}
	public void setDisable_auto_group_change(int disable_auto_group_change) {
		this.disable_auto_group_change = disable_auto_group_change;
	}
	
	
	}
