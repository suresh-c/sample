package com.wipro.dxp.rest.checkout.bean;

import java.util.ArrayList;

public class CheckOut {

	int id=0;
	String created_at="";
	String updated_at="";
	boolean is_active=false;
	boolean is_virtual=false;
	ArrayList<Items> items =new ArrayList<Items>(); 
	int items_count=0;
	int items_qty=0;
	Customer customer;
	Billing_Address billing_address;
	int orig_order_id=0;
	Currency currency;
	boolean customer_is_guest=false;
	boolean customer_note_notify=false;
	int customer_tax_class_id=0;
	int store_id=0;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public boolean isIs_active() {
		return is_active;
	}
	public void setIs_active(boolean is_active) {
		this.is_active = is_active;
	}
	public boolean isIs_virtual() {
		return is_virtual;
	}
	public void setIs_virtual(boolean is_virtual) {
		this.is_virtual = is_virtual;
	}
	public ArrayList<Items> getItems() {
		return items;
	}
	public void setItems(ArrayList<Items> items) {
		this.items = items;
	}
	public int getItems_count() {
		return items_count;
	}
	public void setItems_count(int items_count) {
		this.items_count = items_count;
	}
	public int getItems_qty() {
		return items_qty;
	}
	public void setItems_qty(int items_qty) {
		this.items_qty = items_qty;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Billing_Address getBilling_address() {
		return billing_address;
	}
	public void setBilling_address(Billing_Address billing_address) {
		this.billing_address = billing_address;
	}
	public int getOrig_order_id() {
		return orig_order_id;
	}
	public void setOrig_order_id(int orig_order_id) {
		this.orig_order_id = orig_order_id;
	}
	public Currency getCurrency() {
		return currency;
	}
	public void setCurrency(Currency currency) {
		this.currency = currency;
	}
	public boolean isCustomer_is_guest() {
		return customer_is_guest;
	}
	public void setCustomer_is_guest(boolean customer_is_guest) {
		this.customer_is_guest = customer_is_guest;
	}
	public boolean isCustomer_note_notify() {
		return customer_note_notify;
	}
	public void setCustomer_note_notify(boolean customer_note_notify) {
		this.customer_note_notify = customer_note_notify;
	}
	public int getCustomer_tax_class_id() {
		return customer_tax_class_id;
	}
	public void setCustomer_tax_class_id(int customer_tax_class_id) {
		this.customer_tax_class_id = customer_tax_class_id;
	}
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	
	
}
