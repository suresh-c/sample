package com.wipro.dxp.rest.checkout.bean;

public class Currency {

	String global_currency_code="";
	String base_currency_code="";
	String store_currency_code="";
	String quote_currency_code="";
	int store_to_base_rate=0;
	int store_to_quote_rate=0;
	int base_to_global_rate=0;
	double base_to_quote_rate=0;
	public String getGlobal_currency_code() {
		return global_currency_code;
	}
	public void setGlobal_currency_code(String global_currency_code) {
		this.global_currency_code = global_currency_code;
	}
	public String getBase_currency_code() {
		return base_currency_code;
	}
	public void setBase_currency_code(String base_currency_code) {
		this.base_currency_code = base_currency_code;
	}
	public String getStore_currency_code() {
		return store_currency_code;
	}
	public void setStore_currency_code(String store_currency_code) {
		this.store_currency_code = store_currency_code;
	}
	public String getQuote_currency_code() {
		return quote_currency_code;
	}
	public void setQuote_currency_code(String quote_currency_code) {
		this.quote_currency_code = quote_currency_code;
	}
	public int getStore_to_base_rate() {
		return store_to_base_rate;
	}
	public void setStore_to_base_rate(int store_to_base_rate) {
		this.store_to_base_rate = store_to_base_rate;
	}
	public int getStore_to_quote_rate() {
		return store_to_quote_rate;
	}
	public void setStore_to_quote_rate(int store_to_quote_rate) {
		this.store_to_quote_rate = store_to_quote_rate;
	}
	public int getBase_to_global_rate() {
		return base_to_global_rate;
	}
	public void setBase_to_global_rate(int base_to_global_rate) {
		this.base_to_global_rate = base_to_global_rate;
	}
	public double getBase_to_quote_rate() {
		return base_to_quote_rate;
	}
	public void setBase_to_quote_rate(double base_to_quote_rate) {
		this.base_to_quote_rate = base_to_quote_rate;
	}
	
	
	
}
