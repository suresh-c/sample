package com.wipro.dxp.rest.checkout.bean;

public class Shipping {
	
	Address address;
	String method=null;
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}

}
