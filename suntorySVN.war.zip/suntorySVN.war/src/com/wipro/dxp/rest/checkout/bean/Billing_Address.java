package com.wipro.dxp.rest.checkout.bean;

public class Billing_Address {

	int id=0;
	String region=null;
	String region_id=null;
	String region_code=null;
	String country_id=null;
	String[] street;
	String telephone=null;
	String postcode=null;
	String city=null;
	String firstname=null;
	String lastname=null;
	int customer_id=0;
	String email="";
	int same_as_billing=0;
	int save_in_address_book=0;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getRegion_code() {
		return region_code;
	}
	public void setRegion_code(String region_code) {
		this.region_code = region_code;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String[] getStreet() {
		return street;
	}
	public void setStreet(String[] street) {
		this.street = street;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getSame_as_billing() {
		return same_as_billing;
	}
	public void setSame_as_billing(int same_as_billing) {
		this.same_as_billing = same_as_billing;
	}
	public int getSave_in_address_book() {
		return save_in_address_book;
	}
	public void setSave_in_address_book(int save_in_address_book) {
		this.save_in_address_book = save_in_address_book;
	}
	
	
	
}
