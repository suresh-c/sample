package com.wipro.dxp.rest.checkout.bean;

public class Addresses {
	
	int id=0;
	int customer_id=0;
	Region region;
	int region_id=0;
	String country_id="";
	String[] street;
	String company="";
	String telephone="";
	String postcode="";
	String city="";
	String firstname="";
	String lastname="";
	boolean default_shipping=false;
	boolean default_billing=false;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public Region getRegion() {
		return region;
	}
	public void setRegion(Region region) {
		this.region = region;
	}
	public int getRegion_id() {
		return region_id;
	}
	public void setRegion_id(int region_id) {
		this.region_id = region_id;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String[] getStreet() {
		return street;
	}
	public void setStreet(String[] street) {
		this.street = street;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public boolean isDefault_shipping() {
		return default_shipping;
	}
	public void setDefault_shipping(boolean default_shipping) {
		this.default_shipping = default_shipping;
	}
	public boolean isDefault_billing() {
		return default_billing;
	}
	public void setDefault_billing(boolean default_billing) {
		this.default_billing = default_billing;
	}

	
}
