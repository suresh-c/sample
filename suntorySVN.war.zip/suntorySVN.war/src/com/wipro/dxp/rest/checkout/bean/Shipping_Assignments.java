package com.wipro.dxp.rest.checkout.bean;

public class Shipping_Assignments {

	Shipping shipping;

	public Shipping getShipping() {
		return shipping;
	}

	public void setShipping(Shipping shipping) {
		this.shipping = shipping;
	}
	
}
