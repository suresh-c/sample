package com.wipro.dxp.rest.orderhistory.request.bean;

public class Items {
	double amount_refunded;
	double base_amount_refunded;
	double base_discount_amount;
	double base_discount_invoiced;
	double base_discount_tax_compensation_amount;
	double base_original_price;
	double base_price;
	double base_price_incl_tax;
	double base_row_invoiced;
	double base_row_total;
	double base_row_total_incl_tax;
	double base_tax_amount;
	double base_tax_invoiced;
	String created_at;
	double discount_amount;
	double discount_invoiced;
	double discount_percent;
	double free_shipping;
	double discount_tax_compensation_amount;
	double is_qty_decimal;
	double is_virtual;
	double item_id;
	String name;
	double no_discount;
	double order_id;
	double original_price;
	double price;
	double price_incl_tax;
	double product_id;
	String product_type;
	double qty_canceled;
	double qty_invoiced;
	double qty_ordered;
	double qty_refunded;
	double qty_shipped;
	double quote_item_id;
	double row_invoiced;
	double row_total;
	double row_total_incl_tax;
	double row_weight;
	String sku;
	double store_id;
	double tax_amount;
	double tax_invoiced;
	double tax_percent;
	String updated_at;
	double weight;
	public double getAmount_refunded() {
		return amount_refunded;
	}
	public void setAmount_refunded(double amount_refunded) {
		this.amount_refunded = amount_refunded;
	}
	public double getBase_amount_refunded() {
		return base_amount_refunded;
	}
	public void setBase_amount_refunded(double base_amount_refunded) {
		this.base_amount_refunded = base_amount_refunded;
	}
	public double getBase_discount_amount() {
		return base_discount_amount;
	}
	public void setBase_discount_amount(double base_discount_amount) {
		this.base_discount_amount = base_discount_amount;
	}
	public double getBase_discount_invoiced() {
		return base_discount_invoiced;
	}
	public void setBase_discount_invoiced(double base_discount_invoiced) {
		this.base_discount_invoiced = base_discount_invoiced;
	}
	public double getBase_discount_tax_compensation_amount() {
		return base_discount_tax_compensation_amount;
	}
	public void setBase_discount_tax_compensation_amount(
			double base_discount_tax_compensation_amount) {
		this.base_discount_tax_compensation_amount = base_discount_tax_compensation_amount;
	}
	public double getBase_original_price() {
		return base_original_price;
	}
	public void setBase_original_price(double base_original_price) {
		this.base_original_price = base_original_price;
	}
	public double getBase_price() {
		return base_price;
	}
	public void setBase_price(double base_price) {
		this.base_price = base_price;
	}
	public double getBase_price_incl_tax() {
		return base_price_incl_tax;
	}
	public void setBase_price_incl_tax(double base_price_incl_tax) {
		this.base_price_incl_tax = base_price_incl_tax;
	}
	public double getBase_row_invoiced() {
		return base_row_invoiced;
	}
	public void setBase_row_invoiced(double base_row_invoiced) {
		this.base_row_invoiced = base_row_invoiced;
	}
	public double getBase_row_total() {
		return base_row_total;
	}
	public void setBase_row_total(double base_row_total) {
		this.base_row_total = base_row_total;
	}
	public double getBase_row_total_incl_tax() {
		return base_row_total_incl_tax;
	}
	public void setBase_row_total_incl_tax(double base_row_total_incl_tax) {
		this.base_row_total_incl_tax = base_row_total_incl_tax;
	}
	public double getBase_tax_amount() {
		return base_tax_amount;
	}
	public void setBase_tax_amount(double base_tax_amount) {
		this.base_tax_amount = base_tax_amount;
	}
	public double getBase_tax_invoiced() {
		return base_tax_invoiced;
	}
	public void setBase_tax_invoiced(double base_tax_invoiced) {
		this.base_tax_invoiced = base_tax_invoiced;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public double getDiscount_amount() {
		return discount_amount;
	}
	public void setDiscount_amount(double discount_amount) {
		this.discount_amount = discount_amount;
	}
	public double getDiscount_invoiced() {
		return discount_invoiced;
	}
	public void setDiscount_invoiced(double discount_invoiced) {
		this.discount_invoiced = discount_invoiced;
	}
	public double getDiscount_percent() {
		return discount_percent;
	}
	public void setDiscount_percent(double discount_percent) {
		this.discount_percent = discount_percent;
	}
	public double getFree_shipping() {
		return free_shipping;
	}
	public void setFree_shipping(double free_shipping) {
		this.free_shipping = free_shipping;
	}
	public double getDiscount_tax_compensation_amount() {
		return discount_tax_compensation_amount;
	}
	public void setDiscount_tax_compensation_amount(
			double discount_tax_compensation_amount) {
		this.discount_tax_compensation_amount = discount_tax_compensation_amount;
	}
	public double getIs_qty_decimal() {
		return is_qty_decimal;
	}
	public void setIs_qty_decimal(double is_qty_decimal) {
		this.is_qty_decimal = is_qty_decimal;
	}
	public double getIs_virtual() {
		return is_virtual;
	}
	public void setIs_virtual(double is_virtual) {
		this.is_virtual = is_virtual;
	}
	public double getItem_id() {
		return item_id;
	}
	public void setItem_id(double item_id) {
		this.item_id = item_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getNo_discount() {
		return no_discount;
	}
	public void setNo_discount(double no_discount) {
		this.no_discount = no_discount;
	}
	public double getOrder_id() {
		return order_id;
	}
	public void setOrder_id(double order_id) {
		this.order_id = order_id;
	}
	public double getOriginal_price() {
		return original_price;
	}
	public void setOriginal_price(double original_price) {
		this.original_price = original_price;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getPrice_incl_tax() {
		return price_incl_tax;
	}
	public void setPrice_incl_tax(double price_incl_tax) {
		this.price_incl_tax = price_incl_tax;
	}
	public double getProduct_id() {
		return product_id;
	}
	public void setProduct_id(double product_id) {
		this.product_id = product_id;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public double getQty_canceled() {
		return qty_canceled;
	}
	public void setQty_canceled(double qty_canceled) {
		this.qty_canceled = qty_canceled;
	}
	public double getQty_invoiced() {
		return qty_invoiced;
	}
	public void setQty_invoiced(double qty_invoiced) {
		this.qty_invoiced = qty_invoiced;
	}
	public double getQty_ordered() {
		return qty_ordered;
	}
	public void setQty_ordered(double qty_ordered) {
		this.qty_ordered = qty_ordered;
	}
	public double getQty_refunded() {
		return qty_refunded;
	}
	public void setQty_refunded(double qty_refunded) {
		this.qty_refunded = qty_refunded;
	}
	public double getQty_shipped() {
		return qty_shipped;
	}
	public void setQty_shipped(double qty_shipped) {
		this.qty_shipped = qty_shipped;
	}
	public double getQuote_item_id() {
		return quote_item_id;
	}
	public void setQuote_item_id(double quote_item_id) {
		this.quote_item_id = quote_item_id;
	}
	public double getRow_invoiced() {
		return row_invoiced;
	}
	public void setRow_invoiced(double row_invoiced) {
		this.row_invoiced = row_invoiced;
	}
	public double getRow_total() {
		return row_total;
	}
	public void setRow_total(double row_total) {
		this.row_total = row_total;
	}
	public double getRow_total_incl_tax() {
		return row_total_incl_tax;
	}
	public void setRow_total_incl_tax(double row_total_incl_tax) {
		this.row_total_incl_tax = row_total_incl_tax;
	}
	public double getRow_weight() {
		return row_weight;
	}
	public void setRow_weight(double row_weight) {
		this.row_weight = row_weight;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public double getStore_id() {
		return store_id;
	}
	public void setStore_id(double store_id) {
		this.store_id = store_id;
	}
	public double getTax_amount() {
		return tax_amount;
	}
	public void setTax_amount(double tax_amount) {
		this.tax_amount = tax_amount;
	}
	public double getTax_invoiced() {
		return tax_invoiced;
	}
	public void setTax_invoiced(double tax_invoiced) {
		this.tax_invoiced = tax_invoiced;
	}
	public double getTax_percent() {
		return tax_percent;
	}
	public void setTax_percent(double tax_percent) {
		this.tax_percent = tax_percent;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	
}
