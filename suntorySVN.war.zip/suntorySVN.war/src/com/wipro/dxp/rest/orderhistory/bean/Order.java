package com.wipro.dxp.rest.orderhistory.bean;

import java.util.ArrayList;

public class Order {
	ArrayList<OrderDetail> orders=new ArrayList<OrderDetail>();

	public ArrayList<OrderDetail> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<OrderDetail> orders) {
		this.orders = orders;
	}

	
	
}
