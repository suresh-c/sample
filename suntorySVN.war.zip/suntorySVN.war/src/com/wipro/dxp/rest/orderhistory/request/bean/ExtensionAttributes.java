package com.wipro.dxp.rest.orderhistory.request.bean;

import java.util.ArrayList;

public class ExtensionAttributes {
	ArrayList<ShippingAssignments> shipping_assignments=new ArrayList<ShippingAssignments>();

	public ArrayList<ShippingAssignments> getShipping_assignments() {
		return shipping_assignments;
	}

	public void setShipping_assignments(
			ArrayList<ShippingAssignments> shipping_assignments) {
		this.shipping_assignments = shipping_assignments;
	}
	

}
