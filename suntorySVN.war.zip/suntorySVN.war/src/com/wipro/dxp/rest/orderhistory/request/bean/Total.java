package com.wipro.dxp.rest.orderhistory.request.bean;

public class Total {
	double base_shipping_amount;
	double base_shipping_discount_amount;
	double base_shipping_discount_tax_compensation_amnt;
	double base_shipping_incl_tax;
	double base_shipping_tax_amount;
	double shipping_amount;
	double shipping_discount_amount;
	double shipping_discount_tax_compensation_amount;
	double shipping_incl_tax;
	double shipping_tax_amount;
	public double getBase_shipping_amount() {
		return base_shipping_amount;
	}
	public void setBase_shipping_amount(double base_shipping_amount) {
		this.base_shipping_amount = base_shipping_amount;
	}
	public double getBase_shipping_discount_amount() {
		return base_shipping_discount_amount;
	}
	public void setBase_shipping_discount_amount(
			double base_shipping_discount_amount) {
		this.base_shipping_discount_amount = base_shipping_discount_amount;
	}
	public double getBase_shipping_discount_tax_compensation_amnt() {
		return base_shipping_discount_tax_compensation_amnt;
	}
	public void setBase_shipping_discount_tax_compensation_amnt(
			double base_shipping_discount_tax_compensation_amnt) {
		this.base_shipping_discount_tax_compensation_amnt = base_shipping_discount_tax_compensation_amnt;
	}
	public double getBase_shipping_incl_tax() {
		return base_shipping_incl_tax;
	}
	public void setBase_shipping_incl_tax(double base_shipping_incl_tax) {
		this.base_shipping_incl_tax = base_shipping_incl_tax;
	}
	public double getBase_shipping_tax_amount() {
		return base_shipping_tax_amount;
	}
	public void setBase_shipping_tax_amount(double base_shipping_tax_amount) {
		this.base_shipping_tax_amount = base_shipping_tax_amount;
	}
	public double getShipping_amount() {
		return shipping_amount;
	}
	public void setShipping_amount(double shipping_amount) {
		this.shipping_amount = shipping_amount;
	}
	public double getShipping_discount_amount() {
		return shipping_discount_amount;
	}
	public void setShipping_discount_amount(double shipping_discount_amount) {
		this.shipping_discount_amount = shipping_discount_amount;
	}
	public double getShipping_discount_tax_compensation_amount() {
		return shipping_discount_tax_compensation_amount;
	}
	public void setShipping_discount_tax_compensation_amount(
			double shipping_discount_tax_compensation_amount) {
		this.shipping_discount_tax_compensation_amount = shipping_discount_tax_compensation_amount;
	}
	public double getShipping_incl_tax() {
		return shipping_incl_tax;
	}
	public void setShipping_incl_tax(double shipping_incl_tax) {
		this.shipping_incl_tax = shipping_incl_tax;
	}
	public double getShipping_tax_amount() {
		return shipping_tax_amount;
	}
	public void setShipping_tax_amount(double shipping_tax_amount) {
		this.shipping_tax_amount = shipping_tax_amount;
	}
	
}
