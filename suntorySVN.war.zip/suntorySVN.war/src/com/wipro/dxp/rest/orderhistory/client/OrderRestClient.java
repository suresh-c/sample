package com.wipro.dxp.rest.orderhistory.client;

import java.net.URI;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.wipro.dxp.rest.orderhistory.bean.Order;
import com.wipro.dxp.rest.orderhistory.request.bean.OrderHistory;
import com.wipro.magentostore.controller.MagentoStoreController;


public class OrderRestClient {

	private static final Logger _LOGGER = Logger.getLogger(OrderRestClient.class);
	public static Order orderresponse(String baseUrl, String servicepath , String token)
	{
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		StringBuffer webServiceURL = new StringBuffer(baseUrl);
		webServiceURL.append(servicepath);
		URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build();
		WebTarget webTarget = client.target(serviceURI);
		String response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.get(String.class);
	//	String response="[{\"entity_id\":\"15\",\"increment_id\":\"2000000007\",\"grand_total\":\"2730.9500\",\"customer_firstname\":\"Sanjay\",\"customer_lastname\":\"Alwar\",\"status\":\"pending\",\"created_at\":\"2018-01-26 06:56:39\"}]";
		
		_LOGGER.info(response);
	
		Order order=new Order();
		Gson gson = new Gson();
		order = gson.fromJson(response,Order.class);
		//Order orderObject=dateconverter(order);
		return order;
	}

	
	public static OrderHistory orderDetailresponse(String baseUrl, String servicepath , String token)
	{
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		StringBuffer webServiceURL = new StringBuffer(baseUrl);
		webServiceURL.append(servicepath);
		_LOGGER.info(webServiceURL);
		URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build();
		WebTarget webTarget = client.target(serviceURI);
		String response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.get(String.class);
	
		
		_LOGGER.info(response);
	
		OrderHistory orderInfo=new OrderHistory();
		Gson gson = new Gson();
		orderInfo = gson.fromJson(response,OrderHistory.class);
		_LOGGER.info(orderInfo.getBase_currency_code());
		return orderInfo;
	}

//	public static Order dateconverter(Order order)
//	{
//		_LOGGER.info("Date Conversion");
//		
//		for(int i=0;i<order.getOrders().size();i++)
//		{
//			 
//			
//
//			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//			SimpleDateFormat dateFormatFinal = new SimpleDateFormat("yyyy-MM-dd");
//
//		    Date parsedTimeStamp;
//		
//			try {
//				parsedTimeStamp = dateFormat.parse(order.getOrders().get(i).getCreated_at());
//				Date date=new Date(parsedTimeStamp.getTime());
//			
//				parsedTimeStamp=dateFormatFinal.parse(date.toString());
//				Date finalDate=new Date(parsedTimeStamp.getTime());
//				_LOGGER.info(finalDate.toString());
//			} catch (ParseException e) {
//				//TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//		    
//		}
//		 
//		
//		return order;
//	}
	
	
}
