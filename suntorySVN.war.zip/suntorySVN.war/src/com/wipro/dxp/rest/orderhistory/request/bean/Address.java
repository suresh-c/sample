package com.wipro.dxp.rest.orderhistory.request.bean;

import java.util.ArrayList;

public class Address {
	String address_type;
	String city;
	String country_id;
	String email;
	double entity_id;
	String firstname;
	String lastname;
	double parent_id;
	String postcode;
	String region;
	String region_code;
	ArrayList<String> street=new ArrayList<String>(); 
	String telephone;
	public String getAddress_type() {
		return address_type;
	}
	public void setAddress_type(String address_type) {
		this.address_type = address_type;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getEntity_id() {
		return entity_id;
	}
	public void setEntity_id(double entity_id) {
		this.entity_id = entity_id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public double getParent_id() {
		return parent_id;
	}
	public void setParent_id(double parent_id) {
		this.parent_id = parent_id;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegion_code() {
		return region_code;
	}
	public void setRegion_code(String region_code) {
		this.region_code = region_code;
	}
	public ArrayList<String> getStreet() {
		return street;
	}
	public void setStreet(ArrayList<String> street) {
		this.street = street;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

}
