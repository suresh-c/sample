package com.wipro.dxp.rest.orderhistory.request.bean;

public class ShippingAssignments {
	
	
	Shipping shipping=new Shipping();

	public Shipping getShipping() {
		return shipping;
	}

	public void setShipping(Shipping shipping) {
		this.shipping = shipping;
	}
	

}
