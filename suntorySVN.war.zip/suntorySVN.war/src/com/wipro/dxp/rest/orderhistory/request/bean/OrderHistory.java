package com.wipro.dxp.rest.orderhistory.request.bean;

import java.util.ArrayList;

public class OrderHistory {
	
	String base_currency_code;
	double base_discount_amount;
	double base_grand_total;
	double base_discount_tax_compensation_amount;
	double base_shipping_amount;
	double base_shipping_discount_amount;
	double base_shipping_discount_tax_compensation_amnt;
	double base_shipping_incl_tax;
	double base_shipping_tax_amount;
	double base_subtotal;
	double base_subtotal_incl_tax;
	double base_tax_amount;
	double base_total_due;
	double base_to_global_rate;
	double base_to_order_rate;
	double billing_address_id;
	String created_at;
	String customer_email;
	String customer_firstname;
	double customer_group_id;
	double customer_id;
	double customer_is_guest;
	String customer_lastname;
	double customer_note_notify;
	double discount_amount;
	double email_sent;
	double entity_id;
	String global_currency_code;
	double grand_total;
	double discount_tax_compensation_amount;
	String increment_id;
	double is_virtual;
	String order_currency_code;
	String protect_code;
	double quote_id;
	String remote_ip;
	double shipping_amount;
	String shipping_description;
	double shipping_discount_amount;
	double shipping_discount_tax_compensation_amount;
	double shipping_incl_tax;
	double shipping_tax_amount;
	String state;
	String status;
	String store_currency_code;
	double store_id;
	String store_name;
	double store_to_base_rate;
	double store_to_order_rate;
	double subtotal;
	double subtotal_incl_tax;
	double tax_amount;
	double total_due;
	double total_item_count;
	double total_qty_ordered;
	String updated_at;
	double weight;
	ArrayList<Items> items=new ArrayList<Items>();
	BillingAddress billing_address;
	Payment payment;
	ArrayList<StatusHistories> status_histories=new ArrayList<StatusHistories>();
	ExtensionAttributes extension_attributes;
	public String getBase_currency_code() {
		return base_currency_code;
	}
	public void setBase_currency_code(String base_currency_code) {
		this.base_currency_code = base_currency_code;
	}
	public double getBase_discount_amount() {
		return base_discount_amount;
	}
	public void setBase_discount_amount(double base_discount_amount) {
		this.base_discount_amount = base_discount_amount;
	}
	public double getBase_grand_total() {
		return base_grand_total;
	}
	public void setBase_grand_total(double base_grand_total) {
		this.base_grand_total = base_grand_total;
	}
	public double getBase_discount_tax_compensation_amount() {
		return base_discount_tax_compensation_amount;
	}
	public void setBase_discount_tax_compensation_amount(
			double base_discount_tax_compensation_amount) {
		this.base_discount_tax_compensation_amount = base_discount_tax_compensation_amount;
	}
	public double getBase_shipping_amount() {
		return base_shipping_amount;
	}
	public void setBase_shipping_amount(double base_shipping_amount) {
		this.base_shipping_amount = base_shipping_amount;
	}
	public double getBase_shipping_discount_amount() {
		return base_shipping_discount_amount;
	}
	public void setBase_shipping_discount_amount(
			double base_shipping_discount_amount) {
		this.base_shipping_discount_amount = base_shipping_discount_amount;
	}
	public double getBase_shipping_discount_tax_compensation_amnt() {
		return base_shipping_discount_tax_compensation_amnt;
	}
	public void setBase_shipping_discount_tax_compensation_amnt(
			double base_shipping_discount_tax_compensation_amnt) {
		this.base_shipping_discount_tax_compensation_amnt = base_shipping_discount_tax_compensation_amnt;
	}
	public double getBase_shipping_incl_tax() {
		return base_shipping_incl_tax;
	}
	public void setBase_shipping_incl_tax(double base_shipping_incl_tax) {
		this.base_shipping_incl_tax = base_shipping_incl_tax;
	}
	public double getBase_shipping_tax_amount() {
		return base_shipping_tax_amount;
	}
	public void setBase_shipping_tax_amount(double base_shipping_tax_amount) {
		this.base_shipping_tax_amount = base_shipping_tax_amount;
	}
	public double getBase_subtotal() {
		return base_subtotal;
	}
	public void setBase_subtotal(double base_subtotal) {
		this.base_subtotal = base_subtotal;
	}
	public double getBase_subtotal_incl_tax() {
		return base_subtotal_incl_tax;
	}
	public void setBase_subtotal_incl_tax(double base_subtotal_incl_tax) {
		this.base_subtotal_incl_tax = base_subtotal_incl_tax;
	}
	public double getBase_tax_amount() {
		return base_tax_amount;
	}
	public void setBase_tax_amount(double base_tax_amount) {
		this.base_tax_amount = base_tax_amount;
	}
	public double getBase_total_due() {
		return base_total_due;
	}
	public void setBase_total_due(double base_total_due) {
		this.base_total_due = base_total_due;
	}
	public double getBase_to_global_rate() {
		return base_to_global_rate;
	}
	public void setBase_to_global_rate(double base_to_global_rate) {
		this.base_to_global_rate = base_to_global_rate;
	}
	public double getBase_to_order_rate() {
		return base_to_order_rate;
	}
	public void setBase_to_order_rate(double base_to_order_rate) {
		this.base_to_order_rate = base_to_order_rate;
	}
	public double getBilling_address_id() {
		return billing_address_id;
	}
	public void setBilling_address_id(double billing_address_id) {
		this.billing_address_id = billing_address_id;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public String getCustomer_firstname() {
		return customer_firstname;
	}
	public void setCustomer_firstname(String customer_firstname) {
		this.customer_firstname = customer_firstname;
	}
	public double getCustomer_group_id() {
		return customer_group_id;
	}
	public void setCustomer_group_id(double customer_group_id) {
		this.customer_group_id = customer_group_id;
	}
	public double getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(double customer_id) {
		this.customer_id = customer_id;
	}
	public double getCustomer_is_guest() {
		return customer_is_guest;
	}
	public void setCustomer_is_guest(double customer_is_guest) {
		this.customer_is_guest = customer_is_guest;
	}
	public String getCustomer_lastname() {
		return customer_lastname;
	}
	public void setCustomer_lastname(String customer_lastname) {
		this.customer_lastname = customer_lastname;
	}
	public double getCustomer_note_notify() {
		return customer_note_notify;
	}
	public void setCustomer_note_notify(double customer_note_notify) {
		this.customer_note_notify = customer_note_notify;
	}
	public double getDiscount_amount() {
		return discount_amount;
	}
	public void setDiscount_amount(double discount_amount) {
		this.discount_amount = discount_amount;
	}
	public double getEmail_sent() {
		return email_sent;
	}
	public void setEmail_sent(double email_sent) {
		this.email_sent = email_sent;
	}
	public double getEntity_id() {
		return entity_id;
	}
	public void setEntity_id(double entity_id) {
		this.entity_id = entity_id;
	}
	public String getGlobal_currency_code() {
		return global_currency_code;
	}
	public void setGlobal_currency_code(String global_currency_code) {
		this.global_currency_code = global_currency_code;
	}
	public double getGrand_total() {
		return grand_total;
	}
	public void setGrand_total(double grand_total) {
		this.grand_total = grand_total;
	}
	public double getDiscount_tax_compensation_amount() {
		return discount_tax_compensation_amount;
	}
	public void setDiscount_tax_compensation_amount(
			double discount_tax_compensation_amount) {
		this.discount_tax_compensation_amount = discount_tax_compensation_amount;
	}
	public String getIncrement_id() {
		return increment_id;
	}
	public void setIncrement_id(String increment_id) {
		this.increment_id = increment_id;
	}
	public double getIs_virtual() {
		return is_virtual;
	}
	public void setIs_virtual(double is_virtual) {
		this.is_virtual = is_virtual;
	}
	
	public String getOrder_currency_code() {
		return order_currency_code;
	}
	public void setOrder_currency_code(String order_currency_code) {
		this.order_currency_code = order_currency_code;
	}
	public String getProtect_code() {
		return protect_code;
	}
	public void setProtect_code(String protect_code) {
		this.protect_code = protect_code;
	}
	public double getQuote_id() {
		return quote_id;
	}
	public void setQuote_id(double quote_id) {
		this.quote_id = quote_id;
	}
	public String getRemote_ip() {
		return remote_ip;
	}
	public void setRemote_ip(String remote_ip) {
		this.remote_ip = remote_ip;
	}
	public double getShipping_amount() {
		return shipping_amount;
	}
	public void setShipping_amount(double shipping_amount) {
		this.shipping_amount = shipping_amount;
	}
	public String getShipping_description() {
		return shipping_description;
	}
	public void setShipping_description(String shipping_description) {
		this.shipping_description = shipping_description;
	}
	public double getShipping_discount_amount() {
		return shipping_discount_amount;
	}
	public void setShipping_discount_amount(double shipping_discount_amount) {
		this.shipping_discount_amount = shipping_discount_amount;
	}
	public double getShipping_discount_tax_compensation_amount() {
		return shipping_discount_tax_compensation_amount;
	}
	public void setShipping_discount_tax_compensation_amount(
			double shipping_discount_tax_compensation_amount) {
		this.shipping_discount_tax_compensation_amount = shipping_discount_tax_compensation_amount;
	}
	public double getShipping_incl_tax() {
		return shipping_incl_tax;
	}
	public void setShipping_incl_tax(double shipping_incl_tax) {
		this.shipping_incl_tax = shipping_incl_tax;
	}
	public double getShipping_tax_amount() {
		return shipping_tax_amount;
	}
	public void setShipping_tax_amount(double shipping_tax_amount) {
		this.shipping_tax_amount = shipping_tax_amount;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStore_currency_code() {
		return store_currency_code;
	}
	public void setStore_currency_code(String store_currency_code) {
		this.store_currency_code = store_currency_code;
	}
	public double getStore_id() {
		return store_id;
	}
	public void setStore_id(double store_id) {
		this.store_id = store_id;
	}
	public String getStore_name() {
		return store_name;
	}
	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}
	public double getStore_to_base_rate() {
		return store_to_base_rate;
	}
	public void setStore_to_base_rate(double store_to_base_rate) {
		this.store_to_base_rate = store_to_base_rate;
	}
	public double getStore_to_order_rate() {
		return store_to_order_rate;
	}
	public void setStore_to_order_rate(double store_to_order_rate) {
		this.store_to_order_rate = store_to_order_rate;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}
	public double getSubtotal_incl_tax() {
		return subtotal_incl_tax;
	}
	public void setSubtotal_incl_tax(double subtotal_incl_tax) {
		this.subtotal_incl_tax = subtotal_incl_tax;
	}
	public double getTax_amount() {
		return tax_amount;
	}
	public void setTax_amount(double tax_amount) {
		this.tax_amount = tax_amount;
	}
	public double getTotal_due() {
		return total_due;
	}
	public void setTotal_due(double total_due) {
		this.total_due = total_due;
	}
	public double getTotal_item_count() {
		return total_item_count;
	}
	public void setTotal_item_count(double total_item_count) {
		this.total_item_count = total_item_count;
	}
	public double getTotal_qty_ordered() {
		return total_qty_ordered;
	}
	public void setTotal_qty_ordered(double total_qty_ordered) {
		this.total_qty_ordered = total_qty_ordered;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public ArrayList<Items> getItems() {
		return items;
	}
	public void setItems(ArrayList<Items> items) {
		this.items = items;
	}
	public BillingAddress getBilling_address() {
		return billing_address;
	}
	public void setBilling_address(BillingAddress billing_address) {
		this.billing_address = billing_address;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	public ArrayList<StatusHistories> getStatus_histories() {
		return status_histories;
	}
	public void setStatus_histories(ArrayList<StatusHistories> status_histories) {
		this.status_histories = status_histories;
	}
	public ExtensionAttributes getExtension_attributes() {
		return extension_attributes;
	}
	public void setExtension_attributes(ExtensionAttributes extension_attributes) {
		this.extension_attributes = extension_attributes;
	}
	
	
	
	
}
