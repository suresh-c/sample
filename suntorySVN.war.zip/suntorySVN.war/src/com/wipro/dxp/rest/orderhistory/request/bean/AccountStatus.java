package com.wipro.dxp.rest.orderhistory.request.bean;

public class AccountStatus {

}
