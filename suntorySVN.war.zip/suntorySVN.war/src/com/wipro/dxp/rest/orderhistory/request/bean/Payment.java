package com.wipro.dxp.rest.orderhistory.request.bean;

import java.util.ArrayList;

public class Payment 
{
	AccountStatus account_status;
	ArrayList<String>additional_information=new ArrayList<String>();
	double amount_ordered;
	double base_amount_ordered;
	double base_shipping_amount;
	String cc_last4;
	double entity_id;
	String method;
	double parent_id;
	String po_number;
	double shipping_amount;
	
	public AccountStatus getAccount_status() {
		return account_status;
	}
	public void setAccount_status(AccountStatus account_status) {
		this.account_status = account_status;
	}
	public ArrayList<String> getAdditional_information() {
		return additional_information;
	}
	public void setAdditional_information(ArrayList<String> additional_information) {
		this.additional_information = additional_information;
	}
	public double getAmount_ordered() {
		return amount_ordered;
	}
	public void setAmount_ordered(double amount_ordered) {
		this.amount_ordered = amount_ordered;
	}
	public double getBase_amount_ordered() {
		return base_amount_ordered;
	}
	public void setBase_amount_ordered(double base_amount_ordered) {
		this.base_amount_ordered = base_amount_ordered;
	}
	public double getBase_shipping_amount() {
		return base_shipping_amount;
	}
	public void setBase_shipping_amount(double base_shipping_amount) {
		this.base_shipping_amount = base_shipping_amount;
	}
	public String getCc_last4() {
		return cc_last4;
	}
	public void setCc_last4(String cc_last4) {
		this.cc_last4 = cc_last4;
	}
	public double getEntity_id() {
		return entity_id;
	}
	public void setEntity_id(double entity_id) {
		this.entity_id = entity_id;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public double getParent_id() {
		return parent_id;
	}
	public void setParent_id(double parent_id) {
		this.parent_id = parent_id;
	}
	public String getPo_number() {
		return po_number;
	}
	public void setPo_number(String po_number) {
		this.po_number = po_number;
	}
	public double getShipping_amount() {
		return shipping_amount;
	}
	public void setShipping_amount(double shipping_amount) {
		this.shipping_amount = shipping_amount;
	}
	
}
