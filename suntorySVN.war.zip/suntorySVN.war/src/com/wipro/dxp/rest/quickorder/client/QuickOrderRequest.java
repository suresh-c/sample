package com.wipro.dxp.rest.quickorder.client;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.google.gson.Gson;
import com.wipro.dxp.rest.quickorder.bean.QuickOrder;
import com.wipro.dxp.rest.quickorder.request.bean.Cart;


public class QuickOrderRequest {

	private static final Logger _LOGGER = Logger.getLogger(Cart.class);
	WebTarget webTarget;
	private static final String webServiceURI = "http://10.201.61.51:81/magento2/rest/V1/suntory/customer/1/most_ordered/20";

	public static void main(String[] args)   {
	
			ClientConfig clientConfig = new ClientConfig();
			Client client = ClientBuilder.newClient(clientConfig);
			URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
			WebTarget webTarget = client.target(serviceURI);
			String response = webTarget.request()
					.header("authorization", "Bearer y6gwhc1y5ncawg4t00enixguck5om1d3")
					.header("accept-language", "application/json")
					.get(String.class);
			System.out.println(response);
//			Gson gson = new GsonBuilder().setLenient()
//            .disableHtmlEscaping()
//            .setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)
//            .setPrettyPrinting()
//            .serializeNulls()
//            .create();
			QuickOrder quickorder = new QuickOrder();  
		//Gson gson = new GsonBuilder().setLenient().create();
			
	Gson gson = new Gson();
		//	Type type = new TypeToken<QuickOrder>() {}.getType();
	 //response="{\"orders\":[{\"product\":{\"entity_id\":\"5\",\"attribute_set_id\":\"9\",\"type_id\":\"simple\",\"sku\":\"Test Product 3\",\"has_options\":\"0\",\"required_options\":\"0\",\"created_at\":\"2018-01-02 10:47:38\",\"updated_at\":\"2018-01-03 10:13:49\",\"status\":\"1\",\"visibility\":\"4\",\"quantity_and_stock_status\":{\"is_in_stock\":true,\"qty\":93},\"tax_class_id\":\"2\",\"price\":\"350.0000\",\"special_price\":null,\"weight\":\"2.0000\",\"name\":\"Test Product 3\",\"options_container\":\"container2\",\"url_key\":\"test-product-3\",\"msrp_display_actual_price_type\":\"0\",\"gift_message_available\":\"0\",\"material_id\":\"testmatid1\",\"material_name\":\"test mat name 1\",\"options\":[],\"media_gallery\":{\"images\":[],\"values\":[]},\"extension_attributes\":{},\"tier_price\":[],\"tier_price_changed\":0,\"category_ids\":[\"4\"],\"is_salable\":\"1\",\"salable\":true},\"max_ordered_qty\":\"1.0000\"},{\"product\":{\"entity_id\":\"8\",\"attribute_set_id\":\"9\",\"type_id\":\"simple\",\"sku\":\"Test Product 6\",\"has_options\":\"0\",\"required_options\":\"0\",\"created_at\":\"2018-01-03 10:44:04\",\"updated_at\":\"2018-01-03 10:53:36\",\"status\":\"1\",\"visibility\":\"4\",\"quantity_and_stock_status\":{\"is_in_stock\":true,\"qty\":113},\"tax_class_id\":\"2\",\"price\":\"400.0000\",\"special_price\":null,\"weight\":\"3.0000\",\"name\":\"Test Product 6\",\"options_container\":\"container2\",\"url_key\":\"test-product-6\",\"msrp_display_actual_price_type\":\"0\",\"gift_message_available\":\"0\",\"material_id\":\"wl_02\",\"material_name\":\"Wipro 02\",\"options\":[],\"media_gallery\":{\"images\":[],\"values\":[]},\"extension_attributes\":{},\"tier_price\":[],\"tier_price_changed\":0,\"category_ids\":[\"4\"],\"is_salable\":\"1\",\"salable\":true},\"max_ordered_qty\":\"6.0000\"},{\"product\":{\"entity_id\":\"6\",\"attribute_set_id\":\"9\",\"type_id\":\"simple\",\"sku\":\"Test Product 4\",\"has_options\":\"0\",\"required_options\":\"0\",\"created_at\":\"2018-01-02 10:47:38\",\"updated_at\":\"2018-01-03 10:05:36\",\"status\":\"1\",\"visibility\":\"4\",\"quantity_and_stock_status\":{\"is_in_stock\":true,\"qty\":118},\"tax_class_id\":\"2\",\"price\":\"400.0000\",\"special_price\":null,\"weight\":\"3.0000\",\"name\":\"Test Product 4\",\"options_container\":\"container2\",\"url_key\":\"test-product-4\",\"msrp_display_actual_price_type\":\"0\",\"gift_message_available\":\"0\",\"material_id\":\"testmatid2\",\"material_name\":\"test mat name 2\",\"options\":[],\"media_gallery\":{\"images\":[],\"values\":[]},\"extension_attributes\":{},\"tier_price\":[],\"tier_price_changed\":0,\"category_ids\":[\"4\"],\"is_salable\":\"1\",\"salable\":true},\"max_ordered_qty\":\"1.0000\"}]}[]";
		System.out.println(response);
			quickorder = gson.fromJson(response,QuickOrder.class);
			
			System.out.println(quickorder.getOrders().get(0));
			System.out.println(quickorder.getOrders().get(0).getProduct().getTier_price_changed());
			System.out.println(quickorder.getOrders().get(0).getProduct().getTier_price());
			System.out.println(quickorder.getOrders().get(0).getProduct().getCategory_ids()[0]);
			System.out.println(quickorder.getOrders().get(0).getProduct().getIs_salable());
			System.out.println(quickorder.getOrders().get(0).getProduct().getSalable());
		//	System.out.println(quickorder.getOrders().get(0).getProduct().getMedia_gallery().getValues());
			//System.out.println(quickorder.getOrders().get(0).getProduct().getUrl_key());

	}
//	String response ="{\"orders\":[{\"product\":{\"entity_id\":\"5\",\"attribute_set_id\":\"9\",\"type_id\":\"simple\",\"sku\":\"Test Product 3\",\"has_options\":\"0\",\"required_options\":\"0\",\"created_at\":\"2018-01-02 10:47:38\",\"updated_at\":\"2018-01-03 10:13:49\",\"status\":\"1\",\"visibility\":\"4\",\"quantity_and_stock_status\":{\"is_in_stock\":true,\"qty\":93},\"tax_class_id\":\"2\",\"price\":\"350.0000\",\"special_price\":null,\"weight\":\"2.0000\",\"name\":\"Test Product 3\",\"options_container\":\"container2\",\"url_key\":\"test-product-3\",\"msrp_display_actual_price_type\":\"0\",\"gift_message_available\":\"0\",\"material_id\":\"testmatid1\",\"material_name\":\"test mat name 1\",\"options\":[],\"media_gallery\":{\"images\":[],\"values\":[]},\"extension_attributes\":{},\"tier_price\":[],\"tier_price_changed\":0,\"category_ids\":[\"4\"],\"is_salable\":\"1\",\"salable\":true},\"max_ordered_qty\":\"1.0000\"},{\"product\":{\"entity_id\":\"8\",\"attribute_set_id\":\"9\",\"type_id\":\"simple\",\"sku\":\"Test Product 6\",\"has_options\":\"0\",\"required_options\":\"0\",\"created_at\":\"2018-01-03 10:44:04\",\"updated_at\":\"2018-01-03 10:53:36\",\"status\":\"1\",\"visibility\":\"4\",\"quantity_and_stock_status\":{\"is_in_stock\":true,\"qty\":113},\"tax_class_id\":\"2\",\"price\":\"400.0000\",\"special_price\":null,\"weight\":\"3.0000\",\"name\":\"Test Product 6\",\"options_container\":\"container2\",\"url_key\":\"test-product-6\",\"msrp_display_actual_price_type\":\"0\",\"gift_message_available\":\"0\",\"material_id\":\"wl_02\",\"material_name\":\"Wipro 02\",\"options\":[],\"media_gallery\":{\"images\":[],\"values\":[]},\"extension_attributes\":{},\"tier_price\":[],\"tier_price_changed\":0,\"category_ids\":[\"4\"],\"is_salable\":\"1\",\"salable\":true},\"max_ordered_qty\":\"6.0000\"},{\"product\":{\"entity_id\":\"6\",\"attribute_set_id\":\"9\",\"type_id\":\"simple\",\"sku\":\"Test Product 4\",\"has_options\":\"0\",\"required_options\":\"0\",\"created_at\":\"2018-01-02 10:47:38\",\"updated_at\":\"2018-01-03 10:05:36\",\"status\":\"1\",\"visibility\":\"4\",\"quantity_and_stock_status\":{\"is_in_stock\":true,\"qty\":118},\"tax_class_id\":\"2\",\"price\":\"400.0000\",\"special_price\":null,\"weight\":\"3.0000\",\"name\":\"Test Product 4\",\"options_container\":\"container2\",\"url_key\":\"test-product-4\",\"msrp_display_actual_price_type\":\"0\",\"gift_message_available\":\"0\",\"material_id\":\"testmatid2\",\"material_name\":\"test mat name 2\",\"options\":[],\"media_gallery\":{\"images\":[],\"values\":[]},\"extension_attributes\":{},\"tier_price\":[],\"tier_price_changed\":0,\"category_ids\":[\"4\"],\"is_salable\":\"1\",\"salable\":true},\"max_ordered_qty\":\"1.0000\"}]}";
	public QuickOrder jsonresponse(String baseUrl, String servicepath , String token)
	{
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		StringBuffer webServiceURL = new StringBuffer(baseUrl);
		webServiceURL.append(servicepath);
		URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build();
		WebTarget webTarget = client.target(serviceURI);
		String response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.get(String.class);
		 _LOGGER.info(response);
		QuickOrder quickorder = new QuickOrder();
		Gson gson = new Gson();
		quickorder = gson.fromJson(response,QuickOrder.class);
		return quickorder;
	}
	
	
	public JSONObject quickorderrequest(String baseURL,String servicePath,String data,String token,String method)
	{
		_LOGGER.info("MagentoApiClient - makeRequest - QuickOrder Request");
		 JSONObject result = new JSONObject();
         try{
                         String urlString = baseURL+servicePath;
                         URL url = new URL(urlString);
                         HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                         connection.setRequestProperty("Content-Type", "application/json");
                         
                         if(token != null){
                                         connection.setRequestProperty("Authorization", "Bearer "+token);
                         }
                         connection.setRequestMethod(method);
                         if(method.equalsIgnoreCase("POST")){
                                         connection.setDoOutput(true);
                                         OutputStream outStream = connection.getOutputStream();
                                         outStream.write(data.getBytes());
                                         outStream.flush();
                                         outStream.close();
                         }
                         int responseCode = connection.getResponseCode(); 
                         _LOGGER.info(urlString);
                         _LOGGER.info(method);
                         _LOGGER.info(responseCode);
                         if(responseCode == 200){
                             result.put("status", "success");
                             result.put("data", IOUtils.toString(connection.getInputStream()).replaceAll("null", "\"N/A\""));
             }else{
                             result.put("status", "failed");
                             String error = IOUtils.toString(connection.getErrorStream()).replaceAll("null", "\"N/A\"");
                             result.put("data", error);
                             _LOGGER.info(error);
             }
             connection.disconnect();
         }
         catch(Exception e){
             e.printStackTrace();
             result.put("status", "failed");
         }
         _LOGGER.info("MagentoApiClient - makeRequest -QuickOrder Request");
         return result;
		
		
	}
		
}
