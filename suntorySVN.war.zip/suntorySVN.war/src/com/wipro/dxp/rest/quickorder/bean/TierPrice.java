package com.wipro.dxp.rest.quickorder.bean;

public class TierPrice {

}
