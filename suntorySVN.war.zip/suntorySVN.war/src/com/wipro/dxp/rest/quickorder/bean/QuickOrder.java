package com.wipro.dxp.rest.quickorder.bean;

import java.util.ArrayList;

public class QuickOrder {
	ArrayList<Orders> orders = new ArrayList<Orders>();

	public ArrayList<Orders> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<Orders> orders) {
		this.orders = orders;
	}
	
	
	

}
