package com.wipro.dxp.rest.quickorder.bean;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class Product {
	String entity_id="";
	String attribute_set_id="";
	String type_id="";
	String sku="";
	String has_options="";
	String required_options="";
	String created_at="";
	String updated_at="";
	String status="";
	String visibility="";
	QuantityAndStock quantity_and_stock_status= new QuantityAndStock() ;
	String tax_class_id="";
	String price="";
	String special_price;
	String weight="";
	String name="";
	String options_container="";
	String url_key="";
	String msrp_display_actual_price_type="";
	String gift_message_available="";
	String material_id="";
	String material_name="";
	
	ExtensionAttributes extension_attributes;
	int tier_price_changed=0;
	String[] category_ids;
	String is_salable="";
	boolean salable;
	ArrayList<Options> options=new ArrayList<Options>();
	ArrayList<TierPrice> tier_price =new ArrayList<TierPrice>();
	

	public ExtensionAttributes getExtension_attributes() {
		return extension_attributes;
	}
	public void setExtension_attributes(ExtensionAttributes extension_attributes) {
		this.extension_attributes = extension_attributes;
	}

	
	public String getEntity_id() {
		return entity_id;
	}
	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}
	public String getAttribute_set_id() {
		return attribute_set_id;
	}
	public void setAttribute_set_id(String attribute_set_id) {
		this.attribute_set_id = attribute_set_id;
	}
		public String getType_id() {
		return type_id;
	}
	public void setType_id(String type_id) {
		this.type_id = type_id;
	}
		public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getHas_options() {
		return has_options;
	}
	public void setHas_options(String has_options) {
		this.has_options = has_options;
	}
		public String getRequired_options() {
		return required_options;
	}
	public void setRequired_options(String required_options) {
		this.required_options = required_options;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public QuantityAndStock getQuantity_and_stock_status() {
		return quantity_and_stock_status;
	}
	public void setQuantity_and_stock_status(
			QuantityAndStock quantity_and_stock_status) {
		this.quantity_and_stock_status = quantity_and_stock_status;
	}
	public String getTax_class_id() {
		return tax_class_id;
	}
	public void setTax_class_id(String tax_class_id) {
		this.tax_class_id = tax_class_id;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}


	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOptions_container() {
		return options_container;
	}
	public void setOptions_container(String options_container) {
		this.options_container = options_container;
	}
	public String getUrl_key() {
		return url_key;
	}
	public void setUrl_key(String url_key) {
		this.url_key = url_key;
	}
	public String getMsrp_display_actual_price_type() {
		return msrp_display_actual_price_type;
	}
	public void setMsrp_display_actual_price_type(
			String msrp_display_actual_price_type) {
		this.msrp_display_actual_price_type = msrp_display_actual_price_type;
	}
	public String getGift_message_available() {
		return gift_message_available;
	}
	public void setGift_message_available(String gift_message_available) {
		this.gift_message_available = gift_message_available;
	}
	public String getMaterial_id() {
		return material_id;
	}
	public void setMaterial_id(String material_id) {
		this.material_id = material_id;
	}
	public String getMaterial_name() {
		return material_name;
	}
	public void setMaterial_name(String material_name) {
		this.material_name = material_name;
	}
	

	
	public String getSpecial_price() {
		return special_price;
	}
	public void setSpecial_price(String special_price) {
		this.special_price = special_price;
	}
	
	public ArrayList<Options> getOptions() {
		return options;
	}
	public void setOptions(ArrayList<Options> options) {
		this.options = options;
	}
	
	public int getTier_price_changed() {
		return tier_price_changed;
	}
	public void setTier_price_changed(int tier_price_changed) {
		this.tier_price_changed = tier_price_changed;
	}
	
	
	
	public String getIs_salable() {
		return is_salable;
	}
	public void setIs_salable(String is_salable) {
		this.is_salable = is_salable;
	}


	
	public boolean getSalable() {
		return salable;
	}
	public void setSalable(boolean salable) {
		this.salable = salable;
	}
	public ArrayList<TierPrice> getTier_price() {
		return tier_price;
	}
	public void setTier_price(ArrayList<TierPrice> tier_price) {
		this.tier_price = tier_price;
	}
	public String[] getCategory_ids() {
		return category_ids;
	}
	public void setCategory_ids(String[] category_ids) {
		this.category_ids = category_ids;
	}

	
	
}
