package com.wipro.dxp.rest.quickorder.request;

import java.util.ArrayList;

public class Cart {
ArrayList<CartItems> cartItems=new ArrayList<CartItems>();

public ArrayList<CartItems> getCartItems() {
	return cartItems;
}

public void setCartItems(ArrayList<CartItems> cartItems) {
	this.cartItems = cartItems;
}

}
