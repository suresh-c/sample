package com.wipro.dxp.rest.quickorder.bean;

public class ExtensionAttributes {

}
