package com.wipro.dxp.rest.quickorder.request.bean;

public class CartItems {
		int productId;
		int qty;
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public int getQty() {
			return qty;
		}
		public void setQty(int qty) {
			this.qty = qty;
		}
		
}
