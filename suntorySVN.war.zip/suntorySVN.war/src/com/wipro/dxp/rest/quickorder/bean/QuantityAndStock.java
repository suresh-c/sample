package com.wipro.dxp.rest.quickorder.bean;

public class QuantityAndStock {
	boolean is_in_stock;
	int qty=0;
	
	public boolean getIs_in_stock() {
		return is_in_stock;
	}
	public void setIs_in_stock(boolean is_in_stock) {
		this.is_in_stock = is_in_stock;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	

}
