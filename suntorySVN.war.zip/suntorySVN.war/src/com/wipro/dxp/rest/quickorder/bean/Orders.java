package com.wipro.dxp.rest.quickorder.bean;


public class Orders {
	Product product;
	String max_ordered_qty="";
//
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
//
	public String getMax_ordered_qty() {
		return max_ordered_qty;
	}

	public void setMax_ordered_qty(String max_ordered_qty) {
		this.max_ordered_qty = max_ordered_qty;
	}
	
}
