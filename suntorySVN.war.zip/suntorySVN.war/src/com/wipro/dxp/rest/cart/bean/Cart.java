package com.wipro.dxp.rest.cart.bean;

import java.util.ArrayList;

public class Cart {

	double grand_total=0.00;
	double base_grand_total=0.00;
	double subtotal=0.00;
	double base_subtotal=0.00;
	double discount_amount=0.00;
	double base_discount_amount=0.00;
	double subtotal_with_discount=0.00;
	double base_subtotal_with_discount=0.00;
	double shipping_amount=0.00;
	double base_shipping_amount=0.00;
	double shipping_discount_amount=0.00;
	double base_shipping_discount_amount=0.00;
	double tax_amount=0.00;
	double base_tax_amount=0.00;
	String weee_tax_applied_amount=null;
	double shipping_tax_amount=0.00;
	double base_shipping_tax_amount=0.00;
	double subtotal_incl_tax=0.00;
	double shipping_incl_tax=0.00;
	double base_shipping_incl_tax=0.00;
	String base_currency_code="";
	String quote_currency_code="";
	int items_qty=0;
	ArrayList<Items> items=new ArrayList<Items>();
	ArrayList<TotalSegments> total_segments=new ArrayList<TotalSegments>();
	public double getGrand_total() {
		return grand_total;
	}
	public void setGrand_total(double grand_total) {
		this.grand_total = grand_total;
	}
	public double getBase_grand_total() {
		return base_grand_total;
	}
	public void setBase_grand_total(double base_grand_total) {
		this.base_grand_total = base_grand_total;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}
	public double getBase_subtotal() {
		return base_subtotal;
	}
	public void setBase_subtotal(double base_subtotal) {
		this.base_subtotal = base_subtotal;
	}
	public double getDiscount_amount() {
		return discount_amount;
	}
	public void setDiscount_amount(double discount_amount) {
		this.discount_amount = discount_amount;
	}
	public double getBase_discount_amount() {
		return base_discount_amount;
	}
	public void setBase_discount_amount(double base_discount_amount) {
		this.base_discount_amount = base_discount_amount;
	}
	public double getSubtotal_with_discount() {
		return subtotal_with_discount;
	}
	public void setSubtotal_with_discount(double subtotal_with_discount) {
		this.subtotal_with_discount = subtotal_with_discount;
	}
	public double getBase_subtotal_with_discount() {
		return base_subtotal_with_discount;
	}
	public void setBase_subtotal_with_discount(double base_subtotal_with_discount) {
		this.base_subtotal_with_discount = base_subtotal_with_discount;
	}
	public double getShipping_amount() {
		return shipping_amount;
	}
	public void setShipping_amount(double shipping_amount) {
		this.shipping_amount = shipping_amount;
	}
	public double getBase_shipping_amount() {
		return base_shipping_amount;
	}
	public void setBase_shipping_amount(double base_shipping_amount) {
		this.base_shipping_amount = base_shipping_amount;
	}
	public double getShipping_discount_amount() {
		return shipping_discount_amount;
	}
	public void setShipping_discount_amount(double shipping_discount_amount) {
		this.shipping_discount_amount = shipping_discount_amount;
	}
	public double getBase_shipping_discount_amount() {
		return base_shipping_discount_amount;
	}
	public void setBase_shipping_discount_amount(
			double base_shipping_discount_amount) {
		this.base_shipping_discount_amount = base_shipping_discount_amount;
	}
	public double getTax_amount() {
		return tax_amount;
	}
	public void setTax_amount(double tax_amount) {
		this.tax_amount = tax_amount;
	}
	public double getBase_tax_amount() {
		return base_tax_amount;
	}
	public void setBase_tax_amount(double base_tax_amount) {
		this.base_tax_amount = base_tax_amount;
	}
	public String getWeee_tax_applied_amount() {
		return weee_tax_applied_amount;
	}
	public void setWeee_tax_applied_amount(String weee_tax_applied_amount) {
		this.weee_tax_applied_amount = weee_tax_applied_amount;
	}
	public double getShipping_tax_amount() {
		return shipping_tax_amount;
	}
	public void setShipping_tax_amount(double shipping_tax_amount) {
		this.shipping_tax_amount = shipping_tax_amount;
	}
	public double getBase_shipping_tax_amount() {
		return base_shipping_tax_amount;
	}
	public void setBase_shipping_tax_amount(double base_shipping_tax_amount) {
		this.base_shipping_tax_amount = base_shipping_tax_amount;
	}
	public double getSubtotal_incl_tax() {
		return subtotal_incl_tax;
	}
	public void setSubtotal_incl_tax(double subtotal_incl_tax) {
		this.subtotal_incl_tax = subtotal_incl_tax;
	}
	public double getShipping_incl_tax() {
		return shipping_incl_tax;
	}
	public void setShipping_incl_tax(double shipping_incl_tax) {
		this.shipping_incl_tax = shipping_incl_tax;
	}
	public double getBase_shipping_incl_tax() {
		return base_shipping_incl_tax;
	}
	public void setBase_shipping_incl_tax(double base_shipping_incl_tax) {
		this.base_shipping_incl_tax = base_shipping_incl_tax;
	}
	public String getBase_currency_code() {
		return base_currency_code;
	}
	public void setBase_currency_code(String base_currency_code) {
		this.base_currency_code = base_currency_code;
	}
	public String getQuote_currency_code() {
		return quote_currency_code;
	}
	public void setQuote_currency_code(String quote_currency_code) {
		this.quote_currency_code = quote_currency_code;
	}
	public int getItems_qty() {
		return items_qty;
	}
	public void setItems_qty(int items_qty) {
		this.items_qty = items_qty;
	}
	public ArrayList<Items> getItems() {
		return items;
	}
	public void setItems(ArrayList<Items> items) {
		this.items = items;
	}
	public ArrayList<TotalSegments> getTotal_segments() {
		return total_segments;
	}
	public void setTotal_segments(ArrayList<TotalSegments> total_segments) {
		this.total_segments = total_segments;
	}
		
}
