package com.wipro.dxp.rest.cart.bean;

public class TotalSegments {

	String code="";
	String title="";
	String value="";
	ExtensionAttributes extension_attributes;
	String area="";
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public ExtensionAttributes getExtension_attributes() {
		return extension_attributes;
	}
	public void setExtension_attributes(ExtensionAttributes extension_attributes) {
		this.extension_attributes = extension_attributes;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
}
