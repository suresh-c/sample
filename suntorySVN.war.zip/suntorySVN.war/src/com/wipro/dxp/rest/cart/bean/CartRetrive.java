package com.wipro.dxp.rest.cart.bean;

import java.util.ArrayList;

public class CartRetrive {
	
	ArrayList<CartItems> cartItems=new ArrayList<CartItems>();

}
