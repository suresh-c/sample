package com.wipro.dxp.rest.cart.bean;

public class CartItems {

	int productId=0;
	int qty=0;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	
}
