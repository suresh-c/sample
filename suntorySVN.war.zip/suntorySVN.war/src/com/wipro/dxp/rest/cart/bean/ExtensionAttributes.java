package com.wipro.dxp.rest.cart.bean;

import java.util.ArrayList;

public class ExtensionAttributes {

	ArrayList<String> tax_grandtotal_details=new ArrayList<String>();

	public ArrayList<String> getTax_grandtotal_details() {
		return tax_grandtotal_details;
	}

	public void setTax_grandtotal_details(ArrayList<String> tax_grandtotal_details) {
		this.tax_grandtotal_details = tax_grandtotal_details;
	}
}
