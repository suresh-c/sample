package com.wipro.dxp.rest.productview.bean;

public class Media_Gallery {
	String value_id= "";
	String file="";
	String media_type= "";
	String entity_id= "";
	String label= null;
	String position= "";
	String disabled= "";
	String label_default= null;
	String position_default= "";
	String disabled_default= "";
	String video_provider= null;
	String video_url= null;
	String video_title= null;
	String video_description= null;
	String video_metadata= null;
	String video_provider_default= null;
	String video_url_default= null;
	String video_title_default= null;
	String video_description_default= null;
	String video_metadata_default= null;
	public String getValue_id() {
		return value_id;
	}
	public void setValue_id(String value_id) {
		this.value_id = value_id;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getMedia_type() {
		return media_type;
	}
	public void setMedia_type(String media_type) {
		this.media_type = media_type;
	}
	public String getEntity_id() {
		return entity_id;
	}
	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDisabled() {
		return disabled;
	}
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}
	public String getLabel_default() {
		return label_default;
	}
	public void setLabel_default(String label_default) {
		this.label_default = label_default;
	}
	public String getPosition_default() {
		return position_default;
	}
	public void setPosition_default(String position_default) {
		this.position_default = position_default;
	}
	public String getDisabled_default() {
		return disabled_default;
	}
	public void setDisabled_default(String disabled_default) {
		this.disabled_default = disabled_default;
	}
	public String getVideo_provider() {
		return video_provider;
	}
	public void setVideo_provider(String video_provider) {
		this.video_provider = video_provider;
	}
	public String getVideo_url() {
		return video_url;
	}
	public void setVideo_url(String video_url) {
		this.video_url = video_url;
	}
	public String getVideo_title() {
		return video_title;
	}
	public void setVideo_title(String video_title) {
		this.video_title = video_title;
	}
	public String getVideo_description() {
		return video_description;
	}
	public void setVideo_description(String video_description) {
		this.video_description = video_description;
	}
	public String getVideo_metadata() {
		return video_metadata;
	}
	public void setVideo_metadata(String video_metadata) {
		this.video_metadata = video_metadata;
	}
	public String getVideo_provider_default() {
		return video_provider_default;
	}
	public void setVideo_provider_default(String video_provider_default) {
		this.video_provider_default = video_provider_default;
	}
	public String getVideo_url_default() {
		return video_url_default;
	}
	public void setVideo_url_default(String video_url_default) {
		this.video_url_default = video_url_default;
	}
	public String getVideo_title_default() {
		return video_title_default;
	}
	public void setVideo_title_default(String video_title_default) {
		this.video_title_default = video_title_default;
	}
	public String getVideo_description_default() {
		return video_description_default;
	}
	public void setVideo_description_default(String video_description_default) {
		this.video_description_default = video_description_default;
	}
	public String getVideo_metadata_default() {
		return video_metadata_default;
	}
	public void setVideo_metadata_default(String video_metadata_default) {
		this.video_metadata_default = video_metadata_default;
	}
	
	
}
