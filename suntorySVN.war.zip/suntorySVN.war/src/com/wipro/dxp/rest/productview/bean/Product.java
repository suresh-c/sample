package com.wipro.dxp.rest.productview.bean;

import java.util.ArrayList;

public class Product {
	
	
String entity_id="";
String attribute_set_id="";
String type_id="";
String sku="";
String has_options="";
String required_options="";
String created_at="";
String updated_at="";
String status= "";
String visibility="";
Quantity_and_Stock_Status quantity_and_stock_status= new Quantity_and_Stock_Status();
String tax_class_id= "";
String price= "";
String special_price= null;
String weight= "";
String name="";
String meta_title= "";
String meta_description= "";
String image= "";
String small_image= "";
String thumbnail= "";
String options_container= "";
String url_key= "";
String gift_message_available= "";
String swatch_image= "";
String material_id= "";
String material_name= "";
String short_description="";
String meta_keyword= "";
ArrayList<Options> options= new ArrayList<Options>();
ArrayList<Media_Gallery> media_gallery=new ArrayList<Media_Gallery>();
ArrayList<Tier_Price> tier_price= new ArrayList<Tier_Price>();
int tier_price_changed=0;
String[] category_ids;
String is_salable="";
public String getEntity_id() {
	return entity_id;
}
public void setEntity_id(String entity_id) {
	this.entity_id = entity_id;
}
public String getAttribute_set_id() {
	return attribute_set_id;
}
public void setAttribute_set_id(String attribute_set_id) {
	this.attribute_set_id = attribute_set_id;
}
public String getType_id() {
	return type_id;
}
public void setType_id(String type_id) {
	this.type_id = type_id;
}
public String getSku() {
	return sku;
}
public void setSku(String sku) {
	this.sku = sku;
}
public String getHas_options() {
	return has_options;
}
public void setHas_options(String has_options) {
	this.has_options = has_options;
}
public String getRequired_options() {
	return required_options;
}
public void setRequired_options(String required_options) {
	this.required_options = required_options;
}
public String getCreated_at() {
	return created_at;
}
public void setCreated_at(String created_at) {
	this.created_at = created_at;
}
public String getUpdated_at() {
	return updated_at;
}
public void setUpdated_at(String updated_at) {
	this.updated_at = updated_at;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getVisibility() {
	return visibility;
}
public void setVisibility(String visibility) {
	this.visibility = visibility;
}
public Quantity_and_Stock_Status getQuantity_and_stock_status() {
	return quantity_and_stock_status;
}
public void setQuantity_and_stock_status(
		Quantity_and_Stock_Status quantity_and_stock_status) {
	this.quantity_and_stock_status = quantity_and_stock_status;
}
public String getTax_class_id() {
	return tax_class_id;
}
public void setTax_class_id(String tax_class_id) {
	this.tax_class_id = tax_class_id;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getSpecial_price() {
	return special_price;
}
public void setSpecial_price(String special_price) {
	this.special_price = special_price;
}
public String getWeight() {
	return weight;
}
public void setWeight(String weight) {
	this.weight = weight;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMeta_title() {
	return meta_title;
}
public void setMeta_title(String meta_title) {
	this.meta_title = meta_title;
}
public String getMeta_description() {
	return meta_description;
}
public void setMeta_description(String meta_description) {
	this.meta_description = meta_description;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public String getSmall_image() {
	return small_image;
}
public void setSmall_image(String small_image) {
	this.small_image = small_image;
}
public String getThumbnail() {
	return thumbnail;
}
public void setThumbnail(String thumbnail) {
	this.thumbnail = thumbnail;
}
public String getOptions_container() {
	return options_container;
}
public void setOptions_container(String options_container) {
	this.options_container = options_container;
}
public String getUrl_key() {
	return url_key;
}
public void setUrl_key(String url_key) {
	this.url_key = url_key;
}
public String getGift_message_available() {
	return gift_message_available;
}
public void setGift_message_available(String gift_message_available) {
	this.gift_message_available = gift_message_available;
}
public String getSwatch_image() {
	return swatch_image;
}
public void setSwatch_image(String swatch_image) {
	this.swatch_image = swatch_image;
}
public String getMaterial_id() {
	return material_id;
}
public void setMaterial_id(String material_id) {
	this.material_id = material_id;
}
public String getMaterial_name() {
	return material_name;
}
public void setMaterial_name(String material_name) {
	this.material_name = material_name;
}
public String getShort_description() {
	return short_description;
}
public void setShort_description(String short_description) {
	this.short_description = short_description;
}
public String getMeta_keyword() {
	return meta_keyword;
}
public void setMeta_keyword(String meta_keyword) {
	this.meta_keyword = meta_keyword;
}
public ArrayList<Options> getOptions() {
	return options;
}
public void setOptions(ArrayList<Options> options) {
	this.options = options;
}
public ArrayList<Media_Gallery> getMedia_gallery() {
	return media_gallery;
}
public void setMedia_gallery(ArrayList<Media_Gallery> media_gallery) {
	this.media_gallery = media_gallery;
}
public ArrayList<Tier_Price> getTier_price() {
	return tier_price;
}
public void setTier_price(ArrayList<Tier_Price> tier_price) {
	this.tier_price = tier_price;
}
public int getTier_price_changed() {
	return tier_price_changed;
}
public void setTier_price_changed(int tier_price_changed) {
	this.tier_price_changed = tier_price_changed;
}
public String[] getCategory_ids() {
	return category_ids;
}
public void setCategory_ids(String[] category_ids) {
	this.category_ids = category_ids;
}
public String getIs_salable() {
	return is_salable;
}
public void setIs_salable(String is_salable) {
	this.is_salable = is_salable;
}


	
	
}
