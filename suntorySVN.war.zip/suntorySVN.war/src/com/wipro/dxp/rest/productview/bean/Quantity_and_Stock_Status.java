package com.wipro.dxp.rest.productview.bean;

public class Quantity_and_Stock_Status {
 
	boolean is_in_stock=false;
	int qty=0;
	public boolean isIs_in_stock() {
		return is_in_stock;
	}
	public void setIs_in_stock(boolean is_in_stock) {
		this.is_in_stock = is_in_stock;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
}
