package com.wipro.dxp.rest.productview.client;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.google.gson.Gson;
import com.mysql.jdbc.Connection;
import com.wipro.dxp.rest.productview.bean.Product;


public class ProductviewRest {
	private static final Logger _LOGGER = Logger.getLogger(Product.class); 

	public static Product productsearch(String baseUrl, String servicepath , String token)
	{
		_LOGGER.info("hai");
		
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		StringBuffer webServiceURL = new StringBuffer(baseUrl);
        webServiceURL.append(servicepath);
		URI serviceURI = UriBuilder.fromUri(webServiceURL.toString()).build();
		WebTarget webTarget = client.target(serviceURI);
		System.out.println(webTarget.toString());
		String response = webTarget.request()
				.header("authorization", "Bearer "+token)
				.header("accept-language", "application/json")
				.get(String.class);
		System.out.println(response);
		Product product = new Product();
		Gson gson = new Gson();
		product = gson.fromJson(response,Product.class);
		return product;
}
	public static JSONObject productrequest(String baseURL,String servicePath,String data,String token,String method)
	{
		_LOGGER.info("MagentoApiClient - makeRequest - QuickOrder Request");
		 JSONObject result = new JSONObject();
         try{
                         String urlString = baseURL+servicePath;
                         URL url = new URL(urlString);
                         HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                         connection.setRequestProperty("Content-Type", "application/json");
                         
                         if(token != null){
                                         connection.setRequestProperty("Authorization", "Bearer "+token);
                         }
                         connection.setRequestMethod(method);
                         if(method.equalsIgnoreCase("POST")){
                                         connection.setDoOutput(true);
                                         OutputStream outStream = connection.getOutputStream();
                                         outStream.write(data.getBytes());
                                         outStream.flush();
                                         outStream.close();
                         }
                         int responseCode = connection.getResponseCode(); 
                         _LOGGER.info(urlString);
                         _LOGGER.info(method);
                         _LOGGER.info(responseCode);
                         if(responseCode == 200){
                             result.put("status", "success");
                             result.put("data", IOUtils.toString(connection.getInputStream()).replaceAll("null", "\"N/A\""));
             }else{
                             result.put("status", "failed");
                             String error = IOUtils.toString(connection.getErrorStream()).replaceAll("null", "\"N/A\"");
                             result.put("data", error);
                             _LOGGER.info(error);
             }
             connection.disconnect();
         }
         catch(Exception e){
             e.printStackTrace();
             result.put("status", "failed");
         }
         _LOGGER.info("MagentoApiClient - makeRequest -QuickOrder Request");
         return result;
		
		
	}



}
